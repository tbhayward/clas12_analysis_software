#!/bin/csh

source source_file.txt

# Set the first argument to be processing two particles if not provided
if ( $#argv < 1 ) then
    set arg1 = "processing_scripts/processing_two_particles.groovy"
    echo "Warning: First argument not provided. Using default: $arg1, which processes two particle events."
else
    set arg1 = "$1"
endif

# Determine the third argument for ./convert_txt_to_root based on arg1
# Initialize to 0 as default value
set convert_arg3 = 0

# Set convert_arg3 based on the value of arg1
if ($arg1 == "processing_scripts/processing_inclusive.groovy") then
    set convert_arg3 = 0
else if ($arg1 == "processing_scripts/processing_mc_inclusive.groovy") then
    set convert_arg3 = 0
else if ($arg1 == "processing_scripts/processing_two_particles.groovy") then
    set convert_arg3 = 1
else if ($arg1 == "processing_scripts/processing_mc_two_particles.groovy") then
    set convert_arg3 = 1
else if ($arg1 == "processing_scripts/processing_three_particles.groovy") then
    set convert_arg3 = 2
else if ($arg1 == "processing_scripts/processing_mc_three_particles.groovy") then
    set convert_arg3 = 2
else if ($arg1 == "processing_scripts/processing_four_particles.groovy") then
    set convert_arg3 = 3
else if ($arg1 == "processing_scripts/processing_dvcs.groovy") then
    set convert_arg3 = 4 # dvcs
else if ($arg1 == "processing_scripts/processing_mc_dvcs.groovy") then
    set convert_arg3 = 4 # dvcs
else if ($arg1 == "processing_scripts/processing_exclusive_pi0.groovy") then
    set convert_arg3 = 5 # eppi0
else if ($arg1 == "processing_scripts/processing_mc_exclusive_pi0.groovy") then
    set convert_arg3 = 5 # generated aaogen, legacy eppi0 branch schema
else if ($arg1 == "processing_scripts/processing_calibration.groovy") then
    set convert_arg3 = 6 # calibration
else if ($arg1 == "processing_scripts/processing_dvcs_calibration.groovy") then
    set convert_arg3 = 6 # calibration
else if ($arg1 == "processing_scripts/processing_mc_rec_dvcs.groovy") then
    set convert_arg3 = 7 # reconstructed MC dvcs with MC::Event weight
else if ($arg1 == "processing_scripts/processing_mc_rec_exclusive_pi0.groovy") then
    set convert_arg3 = 8 # reconstructed MC eppi0 with MC::Event weight
else
    echo "Error: unrecognized processing script: $arg1"
    exit 1
endif

# determine if Monte Carlo
set is_mc = 0;
if ($arg1 == "processing_scripts/processing_mc_inclusive.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_two_particles.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_three_particles.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_dvcs.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_exclusive_pi0.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_rec_dvcs.groovy") then
    set is_mc = 1;
else if ($arg1 == "processing_scripts/processing_mc_rec_exclusive_pi0.groovy") then
    set is_mc = 1;
endif

# Set the second argument to default to the RGA Fall2018 inbending nSidis skim if not provided
if ( $#argv < 2 ) then
    set arg2 = "/cache/clas12/rg-a/production/recon/fall2018/torus-1/pass2/main/train/nSidis/"
    echo "Warning: Second argument not provided. Using default: $arg2, the RGAFa18 pass-2 Inbending nSidis skim."
else
    set arg2 = "$2"
endif

# Campaign workers share one checkout and converter binaries. The campaign launcher
# performs git pull and compiles both converters ONCE before starting workers.
if ($?DVCS_CAMPAIGN_WORKER) then
    echo "Campaign worker: shared git pull and converter compilation completed by launcher."
else
    echo "Pulling the latest changes from the repository..."
    git pull
    if ($status != 0) exit 1
    if (! -f processing_classes/dist/processing_classes.jar) then
        echo "ERROR: locally built processing_classes.jar missing"
        exit 1
    endif
    cp processing_classes/dist/processing_classes.jar coatjava/lib/services/processing_classes.jar
    if ($status != 0) exit 1
endif
# Java processing classes are compiled separately by the user.
echo "Loading QADB module for classpath compatibility; MC selection bypasses QADB."
module load qadb/3.4.1
if (! $?DVCS_CAMPAIGN_WORKER) then
    g++ `root-config --cflags --libs` -o processing_scripts/convert_txt_to_root processing_scripts/convert_txt_to_root.cpp
    if ($status != 0) exit 1
    if ($convert_arg3 == 7 || $convert_arg3 == 8) then
        g++ `root-config --cflags --libs` -o processing_scripts/convert_dvcs_mc_diagnostics processing_scripts/convert_dvcs_mc_diagnostics.cpp
        if ($status != 0) exit 1
    endif
endif

if ($convert_arg3 == 7 || $convert_arg3 == 8) then
    if ($#argv < 9) then
        echo "ERROR: MC processing requires 9 arguments: script input output nfiles energy run qadb_override max_events correction_period"
        exit 2
    endif
    echo "MC processing: script=$arg1 input=$arg2 output=$3 nfiles=$4 energy=$5 run=$6 max_events=$8 period=$9"
else
    echo "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7"
endif

# Optional per-invocation event cap for DVCS data, pi0 data and generated DVCS.
set campaign_max_events = 0
if ($#argv >= 8) then
    set campaign_max_events = "$8"
endif

# execute command based on number of entries (or dvcs/eppi0/calibration designation)
if ($arg1 == "processing_scripts/processing_inclusive.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" 
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_mc_inclusive.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_two_particles.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3" "$4.txt" "$5" "$6" "$7" "$8"
    # Run the convert_txt_to_root program
    set txt_file = "$4.txt"
    set root_file = "$4.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_mc_two_particles.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3" "$4.txt" "$5" "$6" "$7" "$8" "$9"
    # Run the convert_txt_to_root program
    set txt_file = "$4.txt"
    set root_file = "$4.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_three_particles.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3" "$4" "$5.txt" "$6" "$7" "$8" "$9"
    # Run the convert_txt_to_root program
    set txt_file = "$5.txt"
    set root_file = "$5.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_mc_three_particles.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3" "$4" "$5.txt" "$6" "$7" "$8" "$9"
    # Run the convert_txt_to_root program
    set txt_file = "$5.txt"
    set root_file = "$5.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_four_particles.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3" "$4" "$5" "$6.txt" "$7" "$8"
    # Run the convert_txt_to_root program
    set txt_file = "$6.txt"
    set root_file = "$6.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_dvcs.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$campaign_max_events"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_mc_dvcs.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$campaign_max_events"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_exclusive_pi0.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$campaign_max_events"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_mc_rec_dvcs.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$8" "$9"
    if ($status != 0) then
        echo "ERROR: DVCS MC Groovy processing failed"
        exit 1
    endif
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
    if ($status != 0) then
        echo "ERROR: legacy DVCS MC ROOT conversion failed"
        exit 1
    endif
else if ($arg1 == "processing_scripts/processing_mc_exclusive_pi0.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$campaign_max_events"
    if ($status != 0) then
        echo "ERROR: generated pi0 Groovy processing failed"
        exit 1
    endif
    ./processing_scripts/convert_txt_to_root "$3.txt" "$3.root" 5 0
    if ($status != 0) then
        echo "ERROR: generated pi0 ROOT conversion failed"
        exit 1
    endif
else if ($arg1 == "processing_scripts/processing_mc_rec_exclusive_pi0.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7" "$8" "$9"
    if ($status != 0) then
        echo "ERROR: pi0 MC Groovy processing failed"
        exit 1
    endif
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
    if ($status != 0) then
        echo "ERROR: pi0 MC legacy conversion failed"
        exit 1
    endif
else if ($arg1 == "processing_scripts/processing_calibration.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
else if ($arg1 == "processing_scripts/processing_dvcs_calibration.groovy") then
    coatjava/bin/run-groovy -cp processing_classes/dist/processing_classes.jar "$arg1" "$arg2" "$3.txt" "$4" "$5" "$6" "$7"
    # Run the convert_txt_to_root program
    set txt_file = "$3.txt"
    set root_file = "$3.root"
    ./processing_scripts/convert_txt_to_root $txt_file $root_file $convert_arg3 $is_mc
endif
# Sidecars are converted after the main dispatch block; csh nested conditionals
# must not appear on the same line as `else`/`endif` tokens.
if ($convert_arg3 == 7 || $convert_arg3 == 8) then
    ./processing_scripts/convert_dvcs_mc_diagnostics "$3.txt.events.tsv" "$3.mc_events.root"
    if ($status != 0) then
        echo "ERROR: MC event diagnostic conversion failed"
        exit 1
    endif
    ./processing_scripts/convert_dvcs_mc_diagnostics "$3.txt.particles.tsv" "$3.mc_particles.root"
    if ($status != 0) then
        echo "ERROR: MC particle diagnostic conversion failed"
        exit 1
    endif
endif

# Delete text intermediates only after every requested ROOT conversion succeeded.
# Leave intermediates untouched if an earlier stage failed.
if (! -s "$3.root") then
    echo "ERROR: legacy ROOT output missing or empty: $3.root"
    exit 1
endif
if ($convert_arg3 == 7 || $convert_arg3 == 8) then
    if (! -s "$3.mc_events.root" || ! -s "$3.mc_particles.root") then
        echo "ERROR: one or more diagnostic ROOT outputs missing or empty; retaining intermediates"
        exit 1
    endif
    /bin/rm -f "$3.txt.events.tsv" "$3.txt.particles.tsv"
endif
echo "ROOT conversion complete; legacy .txt retained; diagnostic TSV intermediates removed."
