// acceptance.cpp
// -----------------------------------------------------------------------------
// DVCS acceptance from already-counted non-radiative MC yields in the CSV.
//
// New refactored behavior:
//   - No ROOT tree loops.
//   - No event-level cuts here.
//   - Uses generated and reconstructed MC yields already saved by total_counts.cpp.
//   - Computes:
//
//       acceptance, <period> = N_rec_current_corrected / N_gen
//
//     where:
//
//       N_gen = generated yield, ep->epg, mc, <period>
//
//       N_rec_current_corrected = sum over topologies:
//         reconstructed current corrected yield, ep->epg, (FD, FD), mc, <period>
//         reconstructed current corrected yield, ep->epg, (CD, FD), mc, <period>
//         reconstructed current corrected yield, ep->epg, (CD, FT), mc, <period>
//
//   - Writes acceptance as:
//
//       (value,stat,sys)
//
//     with sys = 0 for now.
//
//   - Produces per-period acceptance-vs-phi plots under:
//       <out_root_dir>/acceptance/<PeriodDir>/
//
// Notes:
//   - Global cuts, topology cuts, and 3-sigma cuts are intentionally not applied
//     here because the reconstructed MC yield columns were filled upstream after
//     those cuts.
// -----------------------------------------------------------------------------

#include "acceptance.h"

#include <TTree.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TLegend.h>
#include <TH1D.h>
#include <TLatex.h>
#include <TPad.h>
#include <TH1.h>
#include <TH1F.h>
#include <TROOT.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TAxis.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

static inline void fatal(const std::string& msg) {
    throw std::runtime_error(msg);
}

static inline bool is_finite_positive(double x) {
    return std::isfinite(x) && x > 0.0;
}

static inline bool is_finite_nonnegative(double x) {
    return std::isfinite(x) && x >= 0.0;
}

// -----------------------------------------------------------------------------
// Reviewed RGA proton reconstruction-efficiency correction (Neupane, 2026).
//
// The analysis-note convention is
//     E_C = epsilon_exp / epsilon_sim .
// Therefore the detector acceptance appropriate to data is
//     A_data = A_MC * E_C,
// and the extracted cross section is raised by 1/E_C where MC overestimates
// proton reconstruction.  The published parameterization is quadratic in
// proton momentum, separately in broad theta/phi regions.
//
// This pass-2 implementation evaluates the parameterization at the measured
// proton mean kinematics of each four-dimensional DVCS bin.  Proton momentum
// is obtained exactly from |t| for an on-shell recoil proton:
//     E_p = M_p + |t|/(2 M_p),  p = sqrt(E_p^2-M_p^2).
// The Neupane efficiency bins were defined with missing-proton coordinates and
// mapped to measured coordinates in that analysis.  Because the supplied fit
// table itself is in broad detector-region bins and the mapping is close to
// unity, the present implementation uses the measured p_theta/p_phi means.
// This is intentionally explicit in the CSV so a later event-level/mapped
// refinement can replace it without changing the rest of the extraction.
// -----------------------------------------------------------------------------
static double wrap_deg_360_local(double d) {
    if (!std::isfinite(d)) return std::numeric_limits<double>::quiet_NaN();
    d = std::fmod(d, 360.0);
    if (d < 0.0) d += 360.0;
    return d;
}

struct ProtonEffParams { double a, b, c; };

static ProtonEffParams proton_eff_params(double theta_deg, double phi_deg) {
    const double phi = wrap_deg_360_local(phi_deg);
    if (theta_deg < 37.0) {
        // Table 7.2, theta < 37 deg; phi bins [0,60),...,[300,360).
        static const ProtonEffParams p[6] = {
            {0.04437, -0.14271, 1.03439},
            {0.00490,  0.00554, 0.91770},
            {0.03671, -0.11680, 1.03002},
            {0.01863, -0.07756, 1.02308},
            {0.04915, -0.17173, 1.11768},
            {0.01077, -0.01328, 0.96242}
        };
        int i = static_cast<int>(std::floor(phi / 60.0));
        if (i < 0) i = 0;
        if (i > 5) i = 5;
        return p[i];
    }

    // Table 7.3, theta >= 37 deg; phi bins [0,120),[120,240),[240,360).
    static const ProtonEffParams p[3] = {
        {0.20052, -0.79964, 1.38699},
        {0.16842, -0.64970, 1.31246},
        {0.18845, -0.75924, 1.41677}
    };
    int i = static_cast<int>(std::floor(phi / 120.0));
    if (i < 0) i = 0;
    if (i > 2) i = 2;
    return p[i];
}

static double proton_momentum_from_t(double tabs) {
    static constexpr double mp = 0.9382720813;
    if (!(std::isfinite(tabs) && tabs >= 0.0))
        return std::numeric_limits<double>::quiet_NaN();
    const double ep = mp + tabs / (2.0 * mp);
    const double p2 = ep * ep - mp * mp;
    return p2 > 0.0 ? std::sqrt(p2) : 0.0;
}

static double proton_efficiency_factor(double tabs, double theta_deg, double phi_deg) {
    const double p = proton_momentum_from_t(tabs);
    if (!(std::isfinite(p) && std::isfinite(theta_deg) && std::isfinite(phi_deg)))
        return std::numeric_limits<double>::quiet_NaN();
    const ProtonEffParams q = proton_eff_params(theta_deg, phi_deg);
    const double f = q.a * p * p + q.b * p + q.c;
    // Physical/defensive range.  Nominal DVCS kinematics are far from these
    // bounds; hitting one means the extrapolation should be inspected.
    if (!(std::isfinite(f) && f > 0.20 && f < 1.80))
        return std::numeric_limits<double>::quiet_NaN();
    return f;
}

static double proton_eff_sys_fraction_for_period(const std::string& period) {
    // Neupane's three-way efficiency-correction variation gives 2.83% on the
    // integrated cross section for Fall-2018 inbending.  Per the current
    // pass-2 interim prescription, Fa18 uses that value while Sp18 and Sp19
    // receive 4x the uncertainty until dedicated period studies are complete.
    static constexpr double base = 0.0283;
    if (period == "Sp18 Inb" || period == "Sp18 Out" || period == "Sp19 Inb")
        return 4.0 * base;
    return base;
}

static std::string canonical_period_dir(const std::string& label) {
    if (label == "Fa18 Inb") return "Fa18_Inb";
    if (label == "Fa18 Out") return "Fa18_Out";
    if (label == "Sp19 Inb") return "Sp19_Inb";
    if (label == "Sp18 Inb") return "Sp18_Inb";
    if (label == "Sp18 Out") return "Sp18_Out";

    std::ostringstream ss;
    ss << "[acceptance] FATAL: unknown period label: " << label;
    fatal(ss.str());

    return "";
}

static void mkdir_p(const std::string& path) {
    if (!path.empty()) {
        gSystem->mkdir(path.c_str(), true);
    }
}

static const std::vector<std::string>& periods() {
    static const std::vector<std::string> v = {
        "Fa18 Inb",
        "Fa18 Out",
        "Sp19 Inb",
        "Sp18 Inb",
        "Sp18 Out"
    };

    return v;
}

static const std::vector<std::string>& topologies() {
    static const std::vector<std::string> v = {
        "(FD, FD)",
        "(CD, FD)",
        "(CD, FT)"
    };

    return v;
}

// -----------------------------------------------------------------------------
// CSV I/O
// -----------------------------------------------------------------------------

struct CSV {
    std::vector<std::string> header;
    std::unordered_map<std::string, int> index;
    std::vector<std::vector<std::string>> rows;
};

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    cur.reserve(line.size());

    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];

        if (c == '"') {
            if (in_quotes && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }

    out.push_back(cur);
    return out;
}

static std::string join_csv_row(const std::vector<std::string>& fields) {
    std::ostringstream oss;

    for (size_t i = 0; i < fields.size(); ++i) {
        const std::string& s = fields[i];

        const bool quote =
            s.find(',') != std::string::npos ||
            s.find('"') != std::string::npos ||
            s.find('\n') != std::string::npos ||
            s.find('\r') != std::string::npos;

        if (quote) {
            oss << '"';

            for (char ch : s) {
                if (ch == '"') {
                    oss << "\"\"";
                } else {
                    oss << ch;
                }
            }

            oss << '"';
        } else {
            oss << s;
        }

        if (i + 1 < fields.size()) {
            oss << ',';
        }
    }

    return oss.str();
}

static void load_csv_strict(const std::string& path, CSV& csv) {
    std::ifstream fin(path);

    if (!fin.is_open()) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: cannot open CSV: " << path;
        fatal(ss.str());
    }

    std::string line;

    if (!std::getline(fin, line)) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: empty CSV: " << path;
        fatal(ss.str());
    }

    csv.header = split_csv_line(line);
    csv.index.clear();

    for (int i = 0; i < (int)csv.header.size(); ++i) {
        const std::string& name = csv.header[(size_t)i];

        if (csv.index.find(name) != csv.index.end()) {
            std::ostringstream ss;
            ss << "[acceptance] FATAL: duplicate CSV column: " << name;
            fatal(ss.str());
        }

        csv.index[name] = i;
    }

    csv.rows.clear();

    while (std::getline(fin, line)) {
        if (line.empty()) {
            continue;
        }

        std::vector<std::string> row = split_csv_line(line);

        if (row.size() < csv.header.size()) {
            row.resize(csv.header.size(), "");
        }

        if (row.size() != csv.header.size()) {
            std::ostringstream ss;
            ss << "[acceptance] FATAL: CSV row width mismatch in " << path
               << ". Row has " << row.size()
               << " cells, header has " << csv.header.size() << ".";
            fatal(ss.str());
        }

        csv.rows.push_back(std::move(row));
    }
}

static void write_csv_atomic(const std::string& path, const CSV& csv) {
    const std::string tmp = path + ".tmp";

    {
        std::ofstream fout(tmp);

        if (!fout.is_open()) {
            std::ostringstream ss;
            ss << "[acceptance] FATAL: cannot write temporary CSV: " << tmp;
            fatal(ss.str());
        }

        fout << join_csv_row(csv.header) << "\n";

        for (const auto& row : csv.rows) {
            if (row.size() != csv.header.size()) {
                std::ostringstream ss;
                ss << "[acceptance] FATAL: row width mismatch during write.";
                fatal(ss.str());
            }

            fout << join_csv_row(row) << "\n";
        }

        fout.close();

        if (!fout) {
            std::ostringstream ss;
            ss << "[acceptance] FATAL: failed writing temporary CSV: " << tmp;
            fatal(ss.str());
        }
    }

    std::error_code ec;
    std::filesystem::rename(tmp, path, ec);

    if (ec) {
        std::remove(path.c_str());
        std::filesystem::rename(tmp, path, ec);

        if (ec) {
            std::ostringstream ss;
            ss << "[acceptance] FATAL: atomic rename failed from "
               << tmp << " to " << path << ": " << ec.message();
            fatal(ss.str());
        }
    }
}

static int col_strict(const CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);

    if (it == csv.index.end()) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: missing required CSV column: " << name;
        fatal(ss.str());
    }

    return it->second;
}

static bool parse_first_number(const std::string& s, double& value) {
    value = std::numeric_limits<double>::quiet_NaN();

    if (s.empty()) {
        return false;
    }

    size_t i = 0;

    while (i < s.size()) {
        const char c = s[i];

        const bool maybe_start =
            (c >= '0' && c <= '9') ||
            c == '-' ||
            c == '+' ||
            c == '.';

        if (maybe_start) {
            break;
        }

        ++i;
    }

    if (i >= s.size()) {
        return false;
    }

    char* endp = nullptr;
    value = std::strtod(s.c_str() + i, &endp);

    if (endp == s.c_str() + i) {
        value = std::numeric_limits<double>::quiet_NaN();
        return false;
    }

    return std::isfinite(value);
}

struct CellTriple {
    double value = 0.0;
    double stat = 0.0;
    double sys = 0.0;
};

static inline void skip_tuple_delimiters(const char*& p) {
    while (*p != '\0' &&
           (*p == ' ' || *p == '\t' || *p == '(' || *p == ')' || *p == '"')) {
        ++p;
    }
}

// Parse the fixed CSV tuple format directly, without allocating a temporary
// string, stringstream, token strings, or vector for every cell.
static bool parse_cell_triple(const std::string& s, CellTriple& out) {
    if (s.empty()) {
        return false;
    }

    const char* p = s.c_str();
    char* endp = nullptr;

    skip_tuple_delimiters(p);
    out.value = std::strtod(p, &endp);
    if (endp == p) {
        return false;
    }
    p = endp;

    skip_tuple_delimiters(p);
    if (*p != ',') {
        return false;
    }
    ++p;

    skip_tuple_delimiters(p);
    out.stat = std::strtod(p, &endp);
    if (endp == p) {
        return false;
    }
    p = endp;

    skip_tuple_delimiters(p);
    if (*p != ',') {
        return false;
    }
    ++p;

    skip_tuple_delimiters(p);
    out.sys = std::strtod(p, &endp);
    if (endp == p) {
        return false;
    }

    return true;
}

static CellTriple cell_triple_or_zero(const CSV& csv, int row, int col, const std::string& label) {
    CellTriple out;

    if (row < 0 || row >= (int)csv.rows.size()) {
        return out;
    }

    if (col < 0 || col >= (int)csv.header.size()) {
        return out;
    }

    const std::string& cell = csv.rows[(size_t)row][(size_t)col];
    if (cell.empty()) {
        return out;
    }

    if (!parse_cell_triple(cell, out)) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: expected tuple (value,stat,sys) for "
           << label << ", got '" << cell << "'.";
        fatal(ss.str());
    }

    if (!std::isfinite(out.value) || !std::isfinite(out.stat) || !std::isfinite(out.sys) ||
        out.stat < 0.0 || out.sys < 0.0) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: invalid tuple for " << label
           << ": '" << cell << "'.";
        fatal(ss.str());
    }

    return out;
}

static void add_cell_triple(CellTriple& total, const CellTriple& x) {
    total.value += x.value;
    total.stat = std::sqrt(total.stat * total.stat + x.stat * x.stat);
    total.sys = std::sqrt(total.sys * total.sys + x.sys * x.sys);
}

static double cell_value_strict(const CSV& csv,
                                int row,
                                int col,
                                const std::string& label) {
    if (row < 0 || row >= (int)csv.rows.size()) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: row index out of range for " << label;
        fatal(ss.str());
    }

    if (col < 0 || col >= (int)csv.header.size()) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: column index out of range for " << label;
        fatal(ss.str());
    }

    double v = 0.0;

    if (!parse_first_number(csv.rows[(size_t)row][(size_t)col], v)) {
        std::ostringstream ss;
        ss << "[acceptance] FATAL: cannot parse numeric cell for " << label
           << " from value '" << csv.rows[(size_t)row][(size_t)col] << "'";
        fatal(ss.str());
    }

    return v;
}

static std::string triple_string(double value, double stat, double sys) {
    std::ostringstream ss;
    ss << std::setprecision(12)
       << "(" << value << "," << stat << "," << sys << ")";
    return ss.str();
}

// -----------------------------------------------------------------------------
// Column naming
// -----------------------------------------------------------------------------

static std::string col_generated(const std::string& period) {
    std::ostringstream ss;
    ss << "generated yield, ep->epg, mc, " << period;
    return ss.str();
}

static std::string col_reconstructed_current_corrected(const std::string& topo,
                                                       const std::string& period) {
    std::ostringstream ss;
    ss << "reconstructed current corrected yield, ep->epg, "
       << topo << ", mc, " << period;
    return ss.str();
}

static std::string col_acceptance(const std::string& period) {
    std::ostringstream ss;
    ss << "acceptance, " << period;
    return ss.str();
}

static std::string col_phiavg(const std::string& period) {
    std::ostringstream ss;
    ss << "phiavg, " << period;
    return ss.str();
}

static std::string col_xBavg(const std::string& period) {
    std::ostringstream ss;
    ss << "xBavg, " << period;
    return ss.str();
}

// -----------------------------------------------------------------------------
// Row bins and computed acceptance
// -----------------------------------------------------------------------------

struct RowBin {
    double xBmin = std::numeric_limits<double>::quiet_NaN();
    double xBmax = std::numeric_limits<double>::quiet_NaN();

    double Q2min = std::numeric_limits<double>::quiet_NaN();
    double Q2max = std::numeric_limits<double>::quiet_NaN();

    double tmin = std::numeric_limits<double>::quiet_NaN();
    double tmax = std::numeric_limits<double>::quiet_NaN();

    double phimin = std::numeric_limits<double>::quiet_NaN();
    double phimax = std::numeric_limits<double>::quiet_NaN();

    bool valid = false;
};

struct AcceptancePoint {
    double value = std::numeric_limits<double>::quiet_NaN();
    double stat = std::numeric_limits<double>::quiet_NaN();
    double sys = 0.0;

    double n_gen = 0.0;
    double n_rec = 0.0;
};

static bool valid_cell_to_bool(const std::string& s) {
    return s == "1" || s == "1.0" || s == "true" || s == "TRUE";
}

static std::vector<RowBin> load_row_bins(const CSV& csv) {
    const int c_xBmin = col_strict(csv, "xBmin");
    const int c_xBmax = col_strict(csv, "xBmax");
    const int c_Q2min = col_strict(csv, "Q2min");
    const int c_Q2max = col_strict(csv, "Q2max");
    const int c_tmin = col_strict(csv, "t_abs_min");
    const int c_tmax = col_strict(csv, "t_abs_max");
    const int c_phimin = col_strict(csv, "phimin");
    const int c_phimax = col_strict(csv, "phimax");
    const int c_valid = col_strict(csv, "valid bin");

    std::vector<RowBin> out;
    out.reserve(csv.rows.size());

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        RowBin b;

        b.xBmin = cell_value_strict(csv, r, c_xBmin, "xBmin");
        b.xBmax = cell_value_strict(csv, r, c_xBmax, "xBmax");
        b.Q2min = cell_value_strict(csv, r, c_Q2min, "Q2min");
        b.Q2max = cell_value_strict(csv, r, c_Q2max, "Q2max");
        b.tmin = cell_value_strict(csv, r, c_tmin, "t_abs_min");
        b.tmax = cell_value_strict(csv, r, c_tmax, "t_abs_max");
        b.phimin = cell_value_strict(csv, r, c_phimin, "phimin");
        b.phimax = cell_value_strict(csv, r, c_phimax, "phimax");
        b.valid = valid_cell_to_bool(csv.rows[(size_t)r][(size_t)c_valid]);

        out.push_back(b);
    }

    return out;
}

static double bin_center(double a, double b) {
    return 0.5 * (a + b);
}

static double wrap_phi_deg(double phi) {
    double x = std::fmod(phi, 360.0);

    if (x < 0.0) {
        x += 360.0;
    }

    if (x >= 360.0) {
        x = std::nextafter(360.0, 0.0);
    }

    return x;
}

static double ratio_stat(double numerator,
                         double numerator_stat,
                         double denominator,
                         double denominator_stat) {
    if (!is_finite_positive(denominator) || !is_finite_nonnegative(numerator)) {
        return 0.0;
    }

    const double var = (numerator_stat * numerator_stat) / (denominator * denominator) +
                       (numerator * numerator * denominator_stat * denominator_stat) /
                       (denominator * denominator * denominator * denominator);

    return (var > 0.0) ? std::sqrt(var) : 0.0;
}

static std::vector<AcceptancePoint> compute_acceptance_for_period(CSV& csv,
                                                                  const std::string& period) {
    const std::string generated_name = col_generated(period);
    const int c_gen = col_strict(csv, generated_name);
    const int c_acc = col_strict(csv, col_acceptance(period));
    (void)c_acc;

    std::vector<int> rec_cols;
    std::vector<std::string> rec_names;
    rec_cols.reserve(topologies().size());
    rec_names.reserve(topologies().size());

    for (const auto& topo : topologies()) {
        rec_names.push_back(col_reconstructed_current_corrected(topo, period));
        rec_cols.push_back(col_strict(csv, rec_names.back()));
    }

    std::vector<AcceptancePoint> out;
    out.resize(csv.rows.size());

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        const CellTriple gen = cell_triple_or_zero(csv, r, c_gen, generated_name);

        CellTriple rec;
        rec.value = 0.0;
        rec.stat = 0.0;
        rec.sys = 0.0;

        for (size_t i = 0; i < rec_cols.size(); ++i) {
            add_cell_triple(rec,
                            cell_triple_or_zero(csv,
                                                r,
                                                rec_cols[i],
                                                rec_names[i]));
        }

        AcceptancePoint p;
        p.n_gen = gen.value;
        p.n_rec = rec.value;

        // The Krishna Neupane proton-efficiency correction is deliberately
        // NOT folded into the MC acceptance.  total_counts.cpp already applies
        // 1/E_C event by event to DATA.  Applying E_C here as well would
        // double-correct the extracted cross section.
        if (is_finite_positive(gen.value) && is_finite_nonnegative(rec.value)) {
            p.value = rec.value / gen.value;
            p.stat = ratio_stat(rec.value, rec.stat, gen.value, gen.stat);
            p.sys = 0.0; // acceptance systematic is assigned separately
        } else {
            p.value = 0.0;
            p.stat = 0.0;
            p.sys = 0.0;
        }

        out[(size_t)r] = p;
    }

    return out;
}

static void write_acceptance_to_csv(CSV& csv,
                                    const std::string& period,
                                    const std::vector<AcceptancePoint>& acc) {
    const int c_acc = col_strict(csv, col_acceptance(period));

    if (acc.size() != csv.rows.size()) {
        fatal("[acceptance] FATAL: acceptance vector size does not match CSV rows.");
    }

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        const AcceptancePoint& p = acc[(size_t)r];
        csv.rows[(size_t)r][(size_t)c_acc] = triple_string(p.value, p.stat, p.sys);
    }
}

// -----------------------------------------------------------------------------
// Plotting
// -----------------------------------------------------------------------------

struct Edge {
    double a = 0.0;
    double b = 0.0;
};

static bool same_edge(const Edge& x, const Edge& y) {
    return x.a == y.a && x.b == y.b;
}

static void add_unique_edge(std::vector<Edge>& edges, const Edge& e) {
    auto it = std::find_if(edges.begin(), edges.end(), [&](const Edge& z) {
        return same_edge(e, z);
    });

    if (it == edges.end()) {
        edges.push_back(e);
    }
}

static int find_edge_index(const std::vector<Edge>& edges, const Edge& e) {
    for (int i = 0; i < (int)edges.size(); ++i) {
        if (same_edge(edges[(size_t)i], e)) {
            return i;
        }
    }

    return -1;
}

static std::vector<Edge> unique_xB_edges(const std::vector<RowBin>& rows) {
    std::vector<Edge> out;

    for (const RowBin& r : rows) {
        if (!r.valid) {
            continue;
        }

        add_unique_edge(out, Edge{r.xBmin, r.xBmax});
    }

    std::sort(out.begin(), out.end(), [](const Edge& a, const Edge& b) {
        if (a.a != b.a) return a.a < b.a;
        return a.b < b.b;
    });

    return out;
}

static double phi_x_value(const CSV& csv,
                          const RowBin& rowbin,
                          int row_index,
                          int c_phiavg) {
    if (c_phiavg >= 0) {
        double v = 0.0;

        if (parse_first_number(csv.rows[(size_t)row_index][(size_t)c_phiavg], v)) {
            return wrap_phi_deg(v);
        }
    }

    return wrap_phi_deg(bin_center(rowbin.phimin, rowbin.phimax));
}

static std::string xB_label_for_canvas(const CSV& csv,
                                       const std::vector<RowBin>& rows,
                                       const std::vector<int>& row_indices,
                                       const std::string& period,
                                       const Edge& xb) {
    const int c_xBavg = csv.index.count(col_xBavg(period)) ? csv.index.at(col_xBavg(period)) : -1;

    if (c_xBavg >= 0) {
        for (int r : row_indices) {
            double v = 0.0;

            if (parse_first_number(csv.rows[(size_t)r][(size_t)c_xBavg], v)) {
                std::ostringstream ss;
                ss << "x_{B}=" << std::fixed << std::setprecision(3) << v;
                return ss.str();
            }
        }
    }

    (void)rows;

    std::ostringstream ss;
    ss << "x_{B} in [" << std::fixed << std::setprecision(2) << xb.a
       << "," << std::fixed << std::setprecision(2) << xb.b << ")";
    return ss.str();
}

static void plot_acceptance_for_period(const CSV& csv,
                                       const std::vector<RowBin>& rows,
                                       const std::string& period,
                                       const std::vector<AcceptancePoint>& acc,
                                       const std::string& out_root_dir) {
    const std::string outdir =
        out_root_dir + "/acceptance/" + canonical_period_dir(period);

    mkdir_p(outdir);

    const std::vector<Edge> xbs = unique_xB_edges(rows);
    const int c_phiavg = csv.index.count(col_phiavg(period)) ? csv.index.at(col_phiavg(period)) : -1;

    for (const Edge& xb : xbs) {
        std::vector<int> row_indices;
        std::vector<Edge> q_edges;
        std::vector<Edge> t_edges;

        for (int r = 0; r < (int)rows.size(); ++r) {
            const RowBin& rb = rows[(size_t)r];

            if (!rb.valid) {
                continue;
            }

            if (!(rb.xBmin == xb.a && rb.xBmax == xb.b)) {
                continue;
            }

            row_indices.push_back(r);
            add_unique_edge(q_edges, Edge{rb.Q2min, rb.Q2max});
            add_unique_edge(t_edges, Edge{rb.tmin, rb.tmax});
        }

        if (row_indices.empty()) {
            continue;
        }

        std::sort(q_edges.begin(), q_edges.end(), [](const Edge& a, const Edge& b) {
            if (a.a != b.a) return a.a < b.a;
            return a.b < b.b;
        });

        std::sort(t_edges.begin(), t_edges.end(), [](const Edge& a, const Edge& b) {
            if (a.a != b.a) return a.a < b.a;
            return a.b < b.b;
        });

        const int ncols = (int)q_edges.size();
        const int nrows = (int)t_edges.size();

        if (ncols <= 0 || nrows <= 0) {
            continue;
        }

        const int W = 300 * ncols + 160;
        const int H = 260 * nrows + 240;

        TCanvas c("c_acceptance", "", W, H);

        TPad* top = new TPad("top", "top", 0.0, 0.90, 1.0, 1.0);
        TPad* grid = new TPad("grid", "grid", 0.0, 0.0, 1.0, 0.90);

        top->SetFillStyle(0);
        grid->SetFillStyle(0);

        top->Draw();
        grid->Draw();

        top->cd();

        TLatex title;
        title.SetNDC(true);
        title.SetTextFont(42);
        title.SetTextSize(0.45);

        const std::string xb_text =
            xB_label_for_canvas(csv, rows, row_indices, period, xb);

        {
            std::ostringstream ss;
            ss << "Acceptance   " << period << "   " << xb_text;
            title.DrawLatex(0.05, 0.35, ss.str().c_str());
        }

        grid->cd();
        grid->Divide(ncols, nrows, 0.0, 0.0);

        for (int it = 0; it < nrows; ++it) {
            for (int iq = 0; iq < ncols; ++iq) {
                const int pad_index = it * ncols + iq + 1;
                grid->cd(pad_index);

                gPad->SetLeftMargin(0.160);
                gPad->SetRightMargin(0.07);
                gPad->SetTopMargin(0.22);
                gPad->SetBottomMargin(0.18);
                gPad->SetGrid(1, 1);
                gPad->SetTickx(1);
                gPad->SetTicky(1);

                std::vector<std::pair<double, AcceptancePoint>> points;

                for (int r : row_indices) {
                    const RowBin& rb = rows[(size_t)r];

                    const int q_idx = find_edge_index(q_edges, Edge{rb.Q2min, rb.Q2max});
                    const int t_idx = find_edge_index(t_edges, Edge{rb.tmin, rb.tmax});

                    if (q_idx != iq || t_idx != it) {
                        continue;
                    }

                    const double x = phi_x_value(csv, rb, r, c_phiavg);
                    points.push_back(std::make_pair(x, acc[(size_t)r]));
                }

                std::sort(points.begin(), points.end(),
                          [](const std::pair<double, AcceptancePoint>& a,
                             const std::pair<double, AcceptancePoint>& b) {
                              return a.first < b.first;
                          });

                TGraphErrors* g = new TGraphErrors();

                double ymax = 0.0;

                for (int i = 0; i < (int)points.size(); ++i) {
                    const double x = points[(size_t)i].first;
                    const AcceptancePoint& p = points[(size_t)i].second;

                    g->SetPoint(i, x, p.value);
                    g->SetPointError(i, 0.0, p.stat);

                    ymax = std::max(ymax, p.value + p.stat);
                }

                if (!(ymax > 0.0)) {
                    ymax = 1.0;
                }

                TH1F* frame = (TH1F*)gPad->DrawFrame(0.0, 0.0, 360.0, 1.20 * ymax);
                frame->SetTitle("");
                frame->GetXaxis()->SetTitle("#phi (deg)");
                frame->GetYaxis()->SetTitle("Acceptance");
                frame->GetXaxis()->CenterTitle(true);
                frame->GetYaxis()->CenterTitle(true);
                frame->GetXaxis()->SetNdivisions(505);
                frame->GetXaxis()->SetLabelSize(0.060);
                frame->GetYaxis()->SetLabelSize(0.060);
                frame->GetXaxis()->SetTitleSize(0.070);
                frame->GetYaxis()->SetTitleSize(0.070);
                frame->GetXaxis()->SetTitleOffset(1.05);
                frame->GetYaxis()->SetTitleOffset(1.10);

                g->SetMarkerStyle(20);
                g->SetMarkerSize(0.8);
                g->SetMarkerColor(kBlack);
                g->SetLineColor(kBlack);
                g->SetLineWidth(1);
                g->Draw("PE1 SAME");

                TLatex txt;
                txt.SetNDC(true);
                txt.SetTextFont(42);
                txt.SetTextSize(0.060);

                {
                    std::ostringstream ss;
                    ss << "Q^{2}=" << std::fixed << std::setprecision(2)
                       << bin_center(q_edges[(size_t)iq].a, q_edges[(size_t)iq].b)
                       << "  |t|=" << std::fixed << std::setprecision(2)
                       << bin_center(t_edges[(size_t)it].a, t_edges[(size_t)it].b);
                    txt.DrawLatex(0.12, 0.83, ss.str().c_str());
                }
            }
        }

        const int idx = (int)std::llround(xb.a * 1000.0);

        std::ostringstream fname;
        fname << outdir << "/acceptance_"
              << canonical_period_dir(period)
              << "_xB_" << idx << ".png";

        c.SaveAs(fname.str().c_str());

        delete top;
        delete grid;
    }
}


// -----------------------------------------------------------------------------
// Analysis-note summary outputs
// -----------------------------------------------------------------------------

static int note_period_color(int ip) {
    const int colors[5] = {kBlue+1, kRed+1, kGreen+2, kMagenta+1, kOrange+7};
    return colors[ip];
}

static double note_quantile_sorted(const std::vector<double>& v, double q) {
    if (v.empty()) return std::numeric_limits<double>::quiet_NaN();
    if (q <= 0.0) return v.front();
    if (q >= 1.0) return v.back();
    const double x = q * (double)(v.size() - 1);
    const size_t i0 = (size_t)std::floor(x);
    const size_t i1 = std::min(i0 + 1, v.size() - 1);
    const double f = x - (double)i0;
    return v[i0] * (1.0 - f) + v[i1] * f;
}

static std::vector<double> note_acceptance_values(const std::vector<RowBin>& rows,
                                                   const std::vector<AcceptancePoint>& acc) {
    std::vector<double> v;
    for (size_t i=0;i<rows.size() && i<acc.size();++i) {
        if (!rows[i].valid) continue;
        if (std::isfinite(acc[i].value) && acc[i].value > 0.0) v.push_back(acc[i].value);
    }
    std::sort(v.begin(), v.end());
    return v;
}

static void write_acceptance_note_summary(const std::vector<RowBin>& rows,
                                          const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
                                          const std::string& note_dir) {
    std::ofstream f(note_dir + "/acceptance_summary.csv");
    f << "period,n_populated,mean,median,p16,p84,p05,p95,median_relative_stat,p84_relative_stat\n";
    f << std::setprecision(10);
    for (const auto& per : periods()) {
        const auto& a = by_period.at(per);
        std::vector<double> v = note_acceptance_values(rows,a);
        std::vector<double> rel;
        double sum=0.0;
        for (size_t i=0;i<rows.size() && i<a.size();++i) {
            if (!rows[i].valid || !(a[i].value>0.0) || !std::isfinite(a[i].value)) continue;
            sum += a[i].value;
            if (std::isfinite(a[i].stat) && a[i].stat>=0.0) rel.push_back(a[i].stat/a[i].value);
        }
        std::sort(rel.begin(),rel.end());
        const double mean = v.empty()?0.0:sum/(double)v.size();
        f << per << ',' << v.size() << ',' << mean << ','
          << note_quantile_sorted(v,.50) << ',' << note_quantile_sorted(v,.16) << ','
          << note_quantile_sorted(v,.84) << ',' << note_quantile_sorted(v,.05) << ','
          << note_quantile_sorted(v,.95) << ',' << note_quantile_sorted(rel,.50) << ','
          << note_quantile_sorted(rel,.84) << '\n';
    }
}

static void draw_acceptance_note_period_summary(
    const std::vector<RowBin>& rows,
    const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
    const std::string& note_dir) {

    TCanvas c("c_note_acc_period","",1100,700);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.16); c.SetTopMargin(0.10);
    c.SetGridy(); c.SetTicks(1,1);

    TH1F frame("h_note_acc_period","",5,0.5,5.5);
    frame.SetMinimum(0.0); frame.SetMaximum(0.30);
    frame.GetYaxis()->SetTitle("Acceptance");
    frame.GetYaxis()->SetTitleOffset(1.10);
    frame.GetYaxis()->SetTitleSize(0.050);
    frame.GetXaxis()->SetLabelSize(0.043);
    for (int ip=0;ip<5;++ip) frame.GetXaxis()->SetBinLabel(ip+1,periods()[ip].c_str());
    frame.Draw();

    std::vector<TGraphAsymmErrors*> gs;
    for (int ip=0;ip<5;++ip) {
        std::vector<double> v=note_acceptance_values(rows,by_period.at(periods()[ip]));
        if (v.empty()) { gs.push_back(nullptr); continue; }
        const double med=note_quantile_sorted(v,.50), lo=note_quantile_sorted(v,.16), hi=note_quantile_sorted(v,.84);
        auto* g=new TGraphAsymmErrors(1);
        g->SetPoint(0,ip+1,med);
        g->SetPointError(0,0,0,med-lo,hi-med);
        g->SetMarkerStyle(20); g->SetMarkerSize(1.35);
        g->SetMarkerColor(note_period_color(ip)); g->SetLineColor(note_period_color(ip)); g->SetLineWidth(2);
        g->Draw("PE SAME");
        gs.push_back(g);
    }

    TLatex t; t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048);
    t.DrawLatex(0.11,0.93,"Acceptance by run period");
    TLatex n; n.SetNDC(); n.SetTextFont(42); n.SetTextSize(0.030);
    n.DrawLatex(0.12,0.84,"Points: median over populated analysis bins; bars: 16th--84th percentile bin-to-bin range");
    c.SaveAs((note_dir+"/acceptance_period_summary.png").c_str());
    for(auto* g:gs) delete g;
}

static void draw_acceptance_note_distribution(
    const std::vector<RowBin>& rows,
    const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
    const std::string& note_dir) {

    TCanvas c("c_note_acc_dist","",1100,700);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10);
    c.SetTicks(1,1);
    std::vector<TH1D*> hs;
    double ymax=0.0;
    for (int ip=0;ip<5;++ip) {
        auto* h=new TH1D(Form("h_note_acc_dist_%d",ip),"",50,0.0,0.50);
        for (double x:note_acceptance_values(rows,by_period.at(periods()[ip]))) if (x<0.50) h->Fill(x);
        if (h->Integral()>0) h->Scale(1.0/h->Integral());
        h->SetLineColor(note_period_color(ip)); h->SetMarkerColor(note_period_color(ip));
        h->SetMarkerStyle(20+ip); h->SetMarkerSize(0.75); h->SetLineWidth(2);
        ymax=std::max(ymax,h->GetMaximum()); hs.push_back(h);
    }
    TH1F frame("h_note_acc_dist_frame","",100,0.0,0.50);
    frame.SetMinimum(0.0); frame.SetMaximum(1.20*ymax);
    frame.GetXaxis()->SetTitle("Acceptance");
    frame.GetYaxis()->SetTitle("Fraction of populated analysis bins");
    frame.GetYaxis()->SetTitleOffset(1.15); frame.Draw();
    for(auto* h:hs) h->Draw("PE SAME");
    TLegend leg(0.72,0.60,0.94,0.86); leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.036);
    for(int ip=0;ip<5;++ip) leg.AddEntry(hs[ip],periods()[ip].c_str(),"pe"); leg.Draw();
    TLatex t; t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048);
    t.DrawLatex(0.11,0.93,"Distribution of bin-by-bin acceptance");
    TLatex n; n.SetNDC(); n.SetTextFont(42); n.SetTextSize(0.030);
    n.DrawLatex(0.12,0.84,"Shown: 0 < A < 0.50; all finite positive values are retained in the numerical summary");
    c.SaveAs((note_dir+"/acceptance_distribution_by_period.png").c_str());
    for(auto* h:hs) delete h;
}

static void draw_acceptance_note_xb_summary(
    const std::vector<RowBin>& rows,
    const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
    const std::string& note_dir) {

    const std::vector<Edge> xbs=unique_xB_edges(rows);
    TCanvas c("c_note_acc_xb","",1100,720);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10);
    c.SetGridy(); c.SetTicks(1,1);
    TH1F frame("h_note_acc_xb","",100,0.05,0.60);
    frame.SetMinimum(0.0); frame.SetMaximum(0.30);
    frame.GetXaxis()->SetTitle("x_{B}"); frame.GetYaxis()->SetTitle("Median acceptance");
    frame.GetYaxis()->SetTitleOffset(1.15); frame.Draw();
    const double offsets[5]={-0.006,-0.003,0.0,0.003,0.006};
    std::vector<TGraphAsymmErrors*> gs;
    for(int ip=0;ip<5;++ip){
        auto* g=new TGraphAsymmErrors(); int n=0;
        const auto& av=by_period.at(periods()[ip]);
        for(const auto& xb:xbs){
            std::vector<double> v;
            for(size_t r=0;r<rows.size() && r<av.size();++r){
                if(!rows[r].valid || rows[r].xBmin!=xb.a || rows[r].xBmax!=xb.b) continue;
                if(std::isfinite(av[r].value) && av[r].value>0.0) v.push_back(av[r].value);
            }
            if(v.empty()) continue; std::sort(v.begin(),v.end());
            const double med=note_quantile_sorted(v,.50), lo=note_quantile_sorted(v,.16), hi=note_quantile_sorted(v,.84);
            g->SetPoint(n,0.5*(xb.a+xb.b)+offsets[ip],med);
            g->SetPointError(n,0,0,med-lo,hi-med); ++n;
        }
        g->SetMarkerStyle(20+ip); g->SetMarkerSize(1.05); g->SetLineWidth(2);
        g->SetMarkerColor(note_period_color(ip)); g->SetLineColor(note_period_color(ip));
        g->Draw("PE SAME"); gs.push_back(g);
    }
    TLegend leg(0.71,0.60,0.94,0.86); leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.036);
    for(int ip=0;ip<5;++ip) leg.AddEntry(gs[ip],periods()[ip].c_str(),"pe"); leg.Draw();
    TLatex t; t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048);
    t.DrawLatex(0.11,0.93,"Kinematic dependence of the DVCS acceptance");
    TLatex n; n.SetNDC(); n.SetTextFont(42); n.SetTextSize(0.029);
    n.DrawLatex(0.12,0.84,"Points: median over populated (Q^{2}, |t|, #phi) bins; bars: 16th--84th percentile bin-to-bin range");
    c.SaveAs((note_dir+"/acceptance_vs_xB_summary.png").c_str());
    for(auto* g:gs) delete g;
}

static void draw_acceptance_note_phi_example(
    const CSV& csv,
    const std::vector<RowBin>& rows,
    const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
    const std::string& note_dir) {

    const double tx0=0.204, tx1=0.268;
    struct Key{double q0,q1,t0,t1;}; std::vector<Key> keys;
    for(const auto& b:rows){
        if(!b.valid || b.xBmin!=tx0 || b.xBmax!=tx1) continue;
        bool seen=false; for(const auto& k:keys) if(k.q0==b.Q2min&&k.q1==b.Q2max&&k.t0==b.tmin&&k.t1==b.tmax){seen=true;break;}
        if(!seen) keys.push_back(Key{b.Q2min,b.Q2max,b.tmin,b.tmax});
    }
    if(keys.empty()) return;
    int best=-1,totalbest=-1; Key sel=keys.front();
    for(const auto& k:keys){
        int mn=100000,total=0;
        for(int ip=0;ip<5;++ip){ int n=0; const auto& a=by_period.at(periods()[ip]);
            for(size_t r=0;r<rows.size();++r) if(rows[r].valid&&rows[r].xBmin==tx0&&rows[r].xBmax==tx1&&rows[r].Q2min==k.q0&&rows[r].Q2max==k.q1&&rows[r].tmin==k.t0&&rows[r].tmax==k.t1&&a[r].value>0) ++n;
            mn=std::min(mn,n); total+=n;
        }
        if(mn>best || (mn==best&&total>totalbest)){best=mn;totalbest=total;sel=k;}
    }
    std::ofstream fout(note_dir+"/acceptance_phi_example.csv");
    fout<<"period,xBmin,xBmax,Q2min,Q2max,tmin,tmax,phimin,phimax,phi,acceptance,stat\n"<<std::setprecision(10);
    TCanvas c("c_note_acc_phi","",1100,720); c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10); c.SetGridy(); c.SetTicks(1,1);
    double ymax=0.0; for(int ip=0;ip<5;++ip){ const auto& a=by_period.at(periods()[ip]); for(size_t r=0;r<rows.size();++r) if(rows[r].valid&&rows[r].xBmin==tx0&&rows[r].xBmax==tx1&&rows[r].Q2min==sel.q0&&rows[r].Q2max==sel.q1&&rows[r].tmin==sel.t0&&rows[r].tmax==sel.t1) ymax=std::max(ymax,a[r].value+a[r].stat); }
    TH1F frame("h_note_acc_phi","",100,0,360); frame.SetMinimum(0); frame.SetMaximum(std::max(0.12,1.22*ymax)); frame.GetXaxis()->SetTitle("#phi (deg)"); frame.GetYaxis()->SetTitle("Acceptance"); frame.GetYaxis()->SetTitleOffset(1.15); frame.Draw();
    const double off[5]={-2,-1,0,1,2}; std::vector<TGraphErrors*> gs;
    for(int ip=0;ip<5;++ip){ auto* g=new TGraphErrors(); int n=0; const auto& a=by_period.at(periods()[ip]); int cp=csv.index.count(col_phiavg(periods()[ip]))?csv.index.at(col_phiavg(periods()[ip])):-1;
        for(size_t r=0;r<rows.size();++r){ const auto& b=rows[r]; if(!b.valid||b.xBmin!=tx0||b.xBmax!=tx1||b.Q2min!=sel.q0||b.Q2max!=sel.q1||b.tmin!=sel.t0||b.tmax!=sel.t1||!(a[r].value>0)) continue; double phi=phi_x_value(csv,b,(int)r,cp); g->SetPoint(n,phi+off[ip],a[r].value); g->SetPointError(n,0,a[r].stat); fout<<periods()[ip]<<','<<tx0<<','<<tx1<<','<<sel.q0<<','<<sel.q1<<','<<sel.t0<<','<<sel.t1<<','<<b.phimin<<','<<b.phimax<<','<<phi<<','<<a[r].value<<','<<a[r].stat<<'\n'; ++n; }
        g->SetMarkerStyle(20+ip);g->SetMarkerSize(1.05);g->SetLineWidth(2);g->SetMarkerColor(note_period_color(ip));g->SetLineColor(note_period_color(ip));g->Draw("PE SAME");gs.push_back(g);
    }
    TLegend leg(0.70,0.60,0.94,0.86);leg.SetBorderSize(0);leg.SetFillStyle(0);leg.SetTextSize(0.036);for(int ip=0;ip<5;++ip)leg.AddEntry(gs[ip],periods()[ip].c_str(),"pe");leg.Draw();
    TLatex t;t.SetNDC();t.SetTextFont(42);t.SetTextSize(0.048);t.DrawLatex(0.11,0.93,"Representative #phi dependence of the DVCS acceptance");
    std::ostringstream kin;kin<<std::fixed<<std::setprecision(3)<<tx0<<" < x_{B} < "<<tx1<<",  "<<sel.q0<<" < Q^{2} < "<<sel.q1<<" GeV^{2},  "<<sel.t0<<" < |t| < "<<sel.t1<<" GeV^{2}";
    TLatex lab;lab.SetNDC();lab.SetTextFont(42);lab.SetTextSize(0.028);lab.DrawLatex(0.12,0.84,kin.str().c_str());
    c.SaveAs((note_dir+"/acceptance_phi_example.png").c_str()); for(auto* g:gs)delete g;
}

static void write_acceptance_analysis_note_outputs(
    const CSV& csv,
    const std::vector<RowBin>& rows,
    const std::map<std::string,std::vector<AcceptancePoint>>& by_period,
    const std::string& out_root_dir) {
    const std::string note_dir=out_root_dir+"/acceptance/analysis_note"; mkdir_p(note_dir);
    write_acceptance_note_summary(rows,by_period,note_dir);
    draw_acceptance_note_period_summary(rows,by_period,note_dir);
    draw_acceptance_note_distribution(rows,by_period,note_dir);
    draw_acceptance_note_xb_summary(rows,by_period,note_dir);
    draw_acceptance_note_phi_example(csv,rows,by_period,note_dir);
}

} // namespace

bool update_acceptance_csv(const std::string& csv_path,
                           const std::map<std::string, TTree*>& genMcTrees,
                           const std::map<std::string, TTree*>& recMcTrees,
                           const std::string& combined_cuts_json,
                           const std::string& global_cuts_json,
                           const std::string& out_root_dir) {
    (void)genMcTrees;
    (void)recMcTrees;
    (void)combined_cuts_json;
    (void)global_cuts_json;

    try {
        ROOT::EnableThreadSafety();
        TH1::AddDirectory(kFALSE);
        gStyle->SetOptStat(0);

        CSV csv;
        load_csv_strict(csv_path, csv);

        const std::vector<RowBin> rows = load_row_bins(csv);

        std::map<std::string, std::vector<AcceptancePoint>> acc_by_period;

        for (const std::string& period : periods()) {
            std::cout << "[acceptance] Computing CSV-only acceptance for "
                      << period << std::endl;

            std::vector<AcceptancePoint> acc =
                compute_acceptance_for_period(csv, period);

            // Proton-efficiency QA is performed in total_counts.cpp, where
            // the correction is actually evaluated event by event.

            write_acceptance_to_csv(csv, period, acc);
            acc_by_period[period] = std::move(acc);
        }

        write_csv_atomic(csv_path, csv);

        std::cout << "[acceptance] Updated acceptance columns in: "
                  << csv_path << std::endl;

        for (const std::string& period : periods()) {
            plot_acceptance_for_period(csv,
                                       rows,
                                       period,
                                       acc_by_period.at(period),
                                       out_root_dir);
        }

        std::cout << "[acceptance] Acceptance plots written under: "
                  << out_root_dir << "/acceptance" << std::endl;

        write_acceptance_analysis_note_outputs(csv, rows, acc_by_period, out_root_dir);
        std::cout << "[acceptance] Analysis-note summary outputs written under: "
                  << out_root_dir << "/acceptance/analysis_note" << std::endl;

        return true;
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return false;
    }
}