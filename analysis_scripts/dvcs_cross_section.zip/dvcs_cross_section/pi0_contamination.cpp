// pi0_contamination.cpp
// -----------------------------------------------------------------------------
// Pi0 contamination calculation using values already stored in the pass-2 CSV.
//
// This refactored implementation no longer loops over ROOT trees. Earlier
// modules have already filled:
//
//   1) normalized raw data yields for ep->epg and ep->eppi0
//   2) reconstructed current-corrected AAOGEN MC yields for ep->eppi0
//   3) reconstructed current-corrected AAOGEN background yields for
//      ep->eppi0->epg, i.e. generated pi0 events reconstructed as DVCS
//
// Therefore, for each period and each kinematic CSV row, the contamination is
// computed algebraically as:
//
//   c = N_mis * N_pi0_data / (N_pi0_rec_mc * N_dvcs_data)
//
// using topology-summed values. The CSV schema currently has one contamination
// ratio column per period, not one per topology, so the three standard topology
// columns are summed before computing the ratio.
// -----------------------------------------------------------------------------

#include "pi0_contamination.h"
#include "global_cuts.h"

#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TLegend.h>
#include <TLatex.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TH1.h>
#include <TH1F.h>
#include <TH1D.h>
#include <TTree.h>
#include <TLeaf.h>
#include <TAxis.h>
#include <TBranch.h>
#include <TObjArray.h>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

struct Triple {
    double v = 0.0;
    double stat = 0.0;
    double sys = 0.0;
};

struct CSV {
    std::vector<std::string> header;
    std::unordered_map<std::string, int> index;
    std::vector<std::vector<std::string>> rows;
};

struct RowBin {
    double xBmin = 0.0;
    double xBmax = 0.0;
    double Q2min = 0.0;
    double Q2max = 0.0;
    double tmin = 0.0;
    double tmax = 0.0;
    double phimin = 0.0;
    double phimax = 0.0;
    bool valid = false;
};

struct RowContam {
    double phi = 0.0;
    double value = 0.0;
    double stat = 0.0;
    double xBmin = 0.0;
    double xBmax = 0.0;
    double Q2min = 0.0;
    double Q2max = 0.0;
    double tmin = 0.0;
    double tmax = 0.0;
    bool valid = false;
};

static const std::vector<std::string> kPeriods = {
    "Fa18 Inb",
    "Fa18 Out",
    "Sp19 Inb",
    "Sp18 Inb",
    "Sp18 Out"
};

static const std::vector<std::string> kTopologies = {
    "(FD, FD)",
    "(CD, FD)",
    "(CD, FT)"
};

static void fatal(const std::string& msg) {
    throw std::runtime_error(msg);
}

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    cur.reserve(line.size());
    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];

        if (c == '"') {
            if (in_quotes && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }

    out.push_back(cur);
    return out;
}

static std::string join_csv_row(const std::vector<std::string>& fields) {
    std::ostringstream os;

    for (size_t i = 0; i < fields.size(); ++i) {
        const std::string& s = fields[i];
        const bool quote =
            s.find(',') != std::string::npos ||
            s.find('"') != std::string::npos ||
            s.find('\n') != std::string::npos ||
            s.find('\r') != std::string::npos;

        if (quote) {
            os << '"';
            for (char ch : s) {
                if (ch == '"') {
                    os << "\"\"";
                } else {
                    os << ch;
                }
            }
            os << '"';
        } else {
            os << s;
        }

        if (i + 1 < fields.size()) {
            os << ',';
        }
    }

    return os.str();
}

static void load_csv(const std::string& path, CSV& csv) {
    std::ifstream in(path);
    if (!in.is_open()) {
        fatal("[pi0_contamination] FATAL: cannot open CSV: " + path);
    }

    std::string line;
    if (!std::getline(in, line)) {
        fatal("[pi0_contamination] FATAL: empty CSV: " + path);
    }

    csv.header = split_csv_line(line);
    csv.index.clear();

    for (int i = 0; i < (int)csv.header.size(); ++i) {
        const std::string& name = csv.header[i];
        if (csv.index.find(name) != csv.index.end()) {
            fatal("[pi0_contamination] FATAL: duplicate CSV column: " + name);
        }
        csv.index[name] = i;
    }

    csv.rows.clear();
    while (std::getline(in, line)) {
        if (line.empty()) {
            continue;
        }

        std::vector<std::string> row = split_csv_line(line);
        if (row.size() < csv.header.size()) {
            row.resize(csv.header.size(), "");
        }
        if (row.size() != csv.header.size()) {
            fatal("[pi0_contamination] FATAL: CSV row width mismatch while reading: " + path);
        }
        csv.rows.push_back(std::move(row));
    }
}

static void write_csv_atomic(const std::string& path, const CSV& csv) {
    const std::string tmp = path + ".tmp";

    {
        std::ofstream out(tmp);
        if (!out.is_open()) {
            fatal("[pi0_contamination] FATAL: cannot write temp CSV: " + tmp);
        }

        out << join_csv_row(csv.header) << "\n";
        for (const auto& row : csv.rows) {
            out << join_csv_row(row) << "\n";
        }
    }

    (void)std::remove(path.c_str());
    if (std::rename(tmp.c_str(), path.c_str()) != 0) {
        fatal("[pi0_contamination] FATAL: atomic rename failed: " + tmp + " -> " + path);
    }
}

static int col_strict(const CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);
    if (it == csv.index.end()) {
        fatal("[pi0_contamination] FATAL: missing CSV column: " + name);
    }
    return it->second;
}

static bool valid_cell(const std::string& s) {
    return s == "1" || s == "1.0" || s == "true" || s == "TRUE";
}

static double to_double_strict(const std::string& s, const std::string& context) {
    if (s.empty()) {
        fatal("[pi0_contamination] FATAL: empty numeric cell for " + context);
    }

    char* endp = nullptr;
    const double v = std::strtod(s.c_str(), &endp);

    if (endp == s.c_str() || *endp != '\0') {
        fatal("[pi0_contamination] FATAL: cannot parse numeric cell for " + context + ": '" + s + "'");
    }

    return v;
}

static bool parse_tuple_numbers(const std::string& s, std::vector<double>& vals) {
    vals.clear();

    std::string t;
    t.reserve(s.size());
    for (char c : s) {
        if (c == '(' || c == ')' || c == '"') {
            t.push_back(' ');
        } else {
            t.push_back(c);
        }
    }

    std::stringstream ss(t);
    std::string part;

    while (std::getline(ss, part, ',')) {
        char* endp = nullptr;
        const double v = std::strtod(part.c_str(), &endp);
        if (endp == part.c_str()) {
            return false;
        }
        vals.push_back(v);
    }

    return !vals.empty();
}

static Triple parse_yield_or_zero(const std::string& s,
                                  const std::string& context) {
    Triple out;
    out.v = 0.0;
    out.stat = 0.0;
    out.sys = 0.0;

    if (s.empty()) {
        return out;
    }

    std::vector<double> vals;
    if (!parse_tuple_numbers(s, vals) || vals.size() < 3) {
        fatal("[pi0_contamination] FATAL: expected yield triple (value,stat,sys) for " +
              context + ", got '" + s + "'.");
    }

    out.v = vals[0];
    out.stat = vals[1];
    out.sys = vals[2];

    if (!std::isfinite(out.v) || !std::isfinite(out.stat) || !std::isfinite(out.sys) ||
        out.stat < 0.0 || out.sys < 0.0) {
        fatal("[pi0_contamination] FATAL: invalid yield triple for " + context +
              ": '" + s + "'.");
    }

    return out;
}

static void add_triple_in_quadrature(Triple& total, const Triple& x) {
    total.v += x.v;
    total.stat = std::sqrt(total.stat * total.stat + x.stat * x.stat);
    total.sys = std::sqrt(total.sys * total.sys + x.sys * x.sys);
}

static std::string format_triple(const Triple& t) {
    std::ostringstream os;
    os << "("
       << std::fixed << std::setprecision(8) << t.v << ","
       << std::fixed << std::setprecision(8) << t.stat << ","
       << std::fixed << std::setprecision(8) << t.sys
       << ")";
    return os.str();
}

static std::vector<RowBin> load_row_bins(const CSV& csv) {
    const int c_xmin = col_strict(csv, "xBmin");
    const int c_xmax = col_strict(csv, "xBmax");
    const int c_qmin = col_strict(csv, "Q2min");
    const int c_qmax = col_strict(csv, "Q2max");
    const int c_tmin = col_strict(csv, "t_abs_min");
    const int c_tmax = col_strict(csv, "t_abs_max");
    const int c_pmin = col_strict(csv, "phimin");
    const int c_pmax = col_strict(csv, "phimax");
    const int c_valid = col_strict(csv, "valid bin");

    std::vector<RowBin> bins;
    bins.reserve(csv.rows.size());

    for (const auto& row : csv.rows) {
        RowBin b;
        b.xBmin = to_double_strict(row[c_xmin], "xBmin");
        b.xBmax = to_double_strict(row[c_xmax], "xBmax");
        b.Q2min = to_double_strict(row[c_qmin], "Q2min");
        b.Q2max = to_double_strict(row[c_qmax], "Q2max");
        b.tmin = to_double_strict(row[c_tmin], "t_abs_min");
        b.tmax = to_double_strict(row[c_tmax], "t_abs_max");
        b.phimin = to_double_strict(row[c_pmin], "phimin");
        b.phimax = to_double_strict(row[c_pmax], "phimax");
        b.valid = valid_cell(row[c_valid]);
        bins.push_back(b);
    }

    return bins;
}

static double phi_center(double pmin, double pmax) {
    if (pmax >= pmin) {
        return 0.5 * (pmin + pmax);
    }

    const double span = (360.0 - pmin) + pmax;
    double p = pmin + 0.5 * span;
    if (p >= 360.0) {
        p -= 360.0;
    }
    return p;
}

static std::string normalized_raw_yield_col(const std::string& channel,
                                            const std::string& topo,
                                            const std::string& period,
                                            const std::string& helicity) {
    return "normalized raw yield, " + channel + ", " + topo + ", exp, " + period + ", " + helicity;
}

static std::string rec_current_corrected_yield_col(const std::string& channel,
                                                   const std::string& topo,
                                                   const std::string& period) {
    return "reconstructed current corrected yield, " + channel + ", " + topo + ", mc, " + period;
}

static std::string rec_yield_col(const std::string& channel,
                                 const std::string& topo,
                                 const std::string& period) {
    return "reconstructed yield, " + channel + ", " + topo + ", mc, " + period;
}

static std::string current_eff_col(const std::string& channel,
                                   const std::string& sample,
                                   const std::string& period) {
    return "current efficiency factor, " + channel + ", " + sample + ", " + period;
}

static std::string contamination_col(const std::string& period) {
    return "contamination ratio, " + period;
}

static Triple sum_topology_data_yield(const CSV& csv,
                                      const std::vector<std::string>& row,
                                      const std::string& channel,
                                      const std::string& period) {
    Triple total;
    total.v = 0.0;
    total.stat = 0.0;
    total.sys = 0.0;

    for (const std::string& topo : kTopologies) {
        const std::string colname = normalized_raw_yield_col(channel, topo, period, "unpol");
        const int c = col_strict(csv, colname);
        add_triple_in_quadrature(total, parse_yield_or_zero(row[c], colname));
    }
    return total;
}

static Triple sum_topology_mc_yield(const CSV& csv,
                                    const std::vector<std::string>& row,
                                    const std::string& channel,
                                    const std::string& period) {
    Triple total;
    total.v = 0.0;
    total.stat = 0.0;
    total.sys = 0.0;

    for (const std::string& topo : kTopologies) {
        const std::string colname = rec_current_corrected_yield_col(channel, topo, period);
        const int c = col_strict(csv, colname);
        add_triple_in_quadrature(total, parse_yield_or_zero(row[c], colname));
    }
    return total;
}

static Triple sum_topology_misid_mc_yield_with_current_mode(
    const CSV& csv,
    const std::vector<std::string>& row,
    const std::string& period,
    bool use_epg_mc_current_factor_for_eppi0_bkg) {

    // The current-response convention is now applied event-by-event in
    // total_counts.cpp, before the reconstructed ep->eppi0->epg yield is
    // collapsed into analysis bins.  In particular, total_counts chooses the
    // ep->epg or ep->eppi0 response model for this misidentified sample
    // according to use_epg_mc_current_factor_for_eppi0_bkg.  Do not apply a
    // second period-wide scalar factor here.
    (void)use_epg_mc_current_factor_for_eppi0_bkg;
    return sum_topology_mc_yield(csv, row, "ep->eppi0->epg", period);
}

static Triple compute_contamination(const Triple& Nmis,
                                    const Triple& Npi0_data,
                                    const Triple& Npi0_rec_mc,
                                    const Triple& Ndvcs_data) {
    Triple out;

    if (!(Nmis.v > 0.0) || !(Npi0_data.v > 0.0) ||
        !(Npi0_rec_mc.v > 0.0) || !(Ndvcs_data.v > 0.0)) {
        out.v = 0.0;
        out.stat = 0.0;
        out.sys = 0.0;
        return out;
    }

    out.v = (Nmis.v * Npi0_data.v) / (Npi0_rec_mc.v * Ndvcs_data.v);

    const double rel_var_stat =
        (Nmis.stat * Nmis.stat) / (Nmis.v * Nmis.v) +
        (Npi0_data.stat * Npi0_data.stat) / (Npi0_data.v * Npi0_data.v) +
        (Npi0_rec_mc.stat * Npi0_rec_mc.stat) / (Npi0_rec_mc.v * Npi0_rec_mc.v) +
        (Ndvcs_data.stat * Ndvcs_data.stat) / (Ndvcs_data.v * Ndvcs_data.v);

    out.stat = std::fabs(out.v) * std::sqrt(std::max(0.0, rel_var_stat));
    out.sys = 0.0;

    return out;
}

static std::string safe_dir_name(const std::string& s) {
    std::string out = s;
    for (char& c : out) {
        if (c == ' ') {
            c = '_';
        }
    }
    return out;
}

static std::string join_path(const std::string& a, const std::string& b) {
    if (a.empty()) {
        return b;
    }
    if (a.back() == '/') {
        return a + b;
    }
    return a + "/" + b;
}

static void mkdir_p(const std::string& path) {
    if (!path.empty()) {
        gSystem->mkdir(path.c_str(), true);
    }
}

static void plot_period_contamination(const std::string& period,
                                      const std::vector<RowBin>& bins,
                                      const std::vector<RowContam>& points,
                                      const std::string& output_root_dir) {
    const std::string out_dir = join_path(join_path(output_root_dir, "pi0_contamination_plots"), safe_dir_name(period));
    mkdir_p(out_dir);

    struct XBEdge {
        double a = 0.0;
        double b = 0.0;
    };

    std::vector<XBEdge> xbins;
    for (const RowBin& b : bins) {
        if (!b.valid) {
            continue;
        }
        XBEdge e{b.xBmin, b.xBmax};
        auto it = std::find_if(xbins.begin(), xbins.end(), [&](const XBEdge& z) {
            return z.a == e.a && z.b == e.b;
        });
        if (it == xbins.end()) {
            xbins.push_back(e);
        }
    }

    std::sort(xbins.begin(), xbins.end(), [](const XBEdge& x, const XBEdge& y) {
        if (x.a != y.a) {
            return x.a < y.a;
        }
        return x.b < y.b;
    });

    for (const XBEdge& xb : xbins) {
        std::vector<int> row_indices;
        std::vector<XBEdge> qbins;
        std::vector<XBEdge> tbins;

        for (int i = 0; i < (int)bins.size(); ++i) {
            const RowBin& b = bins[i];
            if (!b.valid) {
                continue;
            }
            if (!(b.xBmin == xb.a && b.xBmax == xb.b)) {
                continue;
            }

            row_indices.push_back(i);

            XBEdge q{b.Q2min, b.Q2max};
            XBEdge t{b.tmin, b.tmax};

            auto iq = std::find_if(qbins.begin(), qbins.end(), [&](const XBEdge& z) {
                return z.a == q.a && z.b == q.b;
            });
            if (iq == qbins.end()) {
                qbins.push_back(q);
            }

            auto it = std::find_if(tbins.begin(), tbins.end(), [&](const XBEdge& z) {
                return z.a == t.a && z.b == t.b;
            });
            if (it == tbins.end()) {
                tbins.push_back(t);
            }
        }

        if (row_indices.empty()) {
            continue;
        }

        auto sort_edge = [](std::vector<XBEdge>& v) {
            std::sort(v.begin(), v.end(), [](const XBEdge& x, const XBEdge& y) {
                if (x.a != y.a) {
                    return x.a < y.a;
                }
                return x.b < y.b;
            });
        };
        sort_edge(qbins);
        sort_edge(tbins);

        const int ncols = (int)qbins.size();
        const int nrows = (int)tbins.size();
        if (ncols <= 0 || nrows <= 0) {
            continue;
        }

        const int W = 300 * ncols + 160;
        const int H = 260 * nrows + 240;

        TCanvas c("c_pi0_contamination", "", W, H);
        TPad* top = new TPad("top", "top", 0.0, 0.90, 1.0, 1.0);
        TPad* grid = new TPad("grid", "grid", 0.0, 0.0, 1.0, 0.90);
        top->SetFillStyle(0);
        grid->SetFillStyle(0);
        top->Draw();
        grid->Draw();

        top->cd();
        TLatex title;
        title.SetNDC(true);
        title.SetTextFont(42);
        title.SetTextSize(0.28);
        std::ostringstream tss;
        tss << period << "   #pi^{0} contamination   x_{B} in ["
            << std::fixed << std::setprecision(2) << xb.a << ", " << xb.b << ")";
        title.DrawLatex(0.05, 0.35, tss.str().c_str());

        grid->cd();
        grid->Divide(ncols, nrows, 0.0, 0.0);

        auto find_edge = [](const std::vector<XBEdge>& v, double a, double b) {
            for (int i = 0; i < (int)v.size(); ++i) {
                if (v[i].a == a && v[i].b == b) {
                    return i;
                }
            }
            return -1;
        };

        for (int it = 0; it < nrows; ++it) {
            for (int iq = 0; iq < ncols; ++iq) {
                const int pad_idx = it * ncols + iq + 1;
                grid->cd(pad_idx);

                gPad->SetLeftMargin(0.160);
                gPad->SetRightMargin(0.07);
                gPad->SetTopMargin(0.22);
                gPad->SetBottomMargin(0.18);
                gPad->SetGrid(1, 1);
                gPad->SetTickx(1);
                gPad->SetTicky(1);

                TGraphErrors g;
                int ip = 0;
                double ymax = 0.0;

                for (int ridx : row_indices) {
                    const RowBin& rb = bins[ridx];
                    const int qidx = find_edge(qbins, rb.Q2min, rb.Q2max);
                    const int tidx = find_edge(tbins, rb.tmin, rb.tmax);
                    if (qidx != iq || tidx != it) {
                        continue;
                    }

                    const RowContam& p = points[ridx];
                    if (!p.valid) {
                        continue;
                    }

                    g.SetPoint(ip, p.phi, p.value);
                    g.SetPointError(ip, 0.0, p.stat);
                    ymax = std::max(ymax, p.value + p.stat);
                    ++ip;
                }

                if (!(ymax > 0.0)) {
                    ymax = 0.02;
                }

                TH1F* frame = (TH1F*)gPad->DrawFrame(0.0, 0.0, 360.0, 1.25 * ymax);
                frame->SetTitle("");
                frame->GetXaxis()->SetTitle("#phi (deg)");
                frame->GetYaxis()->SetTitle("#pi^{0} contamination");
                frame->GetXaxis()->CenterTitle(true);
                frame->GetYaxis()->CenterTitle(true);
                frame->GetXaxis()->SetNdivisions(505);
                frame->GetXaxis()->SetLabelSize(0.060);
                frame->GetYaxis()->SetLabelSize(0.060);
                frame->GetXaxis()->SetTitleSize(0.070);
                frame->GetYaxis()->SetTitleSize(0.070);
                frame->GetXaxis()->SetTitleOffset(1.05);
                frame->GetYaxis()->SetTitleOffset(1.10);

                g.SetMarkerStyle(20);
                g.SetMarkerColor(kBlack);
                g.SetLineColor(kBlack);
                g.SetLineWidth(1);
                g.Draw("PE SAME");

                TLatex txt;
                txt.SetNDC(true);
                txt.SetTextFont(42);
                txt.SetTextSize(0.060);
                std::ostringstream ss;
                ss << "Q^{2}=" << std::fixed << std::setprecision(2) << 0.5 * (qbins[iq].a + qbins[iq].b)
                   << "  |t|=" << std::fixed << std::setprecision(2) << 0.5 * (tbins[it].a + tbins[it].b);
                txt.DrawLatex(0.12, 0.83, ss.str().c_str());
            }
        }

        const int idx = (int)std::llround(xb.a * 1000.0);
        std::ostringstream fname;
        fname << out_dir << "/plot_pi0_contamination_" << safe_dir_name(period)
              << "_xB_" << idx << ".png";
        c.SaveAs(fname.str().c_str());

        delete top;
        delete grid;
    }
}


// -------------------- exclusivity-variable contamination diagnostics --------------------

struct DiagnosticVar {
    std::string name;
    std::string label;
    int nbins = 100;
    double xmin = 0.0;
    double xmax = 1.0;
};

struct DiagnosticBinRow {
    std::string period;
    std::string topology;
    std::string variable;
    int bin = 0;
    double xmin = 0.0;
    double xmax = 0.0;
    double xcenter = 0.0;
    double Ndvcs_data = 0.0;
    double Ndvcs_data_stat = 0.0;
    double Npi0_data = 0.0;
    double Npi0_data_stat = 0.0;
    double Npi0_rec_mc = 0.0;
    double Npi0_rec_mc_stat = 0.0;
    double Nmis_mc = 0.0;
    double Nmis_mc_stat = 0.0;
    double contamination = 0.0;       // fraction, not percent
    double contamination_stat = 0.0;  // fraction, not percent
    bool valid = false;
};


struct DiagnosticHist {
    int nbins = 0;
    double xmin = 0.0;
    double xmax = 1.0;
    double width = 1.0;
    std::vector<double> sumw;
    std::vector<double> sumw2;

    DiagnosticHist() = default;
    DiagnosticHist(int n, double lo, double hi) {
        reset(n, lo, hi);
    }

    void reset(int n, double lo, double hi) {
        nbins = std::max(1, n);
        xmin = lo;
        xmax = hi;
        width = (xmax > xmin) ? (xmax - xmin) / (double)nbins : 1.0;
        sumw.assign((size_t)nbins + 1, 0.0);   // 1-based bin indexing; bin 0 unused
        sumw2.assign((size_t)nbins + 1, 0.0);
    }

    void Fill(double x, double w = 1.0) {
        if (!(x >= xmin && x < xmax) || !(width > 0.0)) return;
        int ibin = 1 + (int)((x - xmin) / width);
        if (ibin < 1) ibin = 1;
        if (ibin > nbins) ibin = nbins;
        sumw[(size_t)ibin] += w;
        sumw2[(size_t)ibin] += w * w;
    }

    int GetNbinsX() const { return nbins; }
    double GetBinContent(int ibin) const {
        if (ibin < 1 || ibin > nbins) return 0.0;
        return sumw[(size_t)ibin];
    }
    double GetBinError(int ibin) const {
        if (ibin < 1 || ibin > nbins) return 0.0;
        return std::sqrt(std::max(0.0, sumw2[(size_t)ibin]));
    }
    double GetBinLowEdge(int ibin) const { return xmin + (double)(ibin - 1) * width; }
    double GetBinUpEdge(int ibin) const { return xmin + (double)ibin * width; }
    double GetBinCenter(int ibin) const { return 0.5 * (GetBinLowEdge(ibin) + GetBinUpEdge(ibin)); }
};

struct DiagnosticCut {
    double mean = std::numeric_limits<double>::quiet_NaN();
    double std = std::numeric_limits<double>::quiet_NaN();
    double cut_low = std::numeric_limits<double>::quiet_NaN();
    double cut_high = std::numeric_limits<double>::quiet_NaN();
    std::string mode = "symmetric_3sigma";
};

using DiagnosticCutMap = std::map<std::string, DiagnosticCut>;
using DiagnosticTopoCutMap = std::map<std::string, DiagnosticCutMap>;


static const std::vector<DiagnosticVar> kDiagnosticVars = {
    {"Delta_phi",           "#Delta#phi (rad)",                                      100, 2.84159, 3.44159},
    {"theta",               "#theta (rad)",                                          100, 0.0, 0.2},
    {"theta_gamma_gamma",   "#theta_{#gamma#gamma} / #theta_{#pi^{0}#pi^{0}} (rad)", 100, 0.0, 2.0},
    {"pTmiss",              "p_{T}^{miss} (GeV)",                                    100, 0.0, 0.3},
    {"Emiss2",              "E_{miss}^{2} (GeV^{2})",                                100, -1.0, 2.0},
    {"Mx2",                 "M_{x}^{2} (GeV^{2})",                                   100, -0.03, 0.03},
    {"Mx2_2",               "M_{x2}^{2} (GeV^{2})",                                  100, 0.0, 3.0}
};

static std::string to_lower_ascii(std::string s) {
    for (char& c : s) {
        c = (char)std::tolower((unsigned char)c);
    }
    return s;
}

static bool key_matches_period(const std::string& key, const std::string& period) {
    const std::string k = to_lower_ascii(key);

    if (period == "Fa18 Inb") return k.find("fa18") != std::string::npos && k.find("in")  != std::string::npos && k.find("out") == std::string::npos;
    if (period == "Fa18 Out") return k.find("fa18") != std::string::npos && k.find("out") != std::string::npos;
    if (period == "Sp18 Inb") return k.find("sp18") != std::string::npos && k.find("in")  != std::string::npos && k.find("out") == std::string::npos;
    if (period == "Sp18 Out") return k.find("sp18") != std::string::npos && k.find("out") != std::string::npos;
    if (period == "Sp19 Inb") return k.find("sp19") != std::string::npos && k.find("in")  != std::string::npos && k.find("out") == std::string::npos;

    return false;
}

static int topology_detector1(const std::string& topo) {
    if (topo == "(FD, FD)") return 1;
    if (topo == "(CD, FD)") return 2;
    if (topo == "(CD, FT)") return 2;
    return -999;
}

static int topology_detector2(const std::string& topo) {
    if (topo == "(FD, FD)") return 1;
    if (topo == "(CD, FD)") return 1;
    if (topo == "(CD, FT)") return 0;
    return -999;
}

static bool passes_topology_ids(int detector1, int detector2, const std::string& topo) {
    return detector1 == topology_detector1(topo) && detector2 == topology_detector2(topo);
}

static std::vector<std::string> diagnostic_variable_aliases(const std::string& requested_variable,
                                                            bool eppi0_exclusive_sample) {
    if (requested_variable == "theta_gamma_gamma") {
        if (eppi0_exclusive_sample) return {"theta_pi0_pi0", "theta_gamma_gamma"};
        return {"theta_gamma_gamma", "theta_pi0_pi0"};
    }

    if (requested_variable == "Delta_phi") {
        return {"Delta_phi"};
    }

    // Most trees use the nominal names below. The extra aliases are deliberately
    // harmless fallbacks for older skim variants. They also make the diagnostic
    // more robust if a channel-specific tree used a slightly different spelling.
    if (requested_variable == "Mx2") {
        return {"Mx2", "Mx2_epg", "Mx2_eg", "Mx2_epgamma", "Mx2_epi0", "Mx2_eppi0"};
    }
    if (requested_variable == "Mx2_2") {
        return {"Mx2_2", "Mx2_egamma", "Mx2_gamma", "Mx2_pi0", "Mx2_x2"};
    }

    return {requested_variable};
}

static std::string join_aliases_for_log(const std::vector<std::string>& aliases) {
    std::ostringstream os;
    for (size_t i = 0; i < aliases.size(); ++i) {
        if (i) os << "/";
        os << aliases[i];
    }
    return os.str();
}

static std::string period_code_for_cut_key(const std::string& period) {
    if (period == "Fa18 Inb") return "Fa18_Inb";
    if (period == "Fa18 Out") return "Fa18_Out";
    if (period == "Sp18 Inb") return "Sp18_Inb";
    if (period == "Sp18 Out") return "Sp18_Out";
    if (period == "Sp19 Inb") return "Sp19_Inb";
    return period;
}

static std::string period_label_for_global_cuts(const std::string& period) {
    if (period == "Fa18 Inb") return "fa18_inb";
    if (period == "Fa18 Out") return "fa18_out";
    if (period == "Sp18 Inb") return "sp18_inb";
    if (period == "Sp18 Out") return "sp18_out";
    if (period == "Sp19 Inb") return "sp19_inb";
    return period;
}

static std::string topology_code_for_cut_key(const std::string& topo) {
    if (topo == "(FD, FD)") return "FD_FD";
    if (topo == "(CD, FD)") return "CD_FD";
    if (topo == "(CD, FT)") return "CD_FT";
    return topo;
}

static std::string diagnostic_cut_key(const std::string& prefix,
                                      const std::string& period,
                                      const std::string& topo) {
    return prefix + "_" + period_code_for_cut_key(period) + "_" + topology_code_for_cut_key(topo);
}

static bool diagnostic_within_cut(double v, const DiagnosticCut& c) {
    if (!std::isfinite(v)) return false;

    if (c.mode == "upper_quantile") {
        if (!std::isfinite(c.cut_high)) return true;
        return v <= c.cut_high;
    }

    double lo = c.cut_low;
    double hi = c.cut_high;
    if (!(std::isfinite(lo) && std::isfinite(hi)) || hi <= lo) {
        if (!std::isfinite(c.mean) || !std::isfinite(c.std) || c.std <= 0.0) return true;
        lo = c.mean - 3.0 * c.std;
        hi = c.mean + 3.0 * c.std;
    }

    return v >= lo && v <= hi;
}

static bool diagnostic_cut_range(const DiagnosticCut& c,
                                 double fallback_low,
                                 double fallback_high,
                                 double& lo,
                                 double& hi) {
    if (c.mode == "upper_quantile") {
        lo = std::isfinite(c.cut_low) ? c.cut_low : fallback_low;
        hi = std::isfinite(c.cut_high) ? c.cut_high : fallback_high;
    } else {
        lo = c.cut_low;
        hi = c.cut_high;
        if (!(std::isfinite(lo) && std::isfinite(hi)) || hi <= lo) {
            if (!std::isfinite(c.mean) || !std::isfinite(c.std) || c.std <= 0.0) return false;
            lo = c.mean - 3.0 * c.std;
            hi = c.mean + 3.0 * c.std;
        }
    }

    return std::isfinite(lo) && std::isfinite(hi) && hi > lo;
}

static bool expand_range_from_cut_map(const DiagnosticCutMap* cuts,
                                      const DiagnosticVar& varcfg,
                                      bool eppi0_exclusive_sample,
                                      double& xmin,
                                      double& xmax) {
    if (!cuts) return false;

    bool found = false;
    const std::vector<std::string> aliases = diagnostic_variable_aliases(varcfg.name, eppi0_exclusive_sample);
    for (const std::string& alias : aliases) {
        auto it = cuts->find(alias);
        if (it == cuts->end()) continue;

        double lo = 0.0;
        double hi = 0.0;
        if (!diagnostic_cut_range(it->second, varcfg.xmin, varcfg.xmax, lo, hi)) continue;

        if (!found) {
            xmin = lo;
            xmax = hi;
            found = true;
        } else {
            xmin = std::min(xmin, lo);
            xmax = std::max(xmax, hi);
        }
    }

    return found;
}

static DiagnosticVar diagnostic_var_with_data_cut_range(const DiagnosticVar& base,
                                                        const std::string& period,
                                                        const DiagnosticTopoCutMap& data_cuts) {
    DiagnosticVar out = base;
    out.nbins = std::max(4, (base.nbins + 8) / 9);

    bool found = false;
    double xmin = 0.0;
    double xmax = 0.0;

    for (const std::string& topo : kTopologies) {
        const std::string dvcs_key = diagnostic_cut_key("DVCS", period, topo);
        const std::string eppi0_key = diagnostic_cut_key("eppi0", period, topo);

        double lo = 0.0;
        double hi = 0.0;
        auto it_dvcs = data_cuts.find(dvcs_key);
        if (it_dvcs != data_cuts.end() &&
            expand_range_from_cut_map(&it_dvcs->second, base, false, lo, hi)) {
            if (!found) {
                xmin = lo;
                xmax = hi;
                found = true;
            } else {
                xmin = std::min(xmin, lo);
                xmax = std::max(xmax, hi);
            }
        }

        auto it_eppi0 = data_cuts.find(eppi0_key);
        if (it_eppi0 != data_cuts.end() &&
            expand_range_from_cut_map(&it_eppi0->second, base, true, lo, hi)) {
            if (!found) {
                xmin = lo;
                xmax = hi;
                found = true;
            } else {
                xmin = std::min(xmin, lo);
                xmax = std::max(xmax, hi);
            }
        }
    }

    if (found && std::isfinite(xmin) && std::isfinite(xmax) && xmax > xmin) {
        out.xmin = xmin;
        out.xmax = xmax;
    }

    return out;
}

static DiagnosticTopoCutMap load_diagnostic_combined_cuts(const std::string& combined_cuts_json,
                                                          const std::string& sample_key) {
    DiagnosticTopoCutMap out;

    std::ifstream fin(combined_cuts_json);
    if (!fin.is_open()) {
        std::cerr << "[pi0_contamination] WARNING: cannot open combined cuts JSON for diagnostics: "
                  << combined_cuts_json << ". Exclusivity-variable diagnostics will not impose sigma cuts."
                  << std::endl;
        return out;
    }

    nlohmann::json j;
    try {
        fin >> j;
    } catch (const std::exception& e) {
        std::cerr << "[pi0_contamination] WARNING: cannot parse combined cuts JSON for diagnostics: "
                  << e.what() << ". Exclusivity-variable diagnostics will not impose sigma cuts."
                  << std::endl;
        return out;
    }

    if (!j.is_object()) return out;

    for (auto it = j.begin(); it != j.end(); ++it) {
        const std::string key = it.key();
        const auto& block = it.value();
        if (!block.is_object() || !block.contains(sample_key) || !block[sample_key].is_object()) continue;

        DiagnosticCutMap cm;
        for (auto vit = block[sample_key].begin(); vit != block[sample_key].end(); ++vit) {
            if (!vit.value().is_object()) continue;
            DiagnosticCut c;
            try {
                const auto& js = vit.value();
                if (js.contains("mean")) c.mean = js["mean"].get<double>();
                if (js.contains("std")) c.std = js["std"].get<double>();
                if (js.contains("cut_low")) c.cut_low = js["cut_low"].get<double>();
                if (js.contains("cut_high")) c.cut_high = js["cut_high"].get<double>();
                if (js.contains("mode")) c.mode = js["mode"].get<std::string>();
            } catch (...) {
                continue;
            }
            cm[vit.key()] = c;
        }
        if (!cm.empty()) out[key] = std::move(cm);
    }

    std::cout << "[pi0_contamination] Loaded " << sample_key << " exclusivity diagnostic cuts for "
              << out.size() << " topology keys from " << combined_cuts_json << std::endl;
    return out;
}


static std::string safe_file_token(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (std::isalnum((unsigned char)c)) {
            out.push_back(c);
        } else {
            out.push_back('_');
        }
    }
    while (out.find("__") != std::string::npos) {
        size_t pos = out.find("__");
        out.replace(pos, 2, "_");
    }
    if (!out.empty() && out.front() == '_') out.erase(out.begin());
    if (!out.empty() && out.back() == '_') out.pop_back();
    return out.empty() ? "unnamed" : out;
}


struct TreeDiagBranches {
    TTree* tree = nullptr;

    int runnum = 0; bool has_runnum = false;
    int detector1 = 0; bool has_detector1 = false;
    int detector2 = 0; bool has_detector2 = false;

    double Delta_phi = 0.0; bool has_Delta_phi = false;
    double p1_theta = 0.0; bool has_p1_theta = false;
    double p1_phi = 0.0; bool has_p1_phi = false;
    double p2_phi = 0.0; bool has_p2_phi = false;

    double t1 = 0.0; bool has_t1 = false;
    double open_angle_ep2 = 0.0; bool has_open_angle_ep2 = false;
    double pTmiss = 0.0; bool has_pTmiss = false;

    double e_p = 0.0; bool has_e_p = false;
    double e_theta = 0.0; bool has_e_theta = false;
    double e_phi = 0.0; bool has_e_phi = false;

    double p2_p = 0.0; bool has_p2_p = false;
    double p2_theta = 0.0; bool has_p2_theta = false;

    double theta = 0.0; bool has_theta = false;
    double Emiss2 = 0.0; bool has_Emiss2 = false;
    double Mx2 = 0.0; bool has_Mx2 = false;
    double Mx2_2 = 0.0; bool has_Mx2_2 = false;
    double theta_gamma_gamma = 0.0; bool has_theta_gamma_gamma = false;
    double theta_pi0_pi0 = 0.0; bool has_theta_pi0_pi0 = false;

    bool bind(TTree* t) {
        tree = t;
        if (!tree) return false;

        // Use explicit branch-address binding instead of TLeaf::GetValue().
        // The diagnostic is sometimes run after several other stages have
        // modified ROOT branch statuses/addresses, and holding TLeaf pointers
        // across GetEntry calls has produced intermittent crashes. This local
        // binder follows the same robust pattern used elsewhere in the analysis:
        // enable only the needed branches, bind them into local C++ storage, and
        // read those values after GetEntry().
        tree->SetBranchStatus("*", 0);

        auto enable = [&](const char* name) {
            if (tree->GetBranch(name)) tree->SetBranchStatus(name, 1);
        };

        enable("runnum");
        enable("detector1");
        enable("detector2");
        enable("Delta_phi");
        enable("p1_theta");
        enable("p1_phi");
        enable("p2_phi");
        enable("t1");
        enable("open_angle_ep2");
        enable("pTmiss");
        enable("e_p");
        enable("e_theta");
        enable("e_phi");
        enable("p2_p");
        enable("p2_theta");
        enable("Emiss2");
        enable("Mx2");
        enable("Mx2_2");
        enable("theta");
        enable("theta_gamma_gamma");
        enable("theta_pi0_pi0");

        tree->SetCacheSize(16LL * 1024LL * 1024LL);
        tree->AddBranchToCache("*", true);

        auto bI = [&](const char* name, int* addr, bool& flag) {
            if (tree->GetBranch(name)) {
                tree->SetBranchAddress(name, addr);
                flag = true;
            }
        };
        auto bD = [&](const char* name, double* addr, bool& flag) {
            if (tree->GetBranch(name)) {
                tree->SetBranchAddress(name, addr);
                flag = true;
            }
        };

        bI("runnum", &runnum, has_runnum);
        bI("detector1", &detector1, has_detector1);
        bI("detector2", &detector2, has_detector2);

        bD("Delta_phi", &Delta_phi, has_Delta_phi);
        bD("p1_theta", &p1_theta, has_p1_theta);
        bD("p1_phi", &p1_phi, has_p1_phi);
        bD("p2_phi", &p2_phi, has_p2_phi);
        bD("t1", &t1, has_t1);
        bD("open_angle_ep2", &open_angle_ep2, has_open_angle_ep2);
        bD("pTmiss", &pTmiss, has_pTmiss);
        bD("e_p", &e_p, has_e_p);
        bD("e_theta", &e_theta, has_e_theta);
        bD("e_phi", &e_phi, has_e_phi);
        bD("p2_p", &p2_p, has_p2_p);
        bD("p2_theta", &p2_theta, has_p2_theta);

        bD("Emiss2", &Emiss2, has_Emiss2);
        bD("Mx2", &Mx2, has_Mx2);
        bD("Mx2_2", &Mx2_2, has_Mx2_2);
        bD("theta", &theta, has_theta);
        bD("theta_gamma_gamma", &theta_gamma_gamma, has_theta_gamma_gamma);
        bD("theta_pi0_pi0", &theta_pi0_pi0, has_theta_pi0_pi0);

        return has_detector1 && has_detector2;
    }

    static double wrapped_abs_delta_phi(double a, double b) {
        double d = a - b;
        constexpr double kPiLocal = 3.14159265358979323846;
        while (d >  kPiLocal) d -= 2.0 * kPiLocal;
        while (d < -kPiLocal) d += 2.0 * kPiLocal;
        return std::fabs(d);
    }

    bool named_value(const std::string& name, double& value) const {
        if (name == "Delta_phi") {
            if (has_Delta_phi) {
                value = Delta_phi;
            } else if (has_p1_phi && has_p2_phi) {
                value = wrapped_abs_delta_phi(p1_phi, p2_phi);
            } else {
                return false;
            }
        } else if (name == "Emiss2") {
            if (!has_Emiss2) return false;
            value = Emiss2;
        } else if (name == "Mx2") {
            if (!has_Mx2) return false;
            value = Mx2;
        } else if (name == "Mx2_2") {
            if (!has_Mx2_2) return false;
            value = Mx2_2;
        } else if (name == "pTmiss") {
            if (!has_pTmiss) return false;
            value = pTmiss;
        } else if (name == "theta") {
            if (!has_theta) return false;
            value = theta;
        } else if (name == "theta_gamma_gamma") {
            if (!has_theta_gamma_gamma) return false;
            value = theta_gamma_gamma;
        } else if (name == "theta_pi0_pi0") {
            if (!has_theta_pi0_pi0) return false;
            value = theta_pi0_pi0;
        } else {
            return false;
        }

        return std::isfinite(value);
    }

    bool value_from_aliases(const std::vector<std::string>& aliases, double& value) const {
        for (const std::string& alias : aliases) {
            if (named_value(alias, value)) return true;
        }
        return false;
    }

    bool get_main_value(const DiagnosticVar& varcfg,
                        bool eppi0_exclusive_sample,
                        double& value,
                        int& d1,
                        int& d2) const {
        if (!tree || !has_detector1 || !has_detector2) return false;
        d1 = detector1;
        d2 = detector2;
        const std::vector<std::string> aliases = diagnostic_variable_aliases(varcfg.name, eppi0_exclusive_sample);
        return value_from_aliases(aliases, value);
    }

    bool value_for_cut_var(const std::string& cut_var,
                           bool eppi0_exclusive_sample,
                           double& value) const {
        const std::vector<std::string> aliases = diagnostic_variable_aliases(cut_var, eppi0_exclusive_sample);
        return value_from_aliases(aliases, value);
    }

    bool passes_global_selection(const std::string& period, int d1, int d2) const {
        const GlobalCutConfig& cfg = default_global_cuts();

        if (!(has_t1 && has_open_angle_ep2 && has_pTmiss)) return false;
        if (has_runnum && is_excluded_run(runnum)) return false;

        if (global_cuts_require_sector_phi(cfg)) {
            if (!(has_e_phi && has_p1_phi && has_p2_phi)) return false;
        }

        if (global_cuts_require_auxiliary_kinematics(cfg)) {
            if (!(has_e_theta && has_e_phi &&
                  has_p1_theta && has_p1_phi &&
                  has_p2_p && has_p2_theta && has_p2_phi)) return false;

            return passes_global_cuts(t1, open_angle_ep2, pTmiss,
                                      d1, d2,
                                      period_label_for_global_cuts(period),
                                      e_p, e_theta, e_phi,
                                      p1_theta, p1_phi,
                                      p2_p, p2_theta, p2_phi,
                                      cfg);
        }

        if (cfg.enable_dvcsgen_ycol_cut) {
            if (!(has_e_p && has_e_theta && has_e_phi && has_p2_p && has_p2_theta && has_p2_phi)) return false;

            if (global_cuts_require_sector_phi(cfg)) {
                return passes_global_cuts(t1, open_angle_ep2, pTmiss,
                                          d1, d2,
                                          period_label_for_global_cuts(period),
                                          e_p, e_theta, e_phi,
                                          p1_theta, p1_phi,
                                          p2_p, p2_theta, p2_phi,
                                          cfg);
            }

            return passes_global_cuts(t1, open_angle_ep2, pTmiss,
                                      d1, d2,
                                      period_label_for_global_cuts(period),
                                      e_p, e_theta, e_phi,
                                      p2_p, p2_theta, p2_phi,
                                      cfg);
        }

        if (global_cuts_require_sector_phi(cfg)) {
            return passes_global_cuts(t1, open_angle_ep2, pTmiss,
                                      d1, d2,
                                      period_label_for_global_cuts(period),
                                      e_phi, p1_phi, p2_phi,
                                      cfg);
        }

        return passes_global_cuts(t1, open_angle_ep2, pTmiss, d1, d2, cfg);
    }

    bool passes_cuts(const DiagnosticCutMap* cuts,
                     bool eppi0_exclusive_sample) const {
        if (!cuts) return true;
        for (const auto& kv : *cuts) {
            double value = 0.0;
            if (!value_for_cut_var(kv.first, eppi0_exclusive_sample, value)) {
                return false;
            }
            if (!diagnostic_within_cut(value, kv.second)) {
                return false;
            }
        }
        return true;
    }
};

struct CompiledDiagnosticCut {
    std::vector<std::string> aliases;
    DiagnosticCut cut;
};

using CompiledDiagnosticCuts = std::vector<CompiledDiagnosticCut>;

static CompiledDiagnosticCuts compile_diagnostic_cuts(
    const DiagnosticCutMap* cuts,
    bool eppi0_exclusive_sample) {
    CompiledDiagnosticCuts out;
    if (!cuts) return out;

    out.reserve(cuts->size());
    for (const auto& kv : *cuts) {
        CompiledDiagnosticCut c;
        c.aliases = diagnostic_variable_aliases(kv.first, eppi0_exclusive_sample);
        c.cut = kv.second;
        out.push_back(std::move(c));
    }
    return out;
}

static bool passes_compiled_diagnostic_cuts(
    const TreeDiagBranches& branches,
    const CompiledDiagnosticCuts& cuts) {
    for (const CompiledDiagnosticCut& c : cuts) {
        double value = 0.0;
        if (!branches.value_from_aliases(c.aliases, value)) return false;
        if (!diagnostic_within_cut(value, c.cut)) return false;
    }
    return true;
}

static int diagnostic_topology_index(int detector1, int detector2) {
    if (detector1 == 1 && detector2 == 1) return 0; // (FD, FD)
    if (detector1 == 2 && detector2 == 1) return 1; // (CD, FD)
    if (detector1 == 2 && detector2 == 0) return 2; // (CD, FT)
    return -1;
}

struct DiagnosticSampleResult {
    std::vector<std::vector<DiagnosticHist>> hists;       // [topology][variable]
    std::vector<std::vector<long long>> events_filled;    // [topology][variable]
    int trees_used = 0;
    long long events_seen = 0;
};

static DiagnosticSampleResult fill_all_diagnostic_hists_from_trees(
    const std::map<std::string, TTree*>& trees,
    const std::string& period,
    const std::vector<DiagnosticVar>& varcfgs,
    bool eppi0_exclusive_sample,
    const std::array<const DiagnosticCutMap*, 3>& cuts_by_topology) {

    DiagnosticSampleResult result;
    result.hists.resize(kTopologies.size());
    result.events_filled.resize(kTopologies.size());

    for (size_t itopo = 0; itopo < kTopologies.size(); ++itopo) {
        result.hists[itopo].reserve(varcfgs.size());
        result.events_filled[itopo].assign(varcfgs.size(), 0);
        for (const DiagnosticVar& varcfg : varcfgs) {
            result.hists[itopo].emplace_back(varcfg.nbins, varcfg.xmin, varcfg.xmax);
        }
    }

    std::vector<std::vector<std::string>> aliases_by_variable;
    aliases_by_variable.reserve(varcfgs.size());
    for (const DiagnosticVar& varcfg : varcfgs) {
        aliases_by_variable.push_back(
            diagnostic_variable_aliases(varcfg.name, eppi0_exclusive_sample));
    }

    std::array<CompiledDiagnosticCuts, 3> compiled_cuts;
    for (size_t itopo = 0; itopo < compiled_cuts.size(); ++itopo) {
        compiled_cuts[itopo] =
            compile_diagnostic_cuts(cuts_by_topology[itopo], eppi0_exclusive_sample);
    }

    static std::set<std::string> warned_missing;

    for (const auto& kv : trees) {
        if (!kv.second) continue;
        if (!key_matches_period(kv.first, period)) continue;

        TreeDiagBranches branches;
        if (!branches.bind(kv.second)) {
            for (size_t ivar = 0; ivar < varcfgs.size(); ++ivar) {
                const std::string warn_key =
                    kv.first + "|" + varcfgs[ivar].name + "|" +
                    (eppi0_exclusive_sample ? "pi0" : "dvcs");
                if (warned_missing.insert(warn_key).second) {
                    std::cout << "[pi0_contamination] diagnostic: skipping tree key='"
                              << kv.first << "' for variable " << varcfgs[ivar].name
                              << " because required branch(es) are missing. Tried aliases="
                              << join_aliases_for_log(aliases_by_variable[ivar]) << "."
                              << std::endl;
                }
            }
            continue;
        }

        ++result.trees_used;
        const Long64_t n = kv.second->GetEntries();
        result.events_seen += static_cast<long long>(n);

        for (Long64_t i = 0; i < n; ++i) {
            kv.second->GetEntry(i);

            const int itopo = diagnostic_topology_index(branches.detector1, branches.detector2);
            if (itopo < 0) continue;

            if (!branches.passes_global_selection(
                    period, branches.detector1, branches.detector2)) {
                continue;
            }

            if (!passes_compiled_diagnostic_cuts(
                    branches, compiled_cuts[static_cast<size_t>(itopo)])) {
                continue;
            }

            for (size_t ivar = 0; ivar < varcfgs.size(); ++ivar) {
                double x = 0.0;
                if (!branches.value_from_aliases(aliases_by_variable[ivar], x)) continue;

                const DiagnosticVar& varcfg = varcfgs[ivar];
                if (x < varcfg.xmin || x >= varcfg.xmax) continue;

                result.hists[static_cast<size_t>(itopo)][ivar].Fill(x);
                ++result.events_filled[static_cast<size_t>(itopo)][ivar];
            }
        }
    }

    return result;
}

static Triple topology_data_yield_integrated(const CSV& csv,
                                             const std::vector<RowBin>& bins,
                                             const std::string& channel,
                                             const std::string& topo,
                                             const std::string& period) {
    Triple total;
    const std::string colname = normalized_raw_yield_col(channel, topo, period, "unpol");
    const int c = col_strict(csv, colname);

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        if (!bins[r].valid) continue;
        add_triple_in_quadrature(total, parse_yield_or_zero(csv.rows[r][c], colname));
    }
    return total;
}

static Triple topology_mc_yield_integrated(const CSV& csv,
                                           const std::vector<RowBin>& bins,
                                           const std::string& channel,
                                           const std::string& topo,
                                           const std::string& period) {
    Triple total;
    const std::string colname = rec_current_corrected_yield_col(channel, topo, period);
    const int c = col_strict(csv, colname);

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        if (!bins[r].valid) continue;
        add_triple_in_quadrature(total, parse_yield_or_zero(csv.rows[r][c], colname));
    }
    return total;
}

static void scale_hist_to_yield(TH1D& h, const Triple& target) {
    // Avoid TH1::Integral()/TH1::Scale() here. In this diagnostic pass we create
    // many short-lived stack histograms after long TTree scans. On some ROOT
    // builds TH1 can still have an internal fill buffer, and Integral() may call
    // BufferEmpty(), which has shown intermittent bus errors. The diagnostic only
    // needs ordinary bin sums, so do the scaling explicitly.
    double raw = 0.0;
    for (int ibin = 1; ibin <= h.GetNbinsX(); ++ibin) {
        raw += h.GetBinContent(ibin);
    }

    if (!(raw > 0.0) || !(target.v > 0.0)) return;

    const double scale = target.v / raw;
    for (int ibin = 1; ibin <= h.GetNbinsX(); ++ibin) {
        h.SetBinContent(ibin, h.GetBinContent(ibin) * scale);
        h.SetBinError(ibin, h.GetBinError(ibin) * scale);
    }
}

static DiagnosticBinRow compute_diagnostic_bin(const std::string& period,
                                               const std::string& topo,
                                               const std::string& var,
                                               int ibin,
                                               const DiagnosticHist& h_dvcs,
                                               const DiagnosticHist& h_pi0_data,
                                               const DiagnosticHist& h_pi0_rec,
                                               const DiagnosticHist& h_mis) {
    DiagnosticBinRow row;
    row.period = period;
    row.topology = topo;
    row.variable = var;
    row.bin = ibin;
    row.xmin = h_dvcs.GetBinLowEdge(ibin);
    row.xmax = h_dvcs.GetBinUpEdge(ibin);
    row.xcenter = h_dvcs.GetBinCenter(ibin);

    row.Ndvcs_data = h_dvcs.GetBinContent(ibin);
    row.Ndvcs_data_stat = h_dvcs.GetBinError(ibin);
    row.Npi0_data = h_pi0_data.GetBinContent(ibin);
    row.Npi0_data_stat = h_pi0_data.GetBinError(ibin);
    row.Npi0_rec_mc = h_pi0_rec.GetBinContent(ibin);
    row.Npi0_rec_mc_stat = h_pi0_rec.GetBinError(ibin);
    row.Nmis_mc = h_mis.GetBinContent(ibin);
    row.Nmis_mc_stat = h_mis.GetBinError(ibin);

    if (!(row.Ndvcs_data > 0.0) || !(row.Npi0_data > 0.0) ||
        !(row.Npi0_rec_mc > 0.0) || !(row.Nmis_mc > 0.0)) {
        row.valid = false;
        return row;
    }

    row.contamination = (row.Nmis_mc * row.Npi0_data) /
                        (row.Npi0_rec_mc * row.Ndvcs_data);

    const double rel_var =
        (row.Nmis_mc_stat * row.Nmis_mc_stat) / (row.Nmis_mc * row.Nmis_mc) +
        (row.Npi0_data_stat * row.Npi0_data_stat) / (row.Npi0_data * row.Npi0_data) +
        (row.Npi0_rec_mc_stat * row.Npi0_rec_mc_stat) / (row.Npi0_rec_mc * row.Npi0_rec_mc) +
        (row.Ndvcs_data_stat * row.Ndvcs_data_stat) / (row.Ndvcs_data * row.Ndvcs_data);

    row.contamination_stat = std::fabs(row.contamination) * std::sqrt(std::max(0.0, rel_var));
    row.valid = std::isfinite(row.contamination) && std::isfinite(row.contamination_stat);
    return row;
}

static void write_diagnostic_csv(const std::string& path,
                                 const std::vector<DiagnosticBinRow>& rows) {
    std::ofstream out(path);
    if (!out.is_open()) {
        fatal("[pi0_contamination] FATAL: cannot write diagnostic CSV: " + path);
    }

    out << "period,topology,variable,bin,xmin,xmax,xcenter,"
        << "Ndvcs_data,Ndvcs_data_stat,Npi0_data,Npi0_data_stat,"
        << "Npi0_rec_mc,Npi0_rec_mc_stat,Nmis_mc,Nmis_mc_stat,"
        << "contamination_fraction,contamination_fraction_stat,"
        << "contamination_percent,contamination_percent_stat,valid\n";

    out << std::setprecision(12);
    for (const DiagnosticBinRow& r : rows) {
        out << r.period << ',' << r.topology << ',' << r.variable << ',' << r.bin << ','
            << r.xmin << ',' << r.xmax << ',' << r.xcenter << ','
            << r.Ndvcs_data << ',' << r.Ndvcs_data_stat << ','
            << r.Npi0_data << ',' << r.Npi0_data_stat << ','
            << r.Npi0_rec_mc << ',' << r.Npi0_rec_mc_stat << ','
            << r.Nmis_mc << ',' << r.Nmis_mc_stat << ','
            << r.contamination << ',' << r.contamination_stat << ','
            << 100.0 * r.contamination << ',' << 100.0 * r.contamination_stat << ','
            << (r.valid ? 1 : 0) << '\n';
    }
}

static void draw_topology_graph(const std::vector<DiagnosticBinRow>& rows,
                                int color,
                                int marker,
                                const char* draw_opt,
                                TLegend& leg,
                                const std::string& topo) {
    TGraphErrors* g = new TGraphErrors();
    g->SetName(("g_" + safe_file_token(topo)).c_str());

    int ip = 0;
    for (const DiagnosticBinRow& r : rows) {
        if (!r.valid) continue;
        g->SetPoint(ip, r.xcenter, r.contamination);
        g->SetPointError(ip, 0.5 * (r.xmax - r.xmin), r.contamination_stat);
        ++ip;
    }

    g->SetMarkerStyle(marker);
    g->SetMarkerSize(1.25);
    g->SetMarkerColor(color);
    g->SetLineColor(color);
    g->SetLineWidth(1);

    if (ip > 0) {
        g->Draw(draw_opt);
        leg.AddEntry(g, topo.c_str(), "pe");
    }
}

static void plot_diagnostic_overlay(const std::string& out_png,
                                    const std::string& period,
                                    const DiagnosticVar& varcfg,
                                    const std::map<std::string, std::vector<DiagnosticBinRow>>& rows_by_topology) {
    TCanvas c("c_pi0_contamination_vs_excl_overlay", "", 1100, 800);
    c.SetLeftMargin(0.12);
    c.SetRightMargin(0.05);
    c.SetTopMargin(0.10);
    c.SetBottomMargin(0.13);
    c.SetGrid(1, 1);
    c.SetTickx(1);
    c.SetTicky(1);

    TH1F* frame = (TH1F*)gPad->DrawFrame(varcfg.xmin, 0.0, varcfg.xmax, 1.0);
    frame->SetTitle("");
    frame->GetXaxis()->SetTitle(varcfg.label.c_str());
    frame->GetYaxis()->SetTitle("predicted #pi^{0} contamination");
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);
    frame->GetXaxis()->SetTitleSize(0.045);
    frame->GetYaxis()->SetTitleSize(0.045);
    frame->GetXaxis()->SetLabelSize(0.040);
    frame->GetYaxis()->SetLabelSize(0.040);
    frame->GetYaxis()->SetTitleOffset(1.25);

    TLegend leg(0.68, 0.70, 0.93, 0.88);
    leg.SetBorderSize(0);
    leg.SetFillStyle(0);
    leg.SetTextFont(42);
    leg.SetTextSize(0.035);

    const std::vector<int> colors = {kBlack, kBlue + 1, kRed + 1};
    const std::vector<int> markers = {20, 21, 22};

    int itopo = 0;
    for (const std::string& topo : kTopologies) {
        auto it = rows_by_topology.find(topo);
        if (it == rows_by_topology.end()) continue;
        draw_topology_graph(it->second,
                            colors[itopo % (int)colors.size()],
                            markers[itopo % (int)markers.size()],
                            "PE SAME",
                            leg,
                            topo);
        ++itopo;
    }

    leg.Draw();

    TLatex title;
    title.SetNDC(true);
    title.SetTextFont(42);
    title.SetTextSize(0.040);
    std::ostringstream ss;
    ss << period << "   predicted #pi^{0} contamination vs " << varcfg.name;
    title.DrawLatex(0.12, 0.935, ss.str().c_str());

    c.SaveAs(out_png.c_str());
}

static const DiagnosticCutMap* find_diagnostic_cut_map(
    const DiagnosticTopoCutMap& all_cuts,
    const std::string& prefix,
    const std::string& period,
    const std::string& topology) {
    const auto it = all_cuts.find(diagnostic_cut_key(prefix, period, topology));
    return (it == all_cuts.end()) ? nullptr : &it->second;
}

static void make_exclusivity_variable_diagnostics(
    const CSV& csv,
    const std::vector<RowBin>& bins,
    const std::map<std::string, TTree*>& dvcsDataTrees,
    const std::map<std::string, TTree*>& eppi0DataTrees,
    const std::map<std::string, TTree*>& eppi0RecMcTrees,
    const std::map<std::string, TTree*>& eppi0BkgTrees,
    const DiagnosticTopoCutMap& data_cuts,
    const DiagnosticTopoCutMap& mc_cuts,
    const std::string& output_root_dir) {

    (void)csv;
    (void)bins;

    const std::string diag_dir = join_path(join_path(output_root_dir, "pi0_contamination_plots"),
                                           "exclusivity_variable_diagnostics");
    mkdir_p(diag_dir);

    std::vector<DiagnosticBinRow> all_rows;

    for (const std::string& period : kPeriods) {
        std::vector<DiagnosticVar> varcfgs;
        varcfgs.reserve(kDiagnosticVars.size());
        for (const DiagnosticVar& base_varcfg : kDiagnosticVars) {
            varcfgs.push_back(
                diagnostic_var_with_data_cut_range(base_varcfg, period, data_cuts));
        }

        std::array<const DiagnosticCutMap*, 3> dvcs_data_cuts{};
        std::array<const DiagnosticCutMap*, 3> eppi0_data_cuts{};
        std::array<const DiagnosticCutMap*, 3> dvcs_mc_cuts{};
        std::array<const DiagnosticCutMap*, 3> eppi0_mc_cuts{};

        for (size_t itopo = 0; itopo < kTopologies.size(); ++itopo) {
            const std::string& topo = kTopologies[itopo];
            dvcs_data_cuts[itopo] =
                find_diagnostic_cut_map(data_cuts, "DVCS", period, topo);
            eppi0_data_cuts[itopo] =
                find_diagnostic_cut_map(data_cuts, "eppi0", period, topo);
            dvcs_mc_cuts[itopo] =
                find_diagnostic_cut_map(mc_cuts, "DVCS", period, topo);
            eppi0_mc_cuts[itopo] =
                find_diagnostic_cut_map(mc_cuts, "eppi0", period, topo);
        }

        // Each sample is scanned exactly once for this period. During that one
        // pass, all three topologies and all eight diagnostic variables are
        // filled. The previous implementation rescanned the same trees once for
        // every topology-variable combination.
        const DiagnosticSampleResult dvcs_result =
            fill_all_diagnostic_hists_from_trees(
                dvcsDataTrees, period, varcfgs, false, dvcs_data_cuts);
        const DiagnosticSampleResult pi0_data_result =
            fill_all_diagnostic_hists_from_trees(
                eppi0DataTrees, period, varcfgs, true, eppi0_data_cuts);
        const DiagnosticSampleResult pi0_rec_result =
            fill_all_diagnostic_hists_from_trees(
                eppi0RecMcTrees, period, varcfgs, true, eppi0_mc_cuts);
        const DiagnosticSampleResult mis_result =
            fill_all_diagnostic_hists_from_trees(
                eppi0BkgTrees, period, varcfgs, false, dvcs_mc_cuts);

        const bool have_all_trees =
            dvcs_result.trees_used > 0 &&
            pi0_data_result.trees_used > 0 &&
            pi0_rec_result.trees_used > 0 &&
            mis_result.trees_used > 0;

        for (size_t ivar = 0; ivar < varcfgs.size(); ++ivar) {
            const DiagnosticVar& varcfg = varcfgs[ivar];
            std::map<std::string, std::vector<DiagnosticBinRow>> rows_by_topology;

            for (size_t itopo = 0; itopo < kTopologies.size(); ++itopo) {
                const std::string& topo = kTopologies[itopo];

                if (!have_all_trees) {
                    std::cout << "[pi0_contamination] diagnostic: insufficient trees for "
                              << period << " " << topo << " " << varcfg.name
                              << " trees(dvcs,pi0data,pi0rec,mis)=("
                              << dvcs_result.trees_used << ","
                              << pi0_data_result.trees_used << ","
                              << pi0_rec_result.trees_used << ","
                              << mis_result.trees_used << ")."
                              << std::endl;
                }

                const DiagnosticHist& h_dvcs = dvcs_result.hists[itopo][ivar];
                const DiagnosticHist& h_pi0_data = pi0_data_result.hists[itopo][ivar];
                const DiagnosticHist& h_pi0_rec = pi0_rec_result.hists[itopo][ivar];
                const DiagnosticHist& h_mis = mis_result.hists[itopo][ivar];

                std::vector<DiagnosticBinRow> plot_rows;
                plot_rows.reserve(varcfg.nbins);
                for (int ibin = 1; ibin <= varcfg.nbins; ++ibin) {
                    DiagnosticBinRow row = compute_diagnostic_bin(
                        period, topo, varcfg.name, ibin,
                        h_dvcs, h_pi0_data, h_pi0_rec, h_mis);
                    if (!have_all_trees) row.valid = false;
                    all_rows.push_back(row);
                    plot_rows.push_back(row);
                }
                rows_by_topology[topo] = std::move(plot_rows);

                std::cout << "[pi0_contamination] diagnostic "
                          << period << " " << topo << " " << varcfg.name
                          << ": seen(dvcs,pi0data,pi0rec,mis)=("
                          << dvcs_result.events_seen << ","
                          << pi0_data_result.events_seen << ","
                          << pi0_rec_result.events_seen << ","
                          << mis_result.events_seen
                          << ") filled(dvcs,pi0data,pi0rec,mis)=("
                          << dvcs_result.events_filled[itopo][ivar] << ","
                          << pi0_data_result.events_filled[itopo][ivar] << ","
                          << pi0_rec_result.events_filled[itopo][ivar] << ","
                          << mis_result.events_filled[itopo][ivar]
                          << ")" << std::endl;
            }

            const std::string out_png = join_path(
                diag_dir,
                "pi0_contamination_vs_" + safe_file_token(varcfg.name) + "_" +
                safe_file_token(period) + "_topologies.png");
            plot_diagnostic_overlay(out_png, period, varcfg, rows_by_topology);
        }
    }

    const std::string csv_path =
        join_path(diag_dir, "pi0_contamination_vs_exclusivity_variables.csv");
    write_diagnostic_csv(csv_path, all_rows);

    std::cout << "[pi0_contamination] Wrote exclusivity-variable contamination diagnostics under: "
              << diag_dir << std::endl;
}

static void compute_period(CSV& csv,
                           const std::vector<RowBin>& bins,
                           const std::string& period,
                           const std::string& output_root_dir,
                           const Pi0ContaminationOptions& options) {
    const int c_contam = col_strict(csv, contamination_col(period));

    std::vector<RowContam> points;
    points.resize(csv.rows.size());

    Triple sum_Ndvcs;
    Triple sum_Nmis;
    Triple sum_Npi0_data;
    Triple sum_Npi0_rec;
    sum_Ndvcs.v = sum_Ndvcs.stat = sum_Ndvcs.sys = 0.0;
    sum_Nmis.v = sum_Nmis.stat = sum_Nmis.sys = 0.0;
    sum_Npi0_data.v = sum_Npi0_data.stat = sum_Npi0_data.sys = 0.0;
    sum_Npi0_rec.v = sum_Npi0_rec.stat = sum_Npi0_rec.sys = 0.0;

    for (int r = 0; r < (int)csv.rows.size(); ++r) {
        const RowBin& b = bins[r];

        if (!b.valid) {
            csv.rows[r][c_contam].clear();
            continue;
        }

        const std::vector<std::string>& row = csv.rows[r];

        const Triple Ndvcs = sum_topology_data_yield(csv, row, "ep->epg", period);
        const Triple Npi0_data = sum_topology_data_yield(csv, row, "ep->eppi0", period);
        const Triple Npi0_rec = sum_topology_mc_yield(csv, row, "ep->eppi0", period);
        const Triple Nmis = sum_topology_misid_mc_yield_with_current_mode(
            csv, row, period, options.use_epg_mc_current_factor_for_eppi0_bkg);

        const Triple tr = compute_contamination(Nmis, Npi0_data, Npi0_rec, Ndvcs);
        csv.rows[r][c_contam] = format_triple(tr);

        RowContam p;
        p.phi = phi_center(b.phimin, b.phimax);
        p.value = tr.v;
        p.stat = tr.stat;
        p.xBmin = b.xBmin;
        p.xBmax = b.xBmax;
        p.Q2min = b.Q2min;
        p.Q2max = b.Q2max;
        p.tmin = b.tmin;
        p.tmax = b.tmax;
        p.valid = true;
        points[r] = p;

        add_triple_in_quadrature(sum_Ndvcs, Ndvcs);
        add_triple_in_quadrature(sum_Npi0_data, Npi0_data);
        add_triple_in_quadrature(sum_Npi0_rec, Npi0_rec);
        add_triple_in_quadrature(sum_Nmis, Nmis);
    }

    const Triple integrated = compute_contamination(sum_Nmis, sum_Npi0_data, sum_Npi0_rec, sum_Ndvcs);

    std::cout << "[pi0_contamination] " << period
              << " totals: Ndvcs_norm=" << std::setprecision(10) << sum_Ndvcs.v
              << " Nmis_corr_mc=" << sum_Nmis.v
              << " Npi0_norm=" << sum_Npi0_data.v
              << " Npi0_rec_corr_mc=" << sum_Npi0_rec.v
              << " integrated_contam=" << integrated.v
              << " +/- " << integrated.stat
              << std::endl;

    plot_period_contamination(period, bins, points, output_root_dir);
}


// -------------------- analysis-note production outputs --------------------

struct NotePeriodSummary {
    std::string period;
    Triple Ndvcs;
    Triple Npi0_data;
    Triple Npi0_rec;
    Triple Nmis;
    Triple integrated;
    int n_positive_bins = 0;
    int n_above_50pct = 0;
    double median = 0.0;
    double p16 = 0.0;
    double p84 = 0.0;
    double p95 = 0.0;
};

static double quantile_sorted(const std::vector<double>& sorted, double q) {
    if (sorted.empty()) return 0.0;
    if (q <= 0.0) return sorted.front();
    if (q >= 1.0) return sorted.back();
    const double x = q * (sorted.size() - 1);
    const std::size_t i = static_cast<std::size_t>(std::floor(x));
    const std::size_t j = std::min(i + 1, sorted.size() - 1);
    const double f = x - i;
    return sorted[i] * (1.0 - f) + sorted[j] * f;
}

static Triple topology_data_yield(const CSV& csv, const std::vector<std::string>& row,
                                  const std::string& channel, const std::string& topo,
                                  const std::string& period) {
    const std::string colname = normalized_raw_yield_col(channel, topo, period, "unpol");
    return parse_yield_or_zero(row[col_strict(csv, colname)], colname);
}

static Triple topology_mc_yield(const CSV& csv, const std::vector<std::string>& row,
                                const std::string& channel, const std::string& topo,
                                const std::string& period) {
    const std::string colname = rec_current_corrected_yield_col(channel, topo, period);
    return parse_yield_or_zero(row[col_strict(csv, colname)], colname);
}

static std::vector<NotePeriodSummary> build_note_period_summaries(const CSV& csv,
                                                                  const std::vector<RowBin>& bins) {
    std::vector<NotePeriodSummary> out;
    for (const std::string& period : kPeriods) {
        NotePeriodSummary s;
        s.period = period;
        std::vector<double> values;
        const int cc = col_strict(csv, contamination_col(period));
        for (std::size_t r = 0; r < csv.rows.size(); ++r) {
            if (!bins[r].valid) continue;
            const auto& row = csv.rows[r];
            const Triple Ndvcs = sum_topology_data_yield(csv, row, "ep->epg", period);
            const Triple Npi0d = sum_topology_data_yield(csv, row, "ep->eppi0", period);
            const Triple Npi0m = sum_topology_mc_yield(csv, row, "ep->eppi0", period);
            const Triple Nmis  = sum_topology_mc_yield(csv, row, "ep->eppi0->epg", period);
            add_triple_in_quadrature(s.Ndvcs, Ndvcs);
            add_triple_in_quadrature(s.Npi0_data, Npi0d);
            add_triple_in_quadrature(s.Npi0_rec, Npi0m);
            add_triple_in_quadrature(s.Nmis, Nmis);
            const Triple c = parse_yield_or_zero(row[cc], contamination_col(period));
            if (c.v > 0.0 && std::isfinite(c.v)) {
                values.push_back(c.v);
                ++s.n_positive_bins;
                if (c.v > 0.50) ++s.n_above_50pct;
            }
        }
        s.integrated = compute_contamination(s.Nmis, s.Npi0_data, s.Npi0_rec, s.Ndvcs);
        std::sort(values.begin(), values.end());
        s.median = quantile_sorted(values, 0.50);
        s.p16 = quantile_sorted(values, 0.16);
        s.p84 = quantile_sorted(values, 0.84);
        s.p95 = quantile_sorted(values, 0.95);
        out.push_back(s);
    }
    return out;
}

static void write_note_summary_tables(const CSV& csv, const std::vector<RowBin>& bins,
                                      const std::vector<NotePeriodSummary>& summaries,
                                      const std::string& note_dir) {
    mkdir_p(note_dir);
    {
        std::ofstream f(join_path(note_dir, "pi0_contamination_summary.csv"));
        f << "period,Ndvcs_data,Npi0_data,Npi0_rec_mc,Nmis_mc,integrated_contamination,integrated_stat,"
             "positive_bins,median_bin_contamination,p16,p84,p95,bins_above_50pct\n";
        f << std::setprecision(10);
        for (const auto& s : summaries) {
            f << s.period << ',' << s.Ndvcs.v << ',' << s.Npi0_data.v << ',' << s.Npi0_rec.v << ','
              << s.Nmis.v << ',' << s.integrated.v << ',' << s.integrated.stat << ','
              << s.n_positive_bins << ',' << s.median << ',' << s.p16 << ',' << s.p84 << ','
              << s.p95 << ',' << s.n_above_50pct << '\n';
        }
    }
    {
        std::ofstream f(join_path(note_dir, "pi0_contamination_topology_summary.csv"));
        f << "period,topology,Ndvcs_data,Npi0_data,Npi0_rec_mc,Nmis_mc,contamination,stat\n";
        f << std::setprecision(10);
        for (const std::string& period : kPeriods) {
            for (const std::string& topo : kTopologies) {
                Triple Nd, Npd, Npm, Nm;
                for (std::size_t r = 0; r < csv.rows.size(); ++r) {
                    if (!bins[r].valid) continue;
                    const auto& row = csv.rows[r];
                    add_triple_in_quadrature(Nd, topology_data_yield(csv,row,"ep->epg",topo,period));
                    add_triple_in_quadrature(Npd,topology_data_yield(csv,row,"ep->eppi0",topo,period));
                    add_triple_in_quadrature(Npm,topology_mc_yield(csv,row,"ep->eppi0",topo,period));
                    add_triple_in_quadrature(Nm, topology_mc_yield(csv,row,"ep->eppi0->epg",topo,period));
                }
                const Triple c = compute_contamination(Nm,Npd,Npm,Nd);
                f << period << ',' << topo << ',' << Nd.v << ',' << Npd.v << ',' << Npm.v << ','
                  << Nm.v << ',' << c.v << ',' << c.stat << '\n';
            }
        }
    }
}

static int note_period_color(int ip) {
    // Stable run-period palette for analysis-note summary figures:
    // Fa18 Inb, Fa18 Out, Sp19 Inb, Sp18 Inb, Sp18 Out.
    const int colors[5] = {kBlue+1, kRed+1, kGreen+2, kMagenta+1, kOrange+7};
    return colors[ip];
}

static void draw_note_period_topology_summary(const CSV& csv, const std::vector<RowBin>& bins,
                                              const std::vector<NotePeriodSummary>& summaries,
                                              const std::string& note_dir) {
    TCanvas c("c_note_pi0_period_topology", "", 1150, 700);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.16); c.SetTopMargin(0.10);
    c.SetGridy(); c.SetTicks(1,1);
    TH1F frame("h_note_pi0_period_topology", "", 5, 0.5, 5.5);
    frame.SetMinimum(0.0); frame.SetMaximum(0.50);
    frame.GetYaxis()->SetTitle("Integrated #pi^{0} contamination");
    frame.GetYaxis()->SetTitleOffset(1.25); frame.GetYaxis()->SetTitleSize(0.050); frame.GetYaxis()->SetLabelSize(0.043);
    frame.GetXaxis()->SetLabelSize(0.045);
    for (int i=0;i<5;++i) frame.GetXaxis()->SetBinLabel(i+1,kPeriods[i].c_str());
    frame.Draw();

    const int markers[4] = {20,24,25,26};
    const int colors[4] = {kBlack, kBlue+1, kRed+1, kGreen+2};
    const char* labels[4] = {"Production (topology summed)","FD-FD diagnostic","CD-FD diagnostic","CD-FT diagnostic"};
    std::vector<TGraphErrors*> gs;
    for (int j=0;j<4;++j) {
        auto* g=new TGraphErrors();
        g->SetMarkerStyle(markers[j]);
        g->SetMarkerSize(1.25);
        g->SetMarkerColor(colors[j]);
        g->SetLineColor(colors[j]);
        g->SetLineWidth(2);
        gs.push_back(g);
    }
    for (int ip=0;ip<5;++ip) {
        gs[0]->SetPoint(ip,ip+1,summaries[ip].integrated.v); gs[0]->SetPointError(ip,0,summaries[ip].integrated.stat);
        for (int it=0;it<3;++it) {
            Triple Nd,Npd,Npm,Nm;
            for (std::size_t r=0;r<csv.rows.size();++r) {
                if(!bins[r].valid) continue; const auto& row=csv.rows[r]; const auto& topo=kTopologies[it]; const auto& period=kPeriods[ip];
                add_triple_in_quadrature(Nd,topology_data_yield(csv,row,"ep->epg",topo,period));
                add_triple_in_quadrature(Npd,topology_data_yield(csv,row,"ep->eppi0",topo,period));
                add_triple_in_quadrature(Npm,topology_mc_yield(csv,row,"ep->eppi0",topo,period));
                add_triple_in_quadrature(Nm,topology_mc_yield(csv,row,"ep->eppi0->epg",topo,period));
            }
            const Triple q=compute_contamination(Nm,Npd,Npm,Nd); const double dx=(it-1)*0.10;
            gs[it+1]->SetPoint(ip,ip+1+dx,q.v); gs[it+1]->SetPointError(ip,0,q.stat);
        }
    }
    for(auto* g:gs) g->Draw("PE SAME");
    TLegend leg(0.15,0.54,0.51,0.74); leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.034);
    for(int j=0;j<4;++j) leg.AddEntry(gs[j],labels[j],"pe"); leg.Draw();
    TLatex t; t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048); t.DrawLatex(0.11,0.93,"#pi^{0} background normalization by run period and topology");
    c.SaveAs(join_path(note_dir,"pi0_contamination_period_topology_summary.png").c_str());
    for(auto* g:gs) delete g;
}

static void draw_note_distribution(const CSV& csv, const std::vector<RowBin>& bins,
                                   const std::string& note_dir) {
    TCanvas c("c_note_pi0_distribution", "", 1100, 720);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10); c.SetTicks(1,1);
    std::vector<TH1D*> hs;
    const int markers[5]={20,21,22,23,33};
    double ymax=0.0;
    for(int ip=0;ip<5;++ip){
        auto* h=new TH1D(("h_note_pi0_dist_"+std::to_string(ip)).c_str(),"",30,0.0,0.60);
        const int cc=col_strict(csv,contamination_col(kPeriods[ip]));
        for(std::size_t r=0;r<csv.rows.size();++r){ if(!bins[r].valid) continue; const Triple q=parse_yield_or_zero(csv.rows[r][cc],contamination_col(kPeriods[ip])); if(q.v>0.0 && q.v<0.60) h->Fill(q.v); }
        if(h->Integral()>0) h->Scale(1.0/h->Integral());
        h->SetMarkerStyle(markers[ip]);
        h->SetMarkerSize(0.9);
        h->SetMarkerColor(note_period_color(ip));
        h->SetLineColor(note_period_color(ip));
        h->SetLineWidth(2);
        h->GetXaxis()->SetTitle("#pi^{0} contamination");
        h->GetYaxis()->SetTitle("Fraction of populated analysis bins");
        ymax=std::max(ymax,h->GetMaximum()); hs.push_back(h);
    }
    if(!hs.empty()){ hs[0]->SetMaximum(1.30*ymax); hs[0]->SetMinimum(0.0); hs[0]->GetXaxis()->SetTitleSize(0.050); hs[0]->GetYaxis()->SetTitleSize(0.050); hs[0]->GetYaxis()->SetTitleOffset(1.15); hs[0]->Draw("HIST P"); for(std::size_t i=1;i<hs.size();++i) hs[i]->Draw("HIST P SAME"); }
    TLegend leg(0.69,0.60,0.94,0.88); leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.038); for(int ip=0;ip<5;++ip) leg.AddEntry(hs[ip],kPeriods[ip].c_str(),"lp"); leg.Draw();
    TLatex t; t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048); t.DrawLatex(0.11,0.93,"Distribution of bin-by-bin #pi^{0} contamination");
    TLatex n; n.SetNDC(); n.SetTextFont(42); n.SetTextSize(0.030); n.DrawLatex(0.12,0.84,"Shown: 0 < c_{#pi^{0}} < 0.60; higher values are retained in the summary table");
    c.SaveAs(join_path(note_dir,"pi0_contamination_distribution_by_period.png").c_str());
    for(auto* h:hs) delete h;
}

static void draw_note_xb_summary(const CSV& csv, const std::vector<RowBin>& bins,
                                 const std::string& note_dir) {
    std::vector<std::pair<double,double>> xedges;
    for(const auto& b:bins){
        if(!b.valid) continue;
        std::pair<double,double> e{b.xBmin,b.xBmax};
        if(std::find(xedges.begin(),xedges.end(),e)==xedges.end()) xedges.push_back(e);
    }
    std::sort(xedges.begin(),xedges.end());

    TCanvas c("c_note_pi0_xb", "", 1100, 720);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10);
    c.SetGridy(); c.SetTicks(1,1);

    TH1F frame("h_note_pi0_xb","",100,0.05,0.60);
    frame.SetMinimum(0);
    frame.SetMaximum(0.55);
    frame.GetXaxis()->SetTitle("x_{B}");
    frame.GetYaxis()->SetTitle("Median #pi^{0} contamination");
    frame.GetYaxis()->SetTitleOffset(1.15);
    frame.GetXaxis()->SetTitleSize(0.050);
    frame.GetYaxis()->SetTitleSize(0.050);
    frame.Draw();

    const int markers[5]={20,21,22,23,33};
    // Display-only horizontal offsets keep the five periods visually separable.
    // The underlying x_B bin centers and all numerical results are unchanged.
    const double x_offsets[5]={-0.006,-0.003,0.0,0.003,0.006};

    std::vector<TGraphAsymmErrors*> gs;
    for(int ip=0;ip<5;++ip){
        auto* g=new TGraphAsymmErrors();
        g->SetMarkerStyle(markers[ip]);
        g->SetMarkerSize(1.1);
        g->SetMarkerColor(note_period_color(ip));
        g->SetLineColor(note_period_color(ip));
        g->SetLineWidth(2);

        const int cc=col_strict(csv,contamination_col(kPeriods[ip]));
        int n=0;
        for(const auto& xe:xedges){
            std::vector<double> v;
            for(std::size_t r=0;r<bins.size();++r){
                if(!bins[r].valid || bins[r].xBmin!=xe.first || bins[r].xBmax!=xe.second) continue;
                const Triple q=parse_yield_or_zero(csv.rows[r][cc],contamination_col(kPeriods[ip]));
                if(q.v>0 && std::isfinite(q.v)) v.push_back(q.v);
            }
            if(v.empty()) continue;

            std::sort(v.begin(),v.end());
            const double med=quantile_sorted(v,.50);
            const double lo =quantile_sorted(v,.16);
            const double hi =quantile_sorted(v,.84);
            const double x_center=0.5*(xe.first+xe.second);

            g->SetPoint(n,x_center+x_offsets[ip],med);
            g->SetPointError(n,0,0,med-lo,hi-med);
            ++n;
        }
        g->Draw("PE SAME");
        gs.push_back(g);
    }

    TLegend leg(0.70,0.57,0.94,0.79);
    leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.036);
    for(int ip=0;ip<5;++ip) leg.AddEntry(gs[ip],kPeriods[ip].c_str(),"pe");
    leg.Draw();

    TLatex t;
    t.SetNDC(); t.SetTextFont(42); t.SetTextSize(0.048);
    t.DrawLatex(0.11,0.93,"Kinematic dependence of the #pi^{0} contamination");

    TLatex n;
    n.SetNDC(); n.SetTextFont(42); n.SetTextSize(0.029);
    n.DrawLatex(0.12,0.84,
                "Points: median over populated (Q^{2}, |t|, #phi) bins; bars: 16th--84th percentile bin-to-bin range");

    c.SaveAs(join_path(note_dir,"pi0_contamination_vs_xB_summary.png").c_str());
    for(auto* g:gs) delete g;
}


struct NotePhiCellKey {
    double xmin=0, xmax=0, qmin=0, qmax=0, tmin=0, tmax=0;
};

static bool same_note_phi_cell(const RowBin& b, const NotePhiCellKey& k) {
    const double eps=1e-10;
    return std::fabs(b.xBmin-k.xmin)<eps && std::fabs(b.xBmax-k.xmax)<eps &&
           std::fabs(b.Q2min-k.qmin)<eps && std::fabs(b.Q2max-k.qmax)<eps &&
           std::fabs(b.tmin-k.tmin)<eps && std::fabs(b.tmax-k.tmax)<eps;
}

static void draw_note_phi_example(const CSV& csv, const std::vector<RowBin>& bins,
                                  const std::string& note_dir) {
    // Prefer the central x_B interval 0.204--0.268, then choose the (Q2,|t|)
    // cell with the largest minimum number of populated phi bins across periods.
    // This makes the example deterministic while avoiding a hand-picked phi shape.
    const double target_xmin=0.204;
    const double target_xmax=0.268;

    std::vector<NotePhiCellKey> keys;
    for(const auto& b:bins){
        if(!b.valid) continue;
        if(std::fabs(b.xBmin-target_xmin)>1e-10 || std::fabs(b.xBmax-target_xmax)>1e-10) continue;
        NotePhiCellKey k{b.xBmin,b.xBmax,b.Q2min,b.Q2max,b.tmin,b.tmax};
        bool seen=false;
        for(const auto& x:keys){
            if(std::fabs(x.qmin-k.qmin)<1e-10 && std::fabs(x.qmax-k.qmax)<1e-10 &&
               std::fabs(x.tmin-k.tmin)<1e-10 && std::fabs(x.tmax-k.tmax)<1e-10){
                seen=true; break;
            }
        }
        if(!seen) keys.push_back(k);
    }
    if(keys.empty()) return;

    int best_score=-1;
    int best_total=-1;
    NotePhiCellKey best=keys.front();

    for(const auto& k:keys){
        int min_positive=1000000;
        int total_positive=0;
        for(int ip=0;ip<5;++ip){
            const int cc=col_strict(csv,contamination_col(kPeriods[ip]));
            int npos=0;
            for(std::size_t r=0;r<bins.size();++r){
                if(!bins[r].valid || !same_note_phi_cell(bins[r],k)) continue;
                const Triple q=parse_yield_or_zero(csv.rows[r][cc],contamination_col(kPeriods[ip]));
                if(q.v>0 && std::isfinite(q.v)) ++npos;
            }
            min_positive=std::min(min_positive,npos);
            total_positive+=npos;
        }
        if(min_positive>best_score || (min_positive==best_score && total_positive>best_total)){
            best_score=min_positive;
            best_total=total_positive;
            best=k;
        }
    }

    std::ofstream fout(join_path(note_dir,"pi0_contamination_phi_example.csv"));
    fout << "period,xBmin,xBmax,Q2min,Q2max,tmin,tmax,phimin,phimax,phi_center,contamination,stat\n";
    fout << std::setprecision(10);

    TCanvas c("c_note_pi0_phi_example","",1100,720);
    c.SetLeftMargin(0.11); c.SetRightMargin(0.035); c.SetBottomMargin(0.12); c.SetTopMargin(0.10);
    c.SetGridy(); c.SetTicks(1,1);

    double ymax=0.0;
    for(int ip=0;ip<5;++ip){
        const int cc=col_strict(csv,contamination_col(kPeriods[ip]));
        for(std::size_t r=0;r<bins.size();++r){
            if(!bins[r].valid || !same_note_phi_cell(bins[r],best)) continue;
            const Triple q=parse_yield_or_zero(csv.rows[r][cc],contamination_col(kPeriods[ip]));
            if(q.v>0 && std::isfinite(q.v))
                ymax=std::max(ymax,q.v+q.stat);
        }
    }
    const double plot_ymax=std::max(0.20,std::min(0.80,1.18*ymax));

    TH1F frame("h_note_pi0_phi_example","",100,0.0,360.0);
    frame.SetMinimum(0.0);
    frame.SetMaximum(plot_ymax);
    frame.GetXaxis()->SetTitle("#phi (deg)");
    frame.GetYaxis()->SetTitle("#pi^{0} contamination");
    frame.GetYaxis()->SetTitleOffset(1.15);
    frame.GetXaxis()->SetTitleSize(0.050);
    frame.GetYaxis()->SetTitleSize(0.050);
    frame.Draw();

    const int markers[5]={20,21,22,23,33};
    const double phi_offsets[5]={-2.0,-1.0,0.0,1.0,2.0};
    std::vector<TGraphErrors*> gs;

    for(int ip=0;ip<5;++ip){
        auto* g=new TGraphErrors();
        g->SetMarkerStyle(markers[ip]);
        g->SetMarkerSize(1.05);
        g->SetMarkerColor(note_period_color(ip));
        g->SetLineColor(note_period_color(ip));
        g->SetLineWidth(2);

        const int cc=col_strict(csv,contamination_col(kPeriods[ip]));
        int n=0;
        for(std::size_t r=0;r<bins.size();++r){
            if(!bins[r].valid || !same_note_phi_cell(bins[r],best)) continue;
            const Triple q=parse_yield_or_zero(csv.rows[r][cc],contamination_col(kPeriods[ip]));
            if(!(q.v>0) || !std::isfinite(q.v)) continue;

            const double pc=0.5*(bins[r].phimin+bins[r].phimax);
            g->SetPoint(n,pc+phi_offsets[ip],q.v);
            g->SetPointError(n,0,q.stat);

            fout << kPeriods[ip] << ',' << best.xmin << ',' << best.xmax << ','
                 << best.qmin << ',' << best.qmax << ',' << best.tmin << ',' << best.tmax << ','
                 << bins[r].phimin << ',' << bins[r].phimax << ',' << pc << ','
                 << q.v << ',' << q.stat << '\n';
            ++n;
        }
        g->Draw("PE SAME");
        gs.push_back(g);
    }

    TLegend leg(0.70,0.60,0.94,0.86);
    leg.SetBorderSize(0); leg.SetFillStyle(0); leg.SetTextSize(0.036);
    for(int ip=0;ip<5;++ip) leg.AddEntry(gs[ip],kPeriods[ip].c_str(),"pe");
    leg.Draw();

    TLatex title;
    title.SetNDC(); title.SetTextFont(42); title.SetTextSize(0.048);
    title.DrawLatex(0.11,0.93,"Representative #phi dependence of the #pi^{0} contamination");

    std::ostringstream kin;
    kin << std::fixed << std::setprecision(3)
        << best.xmin << " < x_{B} < " << best.xmax
        << ",  " << best.qmin << " < Q^{2} < " << best.qmax << " GeV^{2}"
        << ",  " << best.tmin << " < |t| < " << best.tmax << " GeV^{2}";
    TLatex lab;
    lab.SetNDC(); lab.SetTextFont(42); lab.SetTextSize(0.028);
    lab.DrawLatex(0.12,0.84,kin.str().c_str());

    TLatex note;
    note.SetNDC(); note.SetTextFont(42); note.SetTextSize(0.027);
    note.DrawLatex(0.12,0.795,"Error bars: propagated statistical uncertainty on c_{#pi^{0}} in each analysis bin");

    c.SaveAs(join_path(note_dir,"pi0_contamination_phi_example.png").c_str());
    for(auto* g:gs) delete g;
}


static void write_analysis_note_outputs(const CSV& csv, const std::vector<RowBin>& bins,
                                        const std::string& output_root_dir) {
    const std::string note_dir=join_path(join_path(output_root_dir,"pi0_contamination_plots"),"analysis_note");
    mkdir_p(note_dir);
    const auto summaries=build_note_period_summaries(csv,bins);
    write_note_summary_tables(csv,bins,summaries,note_dir);
    draw_note_period_topology_summary(csv,bins,summaries,note_dir);
    draw_note_distribution(csv,bins,note_dir);
    draw_note_xb_summary(csv,bins,note_dir);
    draw_note_phi_example(csv,bins,note_dir);
    std::cout << "[pi0_contamination] Analysis-note outputs written under: " << note_dir << std::endl;
}

} // namespace

bool compute_pi0_contamination_overall(
    const std::map<std::string, TTree*> &dvcsDataTrees,
    const std::map<std::string, TTree*> &eppi0DataTrees,
    const std::map<std::string, TTree*> &eppi0RecMcTrees,
    const std::map<std::string, TTree*> &eppi0BkgTrees,
    const std::string &combined_cuts_json,
    const std::string &csv_main,
    const std::string &output_root_dir,
    int max_workers,
    const Pi0ContaminationOptions& options) {
    (void)max_workers;

    try {
        TH1::AddDirectory(kFALSE);
        gStyle->SetOptStat(0);

        CSV csv;
        load_csv(csv_main, csv);
        const std::vector<RowBin> bins = load_row_bins(csv);

        if (bins.size() != csv.rows.size()) {
            fatal("[pi0_contamination] FATAL: internal row/bin size mismatch.");
        }

        std::cout << "[pi0_contamination] Misidentified ep->eppi0->epg MC current correction mode: "
                  << (options.use_epg_mc_current_factor_for_eppi0_bkg
                          ? "ep->epg MC factor (default)"
                          : "ep->eppi0 MC factor (legacy)")
                  << std::endl;

        for (const std::string& period : kPeriods) {
            compute_period(csv, bins, period, output_root_dir, options);
        }

        const DiagnosticTopoCutMap diagnostic_data_cuts =
            load_diagnostic_combined_cuts(combined_cuts_json, "data");
        const DiagnosticTopoCutMap diagnostic_mc_cuts =
            load_diagnostic_combined_cuts(combined_cuts_json, "mc");

        make_exclusivity_variable_diagnostics(csv,
                                              bins,
                                              dvcsDataTrees,
                                              eppi0DataTrees,
                                              eppi0RecMcTrees,
                                              eppi0BkgTrees,
                                              diagnostic_data_cuts,
                                              diagnostic_mc_cuts,
                                              output_root_dir);

        write_analysis_note_outputs(csv, bins, output_root_dir);

        write_csv_atomic(csv_main, csv);

        std::cout << "[pi0_contamination] Updated contamination columns in: "
                  << csv_main << std::endl;
        std::cout << "[pi0_contamination] Plots written under: "
                  << join_path(output_root_dir, "pi0_contamination_plots") << std::endl;

        return true;
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return false;
    }
}
