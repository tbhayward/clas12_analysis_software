#ifndef CROSS_SECTIONS_H
#define CROSS_SECTIONS_H

#include <map>
#include <string>

// Simple triple used throughout:
//   value = main quantity
//   stat  = statistical component
//   sys   = systematic component (often 0 here)
struct Triple {
    double value;
    double stat;
    double sys;
};

// Map from period/group label to its luminosity triple.
// Convention for LumiMap entries:
//   value = total (unpolarized) accumulated charge
//   stat  = + helicity accumulated charge
//   sys   = - helicity accumulated charge
using LumiMap = std::map<std::string, Triple>;

// Options controlling the single authoritative charge input.
struct LumiBuildOptions {
    std::string charge_csv_path =
        "imports/integrated_luminosity/global.csv";
};

// Build the luminosity/charge map from the single authoritative global.csv,
// summing column 2 over the exact final Pass-2 selected run lists.
LumiMap build_lumi_map();

// Build luminosity map with explicit charge-column convention control.
LumiMap build_lumi_map(const LumiBuildOptions &options);

// Update dvcs_pass2_analysis.csv:
//   - Fill integrated luminosity columns using lumi_map.
//   - Compute cross sections from already-corrected, already-unfolded yields:
//       acceptance corrected yield, ep->epg, exp, <label>, <helicity>
//   - Import Frad/Fbin directly from imports/all_bin_v3.csv.
//   - Write those imported Frad/Fbin values into both 10.6 GeV and 10.2 GeV CSV columns.
//   - Read the phase-space-allowed bin_volume from the pass-2 CSV columns
//     filled by bin_volume.cpp; do not import or overwrite bin_volume from Lee's CSV.
//   - Do not apply imports/efficiency.json or any additional normalization.
// Returns true on success, false on any fatal CSV or I/O problem.
bool compute_cross_sections(const std::string &csv_main,
                            const LumiMap &lumi_map);

// Same as above, but lets the caller explicitly choose the Lee/pass-1 CSV.
// The expected source columns are:
//   Frad
//   Fbin
// matched by the pass-2 CSV "bin index" column.
// The Lee bin_volume column, if present, is intentionally ignored.
bool compute_cross_sections(const std::string &csv_main,
                            const LumiMap &lumi_map,
                            const std::string &lee_csv_path);

// Produce compact analysis-note support material for the cross-section
// determination section. No model comparisons or validation plots are made.
bool write_cross_section_analysis_note_outputs(
    const std::string &csv_main,
    const LumiMap &lumi_map,
    const std::string &out_dir = "output/cross_sections/analysis_note");

// Plot cross sections vs phi for a given label:
//   - Reads cross section columns for that label from csv_main.
//   - Groups rows by xB range, then lays out subpads in Q2 x |t| grid.
//   - Uses log scale on Y.
//   - Uses a single legend at the top of the canvas.
//   - Overlays BH/KM/VGG theory curves if a xs_phi_all.json exists for
//     this label under theory_json_root.
// Saves PNGs under out_root_dir/<PeriodDir>/.
//
// Returns true on success. If the required cross section columns for this
// particular label do not exist, it prints a message and returns true
// (nothing to plot for that label).
bool plot_cross_sections_for_label(const std::string &csv_main,
                                   const std::string &label,
                                   const std::string &theory_json_root,
                                   const std::string &out_root_dir);

// Regenerate BH / KM / VGG theory curves vs phi and write:
//   output/jsons/cross_sections/10.6_GeV/xs_phi_all.json
//   output/jsons/cross_sections/10.2_GeV/xs_phi_all.json
//
// This function overwrites any existing files. It does NOT modify the CSV.
bool regenerate_theory_jsons(const std::string &csv_main,
                             const std::string &theory_json_root);

#endif // CROSS_SECTIONS_H