#include "pass1_systematics_import.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

struct CsvTable {
    std::vector<std::string> header;
    std::vector<std::vector<std::string> > rows;
    std::unordered_map<std::string, int> index;
};

static std::string trim(const std::string& s) {
    size_t b = 0;
    while (b < s.size() && std::isspace((unsigned char)s[b])) {
        ++b;
    }
    size_t e = s.size();
    while (e > b && std::isspace((unsigned char)s[e - 1])) {
        --e;
    }
    return s.substr(b, e - b);
}

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    cur.reserve(line.size());
    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (c == '"') {
            if (in_quotes && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }
    out.push_back(cur);
    return out;
}

static std::string join_csv_row(const std::vector<std::string>& fields) {
    std::ostringstream oss;
    for (size_t i = 0; i < fields.size(); ++i) {
        const std::string& s = fields[i];
        const bool need_quotes =
            s.find(',') != std::string::npos ||
            s.find('"') != std::string::npos ||
            s.find('\n') != std::string::npos ||
            s.find('\r') != std::string::npos;

        if (need_quotes) {
            oss << '"';
            for (const char ch : s) {
                if (ch == '"') {
                    oss << "\"\"";
                } else {
                    oss << ch;
                }
            }
            oss << '"';
        } else {
            oss << s;
        }
        if (i + 1 < fields.size()) {
            oss << ',';
        }
    }
    return oss.str();
}

static std::unordered_map<std::string, int>
build_header_index(const std::vector<std::string>& header) {
    std::unordered_map<std::string, int> idx;
    for (int i = 0; i < (int)header.size(); ++i) {
        idx[header[(size_t)i]] = i;
    }
    return idx;
}

static void assert_no_duplicate_columns(const std::vector<std::string>& header,
                                        const std::string& path) {
    std::set<std::string> seen;
    std::set<std::string> duplicates;
    for (const auto& name : header) {
        if (!seen.insert(name).second) {
            duplicates.insert(name);
        }
    }
    if (!duplicates.empty()) {
        std::ostringstream msg;
        msg << "CSV header contains duplicate columns in " << path << ":";
        for (const auto& name : duplicates) {
            msg << "\n  - " << name;
        }
        throw std::runtime_error(msg.str());
    }
}

static CsvTable read_csv_or_throw(const std::string& path) {
    std::ifstream fin(path);
    if (!fin.is_open()) {
        throw std::runtime_error("Could not open CSV: " + path);
    }

    CsvTable table;
    std::string line;
    if (!std::getline(fin, line)) {
        throw std::runtime_error("CSV is empty: " + path);
    }

    table.header = split_csv_line(line);
    if (!table.header.empty()) {
        std::string first = table.header[0];
        std::string low;
        low.reserve(first.size());
        for (const char c : first) {
            low.push_back((char)std::tolower((unsigned char)c));
        }
        if (first.empty() || low.find("unnamed") != std::string::npos) {
            table.header[0] = "bin index";
        }
    }

    assert_no_duplicate_columns(table.header, path);
    table.index = build_header_index(table.header);

    while (std::getline(fin, line)) {
        if (line.empty()) {
            continue;
        }
        std::vector<std::string> row = split_csv_line(line);
        if (row.size() < table.header.size()) {
            row.resize(table.header.size());
        }
        if (row.size() != table.header.size()) {
            std::ostringstream msg;
            msg << "CSV row has " << row.size() << " columns but header has "
                << table.header.size() << " columns in " << path;
            throw std::runtime_error(msg.str());
        }
        table.rows.push_back(std::move(row));
    }

    return table;
}

static void write_csv_or_throw(const std::string& path, const CsvTable& table) {
    const std::string tmp_path = path + ".tmp";
    std::ofstream fout(tmp_path);
    if (!fout.is_open()) {
        throw std::runtime_error("Could not open temporary CSV for writing: " + tmp_path);
    }

    fout << join_csv_row(table.header) << "\n";
    for (const auto& row : table.rows) {
        if (row.size() != table.header.size()) {
            throw std::runtime_error("Internal CSV row/header size mismatch while writing " + path);
        }
        fout << join_csv_row(row) << "\n";
    }

    fout.close();
    if (!fout) {
        throw std::runtime_error("Failed while writing temporary CSV: " + tmp_path);
    }

    std::remove(path.c_str());
    if (std::rename(tmp_path.c_str(), path.c_str()) != 0) {
        throw std::runtime_error("Could not replace CSV with temporary file: " + path);
    }
}

static bool has_column(const CsvTable& table, const std::string& name) {
    return table.index.find(name) != table.index.end();
}

static int column_or_throw(const CsvTable& table,
                           const std::string& name,
                           const std::string& context) {
    const auto it = table.index.find(name);
    if (it == table.index.end()) {
        throw std::runtime_error("Missing required column for " + context + ": " + name);
    }
    return it->second;
}

static std::string get_cell(const std::vector<std::string>& row,
                            const CsvTable& table,
                            const std::string& name) {
    const auto it = table.index.find(name);
    if (it == table.index.end()) {
        return std::string();
    }
    const int col = it->second;
    if (col < 0 || col >= (int)row.size()) {
        return std::string();
    }
    return row[(size_t)col];
}

static double to_double(const std::string& s) {
    const std::string t = trim(s);
    if (t.empty()) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    char* endp = nullptr;
    const double v = std::strtod(t.c_str(), &endp);
    if (endp == t.c_str()) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    return v;
}

static int to_int(const std::string& s) {
    const std::string t = trim(s);
    if (t.empty()) {
        return 0;
    }
    char* endp = nullptr;
    const long v = std::strtol(t.c_str(), &endp, 10);
    if (endp == t.c_str()) {
        return 0;
    }
    return (int)v;
}

static std::string format_double(double value) {
    if (!std::isfinite(value)) {
        return std::string();
    }
    std::ostringstream oss;
    oss << std::setprecision(12) << value;
    return oss.str();
}


static bool parse_tuple_first(const std::string& raw, double& value) {
    std::string s = trim(raw);

    while (s.size() >= 2 && s.front() == '"' && s.back() == '"') {
        s = trim(s.substr(1, s.size() - 2));
    }

    if (s.empty()) return false;

    if (s.front() != '(') {
        value = to_double(s);
        return std::isfinite(value);
    }

    if (s.back() != ')') return false;

    s = s.substr(1, s.size() - 2);
    const size_t comma = s.find(',');
    const std::string first =
        (comma == std::string::npos) ? s : s.substr(0, comma);

    value = to_double(first);
    return std::isfinite(value);
}

static int ensure_column(CsvTable& table,
                         const std::string& name,
                         const std::string& initial_value = "") {
    const auto it = table.index.find(name);
    if (it != table.index.end()) return it->second;

    const int idx = static_cast<int>(table.header.size());
    table.header.push_back(name);
    table.index[name] = idx;

    for (auto& row : table.rows) row.push_back(initial_value);

    return idx;
}

static constexpr double kSp19RadiativeSystematicScale = 1.05;

static const std::string& sp19_radiative_systematic_column() {
    static const std::string col =
        "Syst.err (Frad), Sp19 Inb (10.2 GeV)";
    return col;
}

static const std::string& sp19_bin_centering_systematic_column() {
    static const std::string col =
        "Syst.err (Fbin), Sp19 Inb (10.2 GeV)";
    return col;
}

static const std::string& ten6_normed_cross_section_column() {
    static const std::string col =
        "normed cross sections, ep->epg, exp, 10.6 GeV, unpol";
    return col;
}

static const std::string& sp19_normed_cross_section_column() {
    static const std::string col =
        "normed cross sections, ep->epg, exp, Sp19 Inb, unpol";
    return col;
}

static const std::vector<std::string>& pass1_systematic_component_columns() {
    static const std::vector<std::string> cols = {
        "Syst. err (Acceptance)",
        "Syst.err (Frad)",
        "Syst.err (Fbin)"
    };
    return cols;
}

static const std::string& pass1_systematic_total_column() {
    static const std::string col = "Syst. err (point-to-point total)";
    return col;
}

static const std::vector<std::string>& pass1_systematic_destination_columns() {
    // Only the legacy components that are not regenerated in pass 2 are
    // imported here.  The pi0-subtraction systematic is now recalculated from
    // the pass-2 contamination and acceptance-corrected yields by
    // pi0_systematics.cpp.
    static const std::vector<std::string> cols = {
        "Syst. err (Acceptance)",
        "Syst.err (Frad)",
        "Syst.err (Fbin)"
    };
    return cols;
}

static const std::vector<std::string>& all_point_to_point_component_columns() {
    static const std::vector<std::string> cols = {
        "Syst. err (pi0 subtraction)",
        "Syst. err (Acceptance)",
        "Syst.err (Frad)",
        "Syst.err (Fbin)",
        "Syst. err (exclusivity cuts)",
        "Syst. err (fiducial cuts)"
    };
    return cols;
}

static double quadrature_total_from_components(const std::map<std::string, std::string>& values) {
    double sum2 = 0.0;
    bool any = false;
    for (const auto& col : pass1_systematic_component_columns()) {
        const auto it = values.find(col);
        if (it == values.end()) {
            continue;
        }
        const double v = to_double(it->second);
        if (!std::isfinite(v)) {
            continue;
        }
        sum2 += v * v;
        any = true;
    }
    return any ? std::sqrt(sum2) : std::numeric_limits<double>::quiet_NaN();
}

static double full_point_to_point_total_from_row(const CsvTable& table,
                                                  const std::vector<std::string>& row) {
    double sum2 = 0.0;
    for (const auto& col : all_point_to_point_component_columns()) {
        const int j = column_or_throw(table, col, "point-to-point total recomputation");
        const double v = to_double(row[(size_t)j]);
        if (!std::isfinite(v) || v < 0.0) {
            return std::numeric_limits<double>::quiet_NaN();
        }
        sum2 += v * v;
    }
    return std::sqrt(sum2);
}

struct Pass1SystValues {
    bool used = false;
    std::map<std::string, std::string> values;
    // Fractional model-dependent uncertainties are retained separately.
    // Frad and Fbin uncertainties are properties of the correction factors,
    // so when they are transferred to the new cross section they must be
    // applied fractionally rather than copied as absolute cross-section errors.
    std::map<std::string, double> relative_values;
};

struct KinematicPoint {
    double xb = std::numeric_limits<double>::quiet_NaN();
    double q2 = std::numeric_limits<double>::quiet_NaN();
    double t = std::numeric_limits<double>::quiet_NaN();
    double phi = std::numeric_limits<double>::quiet_NaN();
};

struct Pass1SourceRow {
    int bin_index = 0;
    KinematicPoint point;
    Pass1SystValues values;
};

static KinematicPoint point_from_pass1_row(const CsvTable& table,
                                           const std::vector<std::string>& row) {
    KinematicPoint p;
    p.xb = 0.5 * (to_double(get_cell(row, table, "xBmin")) +
                  to_double(get_cell(row, table, "xBmax")));
    p.q2 = 0.5 * (to_double(get_cell(row, table, "Q2min")) +
                  to_double(get_cell(row, table, "Q2max")));
    p.t = 0.5 * (to_double(get_cell(row, table, "tmin")) +
                 to_double(get_cell(row, table, "tmax")));
    p.phi = 0.5 * (to_double(get_cell(row, table, "phimin")) +
                   to_double(get_cell(row, table, "phimax")));
    return p;
}

static KinematicPoint point_from_pass2_row(const CsvTable& table,
                                           const std::vector<std::string>& row) {
    KinematicPoint p;
    p.xb = 0.5 * (to_double(get_cell(row, table, "xBmin")) +
                  to_double(get_cell(row, table, "xBmax")));
    p.q2 = 0.5 * (to_double(get_cell(row, table, "Q2min")) +
                  to_double(get_cell(row, table, "Q2max")));
    p.t = 0.5 * (to_double(get_cell(row, table, "t_abs_min")) +
                 to_double(get_cell(row, table, "t_abs_max")));
    p.phi = 0.5 * (to_double(get_cell(row, table, "phimin")) +
                   to_double(get_cell(row, table, "phimax")));
    return p;
}

static bool finite_point(const KinematicPoint& p) {
    return std::isfinite(p.xb) && std::isfinite(p.q2) &&
           std::isfinite(p.t) && std::isfinite(p.phi);
}

static bool point_less(const KinematicPoint& a, const KinematicPoint& b) {
    if (a.xb != b.xb) return a.xb < b.xb;
    if (a.q2 != b.q2) return a.q2 < b.q2;
    if (a.t != b.t) return a.t < b.t;
    return a.phi < b.phi;
}

static double periodic_phi_delta(double a, double b) {
    double d = std::fabs(a - b);
    while (d >= 360.0) d -= 360.0;
    return std::min(d, 360.0 - d);
}

static double kinematic_distance2(const KinematicPoint& a,
                                  const KinematicPoint& b) {
    // Scale each coordinate by a representative analysis-bin spacing so the
    // four dimensions contribute comparably to the neighbor search.
    const double dxb = (a.xb - b.xb) / 0.04;
    const double dq2 = (a.q2 - b.q2) / 0.30;
    const double dt = (a.t - b.t) / 0.20;
    const double dphi = periodic_phi_delta(a.phi, b.phi) / 15.0;
    return dxb*dxb + dq2*dq2 + dt*dt + dphi*dphi;
}

static bool average_neighbor_values(const Pass1SourceRow& below,
                                    const Pass1SourceRow& above,
                                    Pass1SystValues& out) {
    out.values.clear();
    for (const auto& col : pass1_systematic_component_columns()) {
        const double lo = to_double(below.values.values.at(col));
        const double hi = to_double(above.values.values.at(col));
        if (!std::isfinite(lo) || !std::isfinite(hi)) {
            return false;
        }
        out.values[col] = format_double(0.5 * (lo + hi));
    }
    for (const auto& col : std::vector<std::string>{"Syst.err (Frad)", "Syst.err (Fbin)"}) {
        const auto ilo = below.values.relative_values.find(col);
        const auto ihi = above.values.relative_values.find(col);
        if (ilo == below.values.relative_values.end() ||
            ihi == above.values.relative_values.end() ||
            !std::isfinite(ilo->second) || !std::isfinite(ihi->second)) {
            return false;
        }
        out.relative_values[col] = 0.5 * (ilo->second + ihi->second);
    }
    out.values[pass1_systematic_total_column()] =
        format_double(quadrature_total_from_components(out.values));
    return true;
}

static bool interpolate_from_kinematic_neighbors(
    const KinematicPoint& target,
    const std::vector<Pass1SourceRow>& sources,
    Pass1SystValues& out,
    int& below_bin,
    int& above_bin,
    double& below_distance,
    double& above_distance) {

    const Pass1SourceRow* below = nullptr;
    const Pass1SourceRow* above = nullptr;
    double best_below = std::numeric_limits<double>::infinity();
    double best_above = std::numeric_limits<double>::infinity();

    for (const auto& src : sources) {
        if (!finite_point(src.point)) continue;
        const double d2 = kinematic_distance2(target, src.point);
        if (point_less(src.point, target)) {
            if (d2 < best_below) {
                best_below = d2;
                below = &src;
            }
        } else if (point_less(target, src.point)) {
            if (d2 < best_above) {
                best_above = d2;
                above = &src;
            }
        }
    }

    if (!below || !above) {
        // Edge-of-phase-space fallback: there may be no lexicographically lower
        // or upper pass-1 bin. In that case use the two nearest kinematic
        // neighbors overall rather than leaving the pass-2 systematic blank.
        const Pass1SourceRow* first = nullptr;
        const Pass1SourceRow* second = nullptr;
        double d_first = std::numeric_limits<double>::infinity();
        double d_second = std::numeric_limits<double>::infinity();
        for (const auto& src : sources) {
            if (!finite_point(src.point)) continue;
            const double d2 = kinematic_distance2(target, src.point);
            if (d2 < d_first) {
                d_second = d_first;
                second = first;
                d_first = d2;
                first = &src;
            } else if (d2 < d_second) {
                d_second = d2;
                second = &src;
            }
        }
        if (!first || !second) return false;
        below = first;
        above = second;
        best_below = d_first;
        best_above = d_second;
    }

    if (!average_neighbor_values(*below, *above, out)) return false;

    below_bin = below->bin_index;
    above_bin = above->bin_index;
    below_distance = std::sqrt(best_below);
    above_distance = std::sqrt(best_above);
    return true;
}


static std::string make_boundary_key(double xb_min,
                                     double xb_max,
                                     double q2_min,
                                     double q2_max,
                                     double t_min,
                                     double t_max,
                                     double phi_min,
                                     double phi_max) {
    std::ostringstream key;
    key << std::fixed << std::setprecision(6)
        << xb_min << '|'
        << xb_max << '|'
        << q2_min << '|'
        << q2_max << '|'
        << t_min << '|'
        << t_max << '|'
        << phi_min << '|'
        << phi_max;
    return key.str();
}

static std::string make_boundary_key_from_pass1_row(const CsvTable& pass1,
                                                    const std::vector<std::string>& row) {
    return make_boundary_key(to_double(get_cell(row, pass1, "xBmin")),
                             to_double(get_cell(row, pass1, "xBmax")),
                             to_double(get_cell(row, pass1, "Q2min")),
                             to_double(get_cell(row, pass1, "Q2max")),
                             to_double(get_cell(row, pass1, "tmin")),
                             to_double(get_cell(row, pass1, "tmax")),
                             to_double(get_cell(row, pass1, "phimin")),
                             to_double(get_cell(row, pass1, "phimax")));
}

static std::string make_boundary_key_from_pass2_row(const CsvTable& pass2,
                                                    const std::vector<std::string>& row) {
    return make_boundary_key(to_double(get_cell(row, pass2, "xBmin")),
                             to_double(get_cell(row, pass2, "xBmax")),
                             to_double(get_cell(row, pass2, "Q2min")),
                             to_double(get_cell(row, pass2, "Q2max")),
                             to_double(get_cell(row, pass2, "t_abs_min")),
                             to_double(get_cell(row, pass2, "t_abs_max")),
                             to_double(get_cell(row, pass2, "phimin")),
                             to_double(get_cell(row, pass2, "phimax")));
}

static void validate_schema(const CsvTable& pass2,
                            const CsvTable& pass1) {
    column_or_throw(pass2, "bin index", "pass-2 systematic import");
    column_or_throw(pass2, "xBmin", "pass-2 systematic import");
    column_or_throw(pass2, "xBmax", "pass-2 systematic import");
    column_or_throw(pass2, "Q2min", "pass-2 systematic import");
    column_or_throw(pass2, "Q2max", "pass-2 systematic import");
    column_or_throw(pass2, "t_abs_min", "pass-2 systematic import");
    column_or_throw(pass2, "t_abs_max", "pass-2 systematic import");
    column_or_throw(pass2, "phimin", "pass-2 systematic import");
    column_or_throw(pass2, "phimax", "pass-2 systematic import");

    column_or_throw(pass1, "bin index", "pass-1 systematic import");
    column_or_throw(pass1, "xBmin", "pass-1 systematic import");
    column_or_throw(pass1, "xBmax", "pass-1 systematic import");
    column_or_throw(pass1, "Q2min", "pass-1 systematic import");
    column_or_throw(pass1, "Q2max", "pass-1 systematic import");
    column_or_throw(pass1, "tmin", "pass-1 systematic import");
    column_or_throw(pass1, "tmax", "pass-1 systematic import");
    column_or_throw(pass1, "phimin", "pass-1 systematic import");
    column_or_throw(pass1, "phimax", "pass-1 systematic import");
    column_or_throw(pass1, "val", "pass-1 cross section used to form fractional model systematics");

    for (const auto& col : pass1_systematic_component_columns()) {
        column_or_throw(pass1, col, "pass-1 systematic source");
    }
    for (const auto& col : all_point_to_point_component_columns()) {
        column_or_throw(pass2, col, "pass-2 systematic destination");
    }
    column_or_throw(pass2,
                    pass1_systematic_total_column(),
                    "pass-2 point-to-point total destination");

    column_or_throw(pass2,
                    ten6_normed_cross_section_column(),
                    "10.6-GeV radiative systematic scaling reference");

    column_or_throw(pass2,
                    sp19_normed_cross_section_column(),
                    "Sp19 radiative systematic scaling destination");
}

} // namespace

bool import_pass1_systematics(const std::string& csv_path,
                              const std::string& pass1_summary_path) {
    try {
        CsvTable pass2 = read_csv_or_throw(csv_path);
        const CsvTable pass1 = read_csv_or_throw(pass1_summary_path);

        validate_schema(pass2, pass1);

        const int sp19_frad_col =
            ensure_column(pass2, sp19_radiative_systematic_column());
        const int sp19_fbin_col =
            ensure_column(pass2, sp19_bin_centering_systematic_column());

        std::map<int, Pass1SystValues> by_bin_index;
        std::map<std::string, Pass1SystValues> by_boundary_key;
        std::vector<Pass1SourceRow> interpolation_sources;

        for (const auto& row : pass1.rows) {
            Pass1SystValues values;
            for (const auto& col : pass1_systematic_component_columns()) {
                values.values[col] = get_cell(row, pass1, col);
            }
            const double pass1_xs = to_double(get_cell(row, pass1, "val"));
            if (std::isfinite(pass1_xs) && std::fabs(pass1_xs) > 0.0) {
                for (const auto& col : std::vector<std::string>{"Syst.err (Frad)", "Syst.err (Fbin)"}) {
                    const double abs_unc = to_double(values.values[col]);
                    if (std::isfinite(abs_unc) && abs_unc >= 0.0) {
                        values.relative_values[col] = abs_unc / std::fabs(pass1_xs);
                    }
                }
            }
            values.values[pass1_systematic_total_column()] =
                format_double(quadrature_total_from_components(values.values));

            const int bin_index = to_int(get_cell(row, pass1, "bin index"));
            if (bin_index > 0) {
                by_bin_index[bin_index] = values;
            }

            const std::string key = make_boundary_key_from_pass1_row(pass1, row);
            if (!key.empty()) {
                by_boundary_key[key] = values;
            }

            Pass1SourceRow source;
            source.bin_index = bin_index;
            source.point = point_from_pass1_row(pass1, row);
            source.values = values;
            interpolation_sources.push_back(source);
        }

        int matched_by_index = 0;
        int matched_by_boundaries = 0;
        int interpolated = 0;
        int unmatched = 0;

        const std::string audit_path = csv_path + ".interpolated_pass1_systematics.csv";
        std::ofstream audit(audit_path);
        if (!audit.is_open()) {
            throw std::runtime_error("Could not open interpolation audit CSV: " + audit_path);
        }
        audit << "pass2_bin_index,xB_center,Q2_center,t_center,phi_center,"
              << "below_pass1_bin,above_pass1_bin,below_scaled_distance,above_scaled_distance,"
              << "pi0,acceptance,Frad,Fbin,total_after_full_recalculation\n";

        for (auto& row : pass2.rows) {
            const int bin_index = to_int(get_cell(row, pass2, "bin index"));

            const Pass1SystValues* values = nullptr;
            auto it_index = by_bin_index.find(bin_index);
            if (it_index != by_bin_index.end()) {
                values = &it_index->second;
                ++matched_by_index;
            } else {
                const std::string key = make_boundary_key_from_pass2_row(pass2, row);
                auto it_key = by_boundary_key.find(key);
                if (it_key != by_boundary_key.end()) {
                    values = &it_key->second;
                    ++matched_by_boundaries;
                }
            }

            Pass1SystValues interpolated_values;
            int below_bin = 0;
            int above_bin = 0;
            double below_distance = std::numeric_limits<double>::quiet_NaN();
            double above_distance = std::numeric_limits<double>::quiet_NaN();

            if (!values) {
                const KinematicPoint target = point_from_pass2_row(pass2, row);
                if (finite_point(target) &&
                    interpolate_from_kinematic_neighbors(target,
                                                         interpolation_sources,
                                                         interpolated_values,
                                                         below_bin,
                                                         above_bin,
                                                         below_distance,
                                                         above_distance)) {
                    values = &interpolated_values;
                    ++interpolated;
                    audit << bin_index << ','
                          << format_double(target.xb) << ','
                          << format_double(target.q2) << ','
                          << format_double(target.t) << ','
                          << format_double(target.phi) << ','
                          << below_bin << ',' << above_bin << ','
                          << format_double(below_distance) << ','
                          << format_double(above_distance);
                    for (const auto& col : pass1_systematic_destination_columns()) {
                        audit << ',' << values->values.at(col);
                    }
                    // The full total is written after the destination row has been updated.
                } else {
                    ++unmatched;
                    continue;
                }
            }

            // Background and acceptance components retain their inherited absolute
            // values here.  Frad and Fbin are model-dependent correction-factor
            // uncertainties, so preserve the fractional uncertainty established in
            // the model study and apply it to the present 10.6-GeV cross section.
            double xs10_for_model_systematics = std::numeric_limits<double>::quiet_NaN();
            {
                const int xs10_col = column_or_throw(pass2, ten6_normed_cross_section_column(),
                                                     "10.6-GeV cross section for model systematics");
                parse_tuple_first(row[(size_t)xs10_col], xs10_for_model_systematics);
            }
            for (const auto& col : pass1_systematic_destination_columns()) {
                const int j = column_or_throw(pass2, col, "pass-2 systematic destination");
                if ((col == "Syst.err (Frad)" || col == "Syst.err (Fbin)") &&
                    std::isfinite(xs10_for_model_systematics) && std::fabs(xs10_for_model_systematics) > 0.0) {
                    const auto ir = values->relative_values.find(col);
                    row[(size_t)j] = (ir != values->relative_values.end() && std::isfinite(ir->second))
                        ? format_double(ir->second * std::fabs(xs10_for_model_systematics))
                        : std::string();
                } else {
                    const auto it_value = values->values.find(col);
                    row[(size_t)j] = (it_value == values->values.end()) ? std::string() : it_value->second;
                }
            }

            // Sp19 Inb was taken at 10.2 GeV, while the inherited pass-1
            // radiative-systematic study is a 10.6-GeV result. The dominant
            // electron-radiation enhancement is governed by logarithms such
            // as ln(Q^2/m_e^2), so the modest beam-energy change is not
            // expected to produce a large new radiative uncertainty.
            //
            // Conservatively inflate the inherited fractional uncertainty:
            //
            //   [delta sigma / |sigma|]_rad^10.2
            //     = 1.05 [delta sigma / |sigma|]_rad^10.6 .
            //
            // Keep Syst.err (Frad) as the 10.6-GeV result and store the
            // 10.2-GeV Sp19 absolute uncertainty in its own CSV column.
            {
                const int frad_col =
                    column_or_throw(pass2,
                                    "Syst.err (Frad)",
                                    "10.6-GeV radiative systematic");

                const int xs10_col =
                    column_or_throw(pass2,
                                    ten6_normed_cross_section_column(),
                                    "10.6-GeV cross section for radiative systematic");

                const int xs19_col =
                    column_or_throw(pass2,
                                    sp19_normed_cross_section_column(),
                                    "Sp19 cross section for radiative systematic");

                const double frad_abs_10p6 =
                    to_double(row[(size_t)frad_col]);

                double xs10 = std::numeric_limits<double>::quiet_NaN();
                double xs19 = std::numeric_limits<double>::quiet_NaN();

                const bool ok10 =
                    parse_tuple_first(row[(size_t)xs10_col], xs10);
                const bool ok19 =
                    parse_tuple_first(row[(size_t)xs19_col], xs19);

                // The inherited Frad/Fbin studies define *fractional*
                // model uncertainties.  Therefore Sp19 can be assigned directly
                // from the matched pass-1 fractional values even in a kinematic
                // bin where the combined 10.6-GeV cross section is absent.
                //
                // This matters for one real pass-2 bin (bin index 2136): Sp19
                // has a valid cross section there while the 10.6-GeV combined
                // cross section is empty.  Requiring xs10 caused the dedicated
                // Sp19 point-to-point total to be blank in exactly that bin.
                const auto irad =
                    values->relative_values.find("Syst.err (Frad)");
                const auto ibin =
                    values->relative_values.find("Syst.err (Fbin)");

                const bool have_rad_frac =
                    irad != values->relative_values.end() &&
                    std::isfinite(irad->second) && irad->second >= 0.0;
                const bool have_bin_frac =
                    ibin != values->relative_values.end() &&
                    std::isfinite(ibin->second) && ibin->second >= 0.0;

                if (ok19 && std::fabs(xs19) > 0.0 && have_rad_frac) {
                    row[(size_t)sp19_frad_col] =
                        format_double(kSp19RadiativeSystematicScale *
                                      irad->second * std::fabs(xs19));
                } else if (std::isfinite(frad_abs_10p6) &&
                           frad_abs_10p6 >= 0.0 &&
                           ok10 && ok19 &&
                           std::fabs(xs10) > 0.0 &&
                           std::fabs(xs19) > 0.0) {
                    // Backward-safe fallback if a legacy source row somehow
                    // lacks the stored fractional value.
                    row[(size_t)sp19_frad_col] =
                        format_double(kSp19RadiativeSystematicScale *
                                      (frad_abs_10p6/std::fabs(xs10)) *
                                      std::fabs(xs19));
                } else {
                    row[(size_t)sp19_frad_col].clear();
                }

                if (ok19 && std::fabs(xs19) > 0.0 && have_bin_frac) {
                    row[(size_t)sp19_fbin_col] =
                        format_double(ibin->second * std::fabs(xs19));
                } else {
                    row[(size_t)sp19_fbin_col].clear();
                }
            }

            // The final point-to-point total is recomputed after the pass-2
            // pi0-subtraction systematic has been assigned.  Do not form a
            // transient total here with an empty pi0 component.
            if (&interpolated_values == values) {
                audit << ',' << "" << '\n';
            }
        }

        write_csv_or_throw(csv_path, pass2);

        std::cout << "[pass1-systematics] Imported fixed pass-1 systematic components from "
                  << pass1_summary_path << "\n";
        std::cout << "[pass1-systematics] Rows matched by bin index: " << matched_by_index
                  << ", by boundaries: " << matched_by_boundaries
                  << ", interpolated from nearest lower/upper kinematic neighbors: " << interpolated
                  << ", unmatched: " << unmatched << "\n";
        std::cout << "[pass1-systematics] Interpolation audit: " << audit_path << "\n";
        std::cout << "[pass1-systematics] Imported component columns:";
        for (const auto& col : pass1_systematic_destination_columns()) {
            std::cout << "\n  - " << col;
        }
        std::cout << "\n[pass1-systematics] Imported legacy pass-1 components that are not regenerated in pass 2.\n";
        std::cout << "[pass1-systematics] The pi0-subtraction component is filled subsequently from the pass-2 contamination by pi0_systematics.\n";
        std::cout << "[pass1-systematics] Sp19 radiative systematic: "
                  << sp19_radiative_systematic_column()
                  << " = " << kSp19RadiativeSystematicScale
                  << " x the inherited 10.6-GeV fractional Frad uncertainty.\n";
        std::cout << "[pass1-systematics] The original Syst.err (Frad) column remains the inherited 10.6-GeV value.\n";

        return true;
    } catch (const std::exception& e) {
        std::cerr << "[pass1-systematics] ERROR: " << e.what() << "\n";
        return false;
    }
}
