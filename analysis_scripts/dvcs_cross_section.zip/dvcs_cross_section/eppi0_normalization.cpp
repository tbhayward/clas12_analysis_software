#include "eppi0_normalization.h"

// -----------------------------------------------------------------------------
// ACCEPTED-AAOGEN-POPULATION EXPORT VERSION: 2026-09-16
// Exports the selected reconstructed AAOgen (xB,Q2,-t) population by period
// and photon topology for external pi0-model folding.
// -----------------------------------------------------------------------------


#include "global_cuts.h"

#include <TTree.h>
#include <TROOT.h>
#include <TSystem.h>
#include <TCanvas.h>
#include <TPad.h>
#include <TH1.h>
#include <TH1D.h>
#include <TGraphErrors.h>
#include <TF1.h>
#include <TLegend.h>
#include <TLatex.h>
#include <TStyle.h>
#include <TAxis.h>
#include <TFitResult.h>
#include <TFitResultPtr.h>
#include <TLine.h>
#include <TObject.h>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

static constexpr double PI = 3.14159265358979323846;
static constexpr double RAD2DEG = 180.0 / PI;
static constexpr double CHARGE_TO_MC_FACTOR = 1.0e-6;
static constexpr double RGA_LUMINOSITY_FACTOR_PB_INV_PER_MC = 1316.875;

static constexpr double RATIO_Y_MIN = 0.0;
static constexpr double RATIO_Y_MAX = 2.0;

static const std::vector<std::string> CSV_PERIOD_ORDER = {
    "Fa18 Inb",
    "Fa18 Out",
    "Sp19 Inb",
    "Sp18 Inb",
    "Sp18 Out"
};

static const std::vector<std::string> WORK_PERIOD_ORDER = {
    "Sp18 Inb",
    "Sp18 Out",
    "Fa18 Inb",
    "Fa18 Out",
    "Sp19 Inb"
};

static const std::vector<std::string> HELICITIES = {
    "unpol",
    "pos",
    "neg"
};

static inline bool has_helicity_resolved_data_columns(const std::string& period) {
    if (period == "Sp18 Inb") {
        return false;
    }

    if (period == "Sp18 Out") {
        return false;
    }

    return true;
}

struct ChannelConfig {
    std::string csv_channel;
    std::string cut_prefix;
    std::string title;
};

static ChannelConfig dvcs_config() {
    ChannelConfig cfg;
    cfg.csv_channel = "ep->epg";
    cfg.cut_prefix = "DVCS";
    cfg.title = "ep #rightarrow ep#gamma";
    return cfg;
}

static ChannelConfig eppi0_config() {
    ChannelConfig cfg;
    cfg.csv_channel = "ep->eppi0";
    cfg.cut_prefix = "eppi0";
    cfg.title = "ep #rightarrow ep#pi_{0}";
    return cfg;
}

struct PeriodTags {
    std::string display;
    std::string period_label;
    std::string period_code;
};

struct CubicFit {
    double a[4] = {1.0, 0.0, 0.0, 0.0};
    double ea[4] = {0.0, 0.0, 0.0, 0.0};
    double x_min = 0.0;
    double x_max = 0.0;
    bool valid = false;
    bool log_space = false;

    double eval(double x) const {
        const double poly = a[0] + x * (a[1] + x * (a[2] + x * a[3]));
        return log_space ? std::exp(poly) : poly;
    }
};

struct QuarticFit {
    double a[5] = {1.0, 0.0, 0.0, 0.0, 0.0};

    double eval(double x) const {
        return a[0] + x * (a[1] + x * (a[2] + x * (a[3] + x * a[4])));
    }
};

struct RegionNormalization {
    std::string region;
    CubicFit fit;
    CubicFit legacy_raw_cubic;
    CubicFit momentum_fit; // residual DATA/(MC*theta_weight), fitted versus p1_p
    double integrated_ratio = 1.0;
    double integrated_ratio_err = 0.0;
};

struct SummaryRatioCurve {
    std::string key;
    std::string title;
    std::string x_title;
    std::vector<double> x;
    std::vector<double> y;
    std::vector<double> ey;
};

struct PhotonTopologyNormalization {
    std::string topology;
    double integrated_ratio = 1.0;
    double integrated_ratio_err = 0.0;
    long long data_events = 0;
    long long mc_events = 0;
    std::map<std::string, SummaryRatioCurve> ratio_curves;
};

struct ControlledTopologyResult {
    std::string topology;
    double controlled_ratio = 0.0;
    double controlled_ratio_err = 0.0;
    double data_support_fraction = 0.0;
    double mc_support_fraction = 0.0;
};

struct ControlledTopologyComparison {
    int min_raw_events_per_sample = 0;
    int common_cells = 0;
    double closure = 0.0;
    std::map<std::string, ControlledTopologyResult> topologies;
};

struct PeriodNormalization {
    std::string period;
    double integrated_ratio = 1.0;
    double integrated_ratio_err = 0.0;
    std::map<std::string, RegionNormalization> regions;
    std::map<std::string, SummaryRatioCurve> summary_ratio_curves;
    std::map<std::string, PhotonTopologyNormalization> photon_topologies;
    ControlledTopologyComparison controlled_nominal;
    ControlledTopologyComparison controlled_strict;
};

static void fatal(const std::string& msg);

struct AaoPeriodInput {
    double sigma_min_microbarn = 0.0;
    double sigma_max_microbarn = 0.0;
    double sigma_mid_microbarn = 0.0;
    double sigma_half_width_microbarn = 0.0;
    double sigma_relative_uncertainty_from_range = 0.0;
    double generated_events = 0.0;
};

static AaoPeriodInput read_aao_period_input(const std::string& json_path, const std::string& period) {
    std::ifstream in(json_path.c_str());

    if (!in.is_open()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: could not open AAOGEN normalization input JSON: " << json_path;
        fatal(ss.str());
    }

    nlohmann::json j;
    in >> j;

    if (!j.contains("periods") || !j["periods"].is_object()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: AAOGEN normalization input JSON is missing object 'periods': " << json_path;
        fatal(ss.str());
    }

    const nlohmann::json& periods = j["periods"];

    if (!periods.contains(period)) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: AAOGEN normalization input JSON is missing period '" << period << "': " << json_path;
        fatal(ss.str());
    }

    const nlohmann::json& jp = periods[period];

    const std::vector<std::string> required = {
        "sigma_min_microbarn",
        "sigma_max_microbarn",
        "sigma_mid_microbarn",
        "sigma_half_width_microbarn",
        "sigma_relative_uncertainty_from_range",
        "generated_events"
    };

    std::vector<std::string> missing;

    for (const std::string& key : required) {
        if (!jp.contains(key)) {
            missing.push_back(key);
        }
    }

    if (!missing.empty()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: AAOGEN normalization input JSON period '" << period << "' is missing keys:";
        for (const std::string& key : missing) {
            ss << " " << key;
        }
        fatal(ss.str());
    }

    AaoPeriodInput out;
    out.sigma_min_microbarn = jp.at("sigma_min_microbarn").get<double>();
    out.sigma_max_microbarn = jp.at("sigma_max_microbarn").get<double>();
    out.sigma_mid_microbarn = jp.at("sigma_mid_microbarn").get<double>();
    out.sigma_half_width_microbarn = jp.at("sigma_half_width_microbarn").get<double>();
    out.sigma_relative_uncertainty_from_range = jp.at("sigma_relative_uncertainty_from_range").get<double>();
    out.generated_events = jp.at("generated_events").get<double>();

    if (!(out.sigma_mid_microbarn > 0.0)) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: AAOGEN normalization input JSON period '" << period << "' has non-positive sigma_mid_microbarn.";
        fatal(ss.str());
    }

    if (!(out.generated_events > 0.0)) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: AAOGEN normalization input JSON period '" << period << "' has non-positive generated_events.";
        fatal(ss.str());
    }

    return out;
}

static void fatal(const std::string& msg) {
    throw std::runtime_error(msg);
}

static std::string lower_ascii(std::string s) {
    for (char& c : s) {
        c = (char)std::tolower((unsigned char)c);
    }

    return s;
}

static bool has_substr(const std::string& s, const std::string& sub) {
    return s.find(sub) != std::string::npos;
}

static PeriodTags parse_period_from_key(const std::string& key) {
    const std::string s = lower_ascii(key);
    PeriodTags t;

    if (has_substr(s, "fa18") && has_substr(s, "inb") && has_substr(s, "supp")) {
        t.display = "Fa18 Inb Supp";
        t.period_label = "fa18_inb";
        t.period_code = "Fa18_Inb_Supp";
        return t;
    }

    if (has_substr(s, "fa18") && has_substr(s, "inb")) {
        t.display = "Fa18 Inb";
        t.period_label = "fa18_inb";
        t.period_code = "Fa18_Inb";
        return t;
    }

    if (has_substr(s, "fa18") && has_substr(s, "out")) {
        t.display = "Fa18 Out";
        t.period_label = "fa18_out";
        t.period_code = "Fa18_Out";
        return t;
    }

    if (has_substr(s, "sp19") && has_substr(s, "inb")) {
        t.display = "Sp19 Inb";
        t.period_label = "sp19_inb";
        t.period_code = "Sp19_Inb";
        return t;
    }

    if (has_substr(s, "sp18") && has_substr(s, "inb")) {
        t.display = "Sp18 Inb";
        t.period_label = "sp18_inb";
        t.period_code = "Sp18_Inb";
        return t;
    }

    if (has_substr(s, "sp18") && has_substr(s, "out")) {
        t.display = "Sp18 Out";
        t.period_label = "sp18_out";
        t.period_code = "Sp18_Out";
        return t;
    }

    std::ostringstream ss;
    ss << "[eppi0_norm] FATAL: cannot parse period from tree key: " << key;
    fatal(ss.str());

    return t;
}

static std::string period_dir(const std::string& period) {
    if (period == "Fa18 Inb") return "Fa18_Inb";
    if (period == "Fa18 Out") return "Fa18_Out";
    if (period == "Sp19 Inb") return "Sp19_Inb";
    if (period == "Sp18 Inb") return "Sp18_Inb";
    if (period == "Sp18 Out") return "Sp18_Out";
    if (period == "Fa18 Inb Supp") return "Fa18_Inb_Supp";

    std::ostringstream ss;
    ss << "[eppi0_norm] FATAL: unknown period label: " << period;
    fatal(ss.str());

    return "";
}

static void mkdir_p(const std::string& path) {
    if (!path.empty()) {
        gSystem->mkdir(path.c_str(), true);
    }
}

static double wrap_phi_deg(double v) {
    double p = std::fmod(v, 360.0);

    if (p < 0.0) {
        p += 360.0;
    }

    if (p >= 360.0) {
        p = std::nextafter(360.0, 0.0);
    }

    return p;
}


static inline double delta_phi_rad_from_two_phi(double phi_a, double phi_b) {
    double d = std::fmod(phi_a - phi_b, 2.0 * PI);

    if (d <= -PI) {
        d += 2.0 * PI;
    }

    if (d > PI) {
        d -= 2.0 * PI;
    }

    return std::fabs(d);
}

static bool in_range(double v, double a, double b) {
    return v >= a && v < b;
}

static bool row_accepts_phi(double phi, double pmin, double pmax) {
    if (pmax > pmin) {
        return in_range(phi, pmin, pmax);
    }

    return phi >= pmin || phi < pmax;
}

static std::string topo_dir(int det1, int det2) {
    if (det1 == 1 && det2 == 1) return "FD_FD";
    if (det1 == 2 && det2 == 1) return "CD_FD";
    if (det1 == 2 && det2 == 0) return "CD_FT";

    return "";
}

static std::string topo_label_for_csv(const std::string& topo) {
    if (topo == "FD_FD") return "(FD, FD)";
    if (topo == "CD_FD") return "(CD, FD)";
    if (topo == "CD_FT") return "(CD, FT)";

    return "";
}

// -----------------------------------------------------------------------------
// CSV helpers
// -----------------------------------------------------------------------------

struct CSV {
    std::vector<std::string> header;
    std::unordered_map<std::string, int> index;
    std::vector<std::vector<std::string>> rows;
};

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    bool inq = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];

        if (c == '"') {
            if (inq && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                inq = !inq;
            }
        } else if (c == ',' && !inq) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }

    out.push_back(cur);

    return out;
}

static std::string join_csv_row(const std::vector<std::string>& fields) {
    std::ostringstream oss;

    for (size_t i = 0; i < fields.size(); ++i) {
        const std::string& s = fields[i];

        const bool quote = s.find(',') != std::string::npos ||
                           s.find('"') != std::string::npos ||
                           s.find('\n') != std::string::npos ||
                           s.find('\r') != std::string::npos;

        if (quote) {
            oss << '"';

            for (char ch : s) {
                if (ch == '"') {
                    oss << "\"\"";
                } else {
                    oss << ch;
                }
            }

            oss << '"';
        } else {
            oss << s;
        }

        if (i + 1 < fields.size()) {
            oss << ',';
        }
    }

    return oss.str();
}

static void load_csv_strict(const std::string& path, CSV& csv) {
    std::ifstream fin(path);

    if (!fin.is_open()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: cannot open CSV: " << path;
        fatal(ss.str());
    }

    std::string line;

    if (!std::getline(fin, line)) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: empty CSV: " << path;
        fatal(ss.str());
    }

    csv.header = split_csv_line(line);
    csv.index.clear();

    for (int i = 0; i < (int)csv.header.size(); ++i) {
        if (csv.index.find(csv.header[i]) != csv.index.end()) {
            std::ostringstream ss;
            ss << "[eppi0_norm] FATAL: duplicate CSV column: " << csv.header[i];
            fatal(ss.str());
        }

        csv.index[csv.header[i]] = i;
    }

    csv.rows.clear();

    while (std::getline(fin, line)) {
        if (line.empty()) {
            continue;
        }

        std::vector<std::string> row = split_csv_line(line);

        if (row.size() < csv.header.size()) {
            row.resize(csv.header.size(), "");
        }

        if (row.size() != csv.header.size()) {
            fatal("[eppi0_norm] FATAL: CSV row width mismatch while loading.");
        }

        csv.rows.push_back(std::move(row));
    }
}

static void write_csv_atomic(const std::string& path, const CSV& csv) {
    const std::string tmp = path + ".tmp";

    std::ofstream fout(tmp);

    if (!fout.is_open()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: cannot write temp CSV: " << tmp;
        fatal(ss.str());
    }

    fout << join_csv_row(csv.header) << "\n";

    for (const auto& row : csv.rows) {
        fout << join_csv_row(row) << "\n";
    }

    fout.close();

    if (!fout) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: failed writing temp CSV: " << tmp;
        fatal(ss.str());
    }

    (void)std::remove(path.c_str());

    if (std::rename(tmp.c_str(), path.c_str()) != 0) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: failed replacing CSV: " << path;
        fatal(ss.str());
    }
}

static int col_strict(const CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);

    if (it == csv.index.end()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: missing CSV column: " << name;
        fatal(ss.str());
    }

    return it->second;
}

static double to_double_strict(const std::string& s, const std::string& what) {
    if (s.empty()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: empty numeric cell for " << what;
        fatal(ss.str());
    }

    char* e = nullptr;
    const double v = std::strtod(s.c_str(), &e);

    if (e == s.c_str()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: parse failure for " << what << " value " << s;
        fatal(ss.str());
    }

    return v;
}

static bool valid_cell(const std::string& s) {
    return s == "1" || s == "1.0" || s == "true" || s == "TRUE";
}

static std::string tuple2(double a, double b) {
    std::ostringstream ss;
    ss << std::setprecision(12) << "(" << a << "," << b << ")";
    return ss.str();
}

static std::string tuple4(const CubicFit& p) {
    std::ostringstream ss;
    ss << std::setprecision(12)
       << "(" << p.a[0] << "," << p.a[1] << "," << p.a[2] << "," << p.a[3] << ")";
    return ss.str();
}

static bool parse_tuple_numbers(const std::string& s, std::vector<double>& vals) {
    vals.clear();

    std::string t = s;

    for (char& c : t) {
        if (c == '(' || c == ')' || c == '"') {
            c = ' ';
        }
    }

    std::stringstream ss(t);
    std::string part;

    while (std::getline(ss, part, ',')) {
        char* e = nullptr;
        const double v = std::strtod(part.c_str(), &e);

        if (e == part.c_str()) {
            return false;
        }

        vals.push_back(v);
    }

    return !vals.empty();
}

static void read_current_factor(const CSV& csv,
                                const ChannelConfig& cfg,
                                const std::string& sample,
                                const std::string& period,
                                double& factor,
                                double& factor_stat) {
    const std::string name = "current efficiency factor, " + cfg.csv_channel + ", " + sample + ", " + period;
    const int c = col_strict(csv, name);

    if (csv.rows.empty()) {
        fatal("[eppi0_norm] FATAL: CSV has no rows.");
    }

    std::vector<double> vals;

    if (!parse_tuple_numbers(csv.rows.front()[c], vals) || vals.size() < 2) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: cannot parse current-efficiency tuple from column " << name
           << " value '" << csv.rows.front()[c] << "'.";
        fatal(ss.str());
    }

    if (!(std::isfinite(vals[0]) && vals[0] > 0.0) ||
        !(std::isfinite(vals[1]) && vals[1] >= 0.0)) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: invalid current-efficiency factor tuple in column " << name
           << ": " << csv.rows.front()[c];
        fatal(ss.str());
    }

    factor = vals[0];
    factor_stat = vals[1];
}

static double read_current_factor_value(const CSV& csv,
                                        const ChannelConfig& cfg,
                                        const std::string& sample,
                                        const std::string& period) {
    double factor = 0.0;
    double factor_stat = 0.0;
    read_current_factor(csv, cfg, sample, period, factor, factor_stat);
    (void)factor_stat;
    return factor;
}

static double cubic_eval_stat_diag(const CubicFit& f, double x) {
    const double basis[4] = {1.0, x, x * x, x * x * x};
    double var = 0.0;

    for (int i = 0; i < 4; ++i) {
        var += basis[i] * basis[i] * f.ea[i] * f.ea[i];
    }

    if (!(var > 0.0)) return 0.0;
    const double sigma_poly = std::sqrt(var);
    return f.log_space ? f.eval(x) * sigma_poly : sigma_poly;
}

static std::string tuple3(double a, double b, double c) {
    std::ostringstream ss;
    ss << std::setprecision(12) << "(" << a << "," << b << "," << c << ")";
    return ss.str();
}

static std::vector<std::string> normalization_regions() {
    return {"Sector 1", "Sector 2", "Sector 3", "Sector 4", "Sector 5", "Sector 6", "CD"};
}

static std::string norm_fit_col(const std::string& period, const std::string& region) {
    return "eppi0 cross-section normalization cubic, ep->eppi0, data_over_mc, " + region + ", " + period;
}

static std::string norm_factor_col(const std::string& period, const std::string& region) {
    return "eppi0 cross-section normalization factor, ep->eppi0, data_over_mc, " + region + ", " + period;
}

static std::string normalized_raw_yield_col(const ChannelConfig& cfg,
                                            const std::string& topo_label,
                                            const std::string& period,
                                            const std::string& hel) {
    return "normalized raw yield, " + cfg.csv_channel + ", " + topo_label + ", exp, " + period + ", " + hel;
}

// -----------------------------------------------------------------------------
// Row bins
// -----------------------------------------------------------------------------

struct RowBin {
    double xBmin = 0.0;
    double xBmax = 0.0;
    double Q2min = 0.0;
    double Q2max = 0.0;
    double tmin = 0.0;
    double tmax = 0.0;
    double pmin = 0.0;
    double pmax = 0.0;
    bool valid = false;
};

static std::vector<RowBin> load_rows(const CSV& csv) {
    const int c_xmin = col_strict(csv, "xBmin");
    const int c_xmax = col_strict(csv, "xBmax");
    const int c_qmin = col_strict(csv, "Q2min");
    const int c_qmax = col_strict(csv, "Q2max");
    const int c_tmin = col_strict(csv, "t_abs_min");
    const int c_tmax = col_strict(csv, "t_abs_max");
    const int c_pmin = col_strict(csv, "phimin");
    const int c_pmax = col_strict(csv, "phimax");
    const int c_valid = col_strict(csv, "valid bin");

    std::vector<RowBin> rows;
    rows.reserve(csv.rows.size());

    for (int i = 0; i < (int)csv.rows.size(); ++i) {
        const auto& r = csv.rows[i];

        RowBin b;
        b.xBmin = to_double_strict(r[c_xmin], "xBmin");
        b.xBmax = to_double_strict(r[c_xmax], "xBmax");
        b.Q2min = to_double_strict(r[c_qmin], "Q2min");
        b.Q2max = to_double_strict(r[c_qmax], "Q2max");
        b.tmin = to_double_strict(r[c_tmin], "t_abs_min");
        b.tmax = to_double_strict(r[c_tmax], "t_abs_max");
        b.pmin = to_double_strict(r[c_pmin], "phimin");
        b.pmax = to_double_strict(r[c_pmax], "phimax");
        b.valid = valid_cell(r[c_valid]);

        rows.push_back(b);
    }

    return rows;
}

static bool row_accepts(const RowBin& r, double x, double Q2, double tabs, double phi) {
    if (!r.valid) return false;
    if (!in_range(x, r.xBmin, r.xBmax)) return false;
    if (!in_range(Q2, r.Q2min, r.Q2max)) return false;
    if (!in_range(tabs, r.tmin, r.tmax)) return false;
    if (!row_accepts_phi(phi, r.pmin, r.pmax)) return false;

    return true;
}

// -----------------------------------------------------------------------------
// Charge and sigma cuts
// -----------------------------------------------------------------------------

static std::unordered_map<int, double> read_charge_csv(const std::string& path) {
    std::ifstream fin(path);

    if (!fin.is_open()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: cannot open charge CSV: " << path;
        fatal(ss.str());
    }

    std::unordered_map<int, double> out;
    std::string line;

    while (std::getline(fin, line)) {
        if (line.empty() || line[0] == '#') {
            continue;
        }

        std::vector<std::string> f = split_csv_line(line);

        if (f.size() < 2) {
            continue;
        }

        char* e = nullptr;
        int run = (int)std::strtol(f[0].c_str(), &e, 10);

        if (e == f[0].c_str()) {
            continue;
        }

        e = nullptr;
        double q = std::strtod(f[1].c_str(), &e);

        if (e == f[1].c_str()) {
            continue;
        }

        out[run] = q;
    }

    return out;
}

struct SigmaStats {
    double mean = std::numeric_limits<double>::quiet_NaN();
    double std = std::numeric_limits<double>::quiet_NaN();
    double cut_low = std::numeric_limits<double>::quiet_NaN();
    double cut_high = std::numeric_limits<double>::quiet_NaN();
    double quantile = 0.0;
    std::string mode = "symmetric_3sigma";
};

using CutVarMap = std::unordered_map<std::string, SigmaStats>;
using TopoCutMap = std::unordered_map<std::string, CutVarMap>;

static TopoCutMap load_sigma_cuts(const std::string& path, const std::string& sample_key) {
    std::ifstream fin(path);

    if (!fin.is_open()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: cannot open combined cuts JSON: " << path;
        fatal(ss.str());
    }

    nlohmann::json j;
    try { fin >> j; }
    catch (const std::exception& ex) {
        fatal("[eppi0_norm] FATAL: failed to parse combined cuts JSON " + path + ": " + ex.what());
    }
    if (!j.is_object()) fatal("[eppi0_norm] FATAL: combined cuts JSON is not an object: " + path);

    TopoCutMap out;

    for (auto it = j.begin(); it != j.end(); ++it) {
        const std::string key = it.key();
        const auto& block = it.value();

        if (!block.is_object() || !block.contains(sample_key)) {
            continue;
        }

        const auto& sample = block[sample_key];

        if (!sample.is_object()) {
            continue;
        }

        CutVarMap vm;

        for (auto vit = sample.begin(); vit != sample.end(); ++vit) {
            const auto& obj = vit.value();

            if (!obj.is_object() || !obj.contains("mean") || !obj.contains("std")) {
                continue;
            }

            SigmaStats s;
            s.mean = obj["mean"].get<double>();
            s.std = obj["std"].get<double>();
            if (obj.contains("cut_low")) s.cut_low = obj["cut_low"].get<double>();
            if (obj.contains("cut_high")) s.cut_high = obj["cut_high"].get<double>();
            if (obj.contains("quantile")) s.quantile = obj["quantile"].get<double>();
            if (obj.contains("mode")) s.mode = obj["mode"].get<std::string>();
            if (!std::isfinite(s.cut_low) || !std::isfinite(s.cut_high) || s.cut_high <= s.cut_low) {
                if (std::isfinite(s.mean) && std::isfinite(s.std) && s.std > 0.0) {
                    s.cut_low = s.mean - 3.0 * s.std;
                    s.cut_high = s.mean + 3.0 * s.std;
                }
            }
            vm[vit.key()] = s;
        }

        if (!vm.empty()) {
            static const std::set<std::string> supported_variables = {
                "Delta_phi",
                "theta",
                "theta_gamma_gamma",
                "pTmiss",
                "Emiss2",
                "Mx2",
                "Mx2_2"
            };
            for (const auto& kv : vm) {
                if (supported_variables.find(kv.first) == supported_variables.end())
                    fatal("[eppi0_norm] FATAL: cut key '" + key + "' contains unsupported production exclusivity variable '" + kv.first + "'.");
            }
            if (vm.find("Mx2") == vm.end())
                fatal("[eppi0_norm] FATAL: cut key '" + key + "' is missing the mandatory forced-first Mx2 cut.");
            out.emplace(key, std::move(vm));
        }
    }

    return out;
}

static bool within_cut_window(double v, const SigmaStats& s) {
    if (!std::isfinite(v)) return false;
    if (s.mode == "upper_quantile") {
        if (!std::isfinite(s.cut_high)) return true;
        return v <= s.cut_high;
    }
    double lo = s.cut_low;
    double hi = s.cut_high;
    if (!(std::isfinite(lo) && std::isfinite(hi)) || hi <= lo) {
        if (!std::isfinite(s.mean) || !std::isfinite(s.std) || s.std <= 0.0) return true;
        lo = s.mean - 3.0 * s.std;
        hi = s.mean + 3.0 * s.std;
    }
    return (v >= lo && v <= hi);
}

static bool check_sigma(const CutVarMap& vm, const std::string& var, bool has, double val) {
    auto it = vm.find(var);

    if (it == vm.end()) {
        return true;
    }

    if (!has) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: sigma cut requires missing branch " << var;
        fatal(ss.str());
    }

    return within_cut_window(val, it->second);
}

// -----------------------------------------------------------------------------
// Branch binding and cuts
// -----------------------------------------------------------------------------

static std::mutex g_bind_mutex;

struct Branches {
    int runnum = 0; bool has_runnum = false;
    int detector1 = 0; bool has_detector1 = false;
    int detector2 = 0; bool has_detector2 = false;
    int detector_gamma1 = -1; bool has_detector_gamma1 = false;
    int detector_gamma2 = -1; bool has_detector_gamma2 = false;
    int helicity = 0; bool has_helicity = false;

    double x = 0.0; bool has_x = false;
    double Q2 = 0.0; bool has_Q2 = false;
    double t1 = 0.0; bool has_t1 = false;
    double phi2 = 0.0; bool has_phi2 = false;

    double p1_p = 0.0; bool has_p1_p = false;
    double p1_theta = 0.0; bool has_p1_theta = false;
    double p1_phi = 0.0; bool has_p1_phi = false;
    double p2_p = 0.0; bool has_p2_p = false;
    double p2_theta = 0.0; bool has_p2_theta = false;
    double p2_phi = 0.0; bool has_p2_phi = false;

    double weight = 1.0; bool has_weight = false;

    double open_angle_ep2 = 0.0; bool has_open_angle_ep2 = false;
    double pTmiss = 0.0; bool has_pTmiss = false;
    double theta = 0.0; bool has_theta = false;
    double Emiss2 = 0.0; bool has_Emiss2 = false;
    double Mx2 = 0.0; bool has_Mx2 = false;
    double Mx2_2 = 0.0; bool has_Mx2_2 = false;
    double theta_gamma_gamma = 0.0; bool has_theta_gamma_gamma = false;
    double theta_pi0_pi0 = 0.0; bool has_theta_pi0_pi0 = false;
    double Delta_phi = 0.0; bool has_Delta_phi = false;

    double e_p = 0.0; bool has_e_p = false;
    double e_theta = 0.0; bool has_e_theta = false;
    double e_phi = 0.0; bool has_e_phi = false;

    void bind(TTree* t, bool need_weight) {
        std::lock_guard<std::mutex> lock(g_bind_mutex);

        t->SetBranchStatus("*", 0);

        auto ena = [&](const char* name) {
            if (t->GetBranch(name)) {
                t->SetBranchStatus(name, 1);
            }
        };

        ena("runnum");
        ena("detector1");
        ena("detector2");
        ena("detector_gamma1");
        ena("detector_gamma2");
        ena("helicity");

        ena("x");
        ena("Q2");
        ena("t1");
        ena("phi2");

        ena("p1_p");
        ena("p1_theta");
        ena("p1_phi");
        ena("p2_p");
        ena("p2_theta");
        ena("p2_phi");

        ena("open_angle_ep2");
        ena("pTmiss");
        ena("Emiss2");
        ena("Mx2");
        ena("Mx2_2");
        ena("theta");
        ena("theta_gamma_gamma");
        ena("theta_pi0_pi0");
        ena("Delta_phi");

        ena("e_p");
        ena("e_theta");
        ena("e_phi");

        if (need_weight) {
            ena("weight");
        }

        t->SetCacheSize(16 * 1024 * 1024);

        auto bI = [&](const char* name, int* addr, bool& flag) {
            if (t->GetBranch(name)) {
                t->SetBranchAddress(name, addr);
                flag = true;
            }
        };

        auto bD = [&](const char* name, double* addr, bool& flag) {
            if (t->GetBranch(name)) {
                t->SetBranchAddress(name, addr);
                flag = true;
            }
        };

        bI("runnum", &runnum, has_runnum);
        bI("detector1", &detector1, has_detector1);
        bI("detector2", &detector2, has_detector2);
        bI("detector_gamma1", &detector_gamma1, has_detector_gamma1);
        bI("detector_gamma2", &detector_gamma2, has_detector_gamma2);
        bI("helicity", &helicity, has_helicity);

        bD("x", &x, has_x);
        bD("Q2", &Q2, has_Q2);
        bD("t1", &t1, has_t1);
        bD("phi2", &phi2, has_phi2);

        bD("p1_p", &p1_p, has_p1_p);
        bD("p1_theta", &p1_theta, has_p1_theta);
        bD("p1_phi", &p1_phi, has_p1_phi);
        bD("p2_p", &p2_p, has_p2_p);
        bD("p2_theta", &p2_theta, has_p2_theta);
        bD("p2_phi", &p2_phi, has_p2_phi);

        bD("weight", &weight, has_weight);

        bD("open_angle_ep2", &open_angle_ep2, has_open_angle_ep2);
        bD("pTmiss", &pTmiss, has_pTmiss);
        bD("Emiss2", &Emiss2, has_Emiss2);
        bD("Mx2", &Mx2, has_Mx2);
        bD("Mx2_2", &Mx2_2, has_Mx2_2);
        bD("theta", &theta, has_theta);
        bD("theta_gamma_gamma", &theta_gamma_gamma, has_theta_gamma_gamma);
        bD("theta_pi0_pi0", &theta_pi0_pi0, has_theta_pi0_pi0);
        bD("Delta_phi", &Delta_phi, has_Delta_phi);

        bD("e_p", &e_p, has_e_p);
        bD("e_theta", &e_theta, has_e_theta);
        bD("e_phi", &e_phi, has_e_phi);
    }

    double phi_deg() const {
        return wrap_phi_deg(phi2 * RAD2DEG);
    }

    double t_abs() const {
        return std::fabs(t1);
    }

    double p1_theta_deg() const {
        return p1_theta * RAD2DEG;
    }

    double p1_phi_deg() const {
        return wrap_phi_deg(p1_phi * RAD2DEG);
    }

    double p2_theta_deg() const {
        return p2_theta * RAD2DEG;
    }

    double p2_phi_deg() const {
        return wrap_phi_deg(p2_phi * RAD2DEG);
    }

    double delta_phi_value(bool& has_val) const {
        if (has_Delta_phi) {
            has_val = true;
            return Delta_phi;
        }

        if (has_p1_phi && has_p2_phi) {
            has_val = true;
            return delta_phi_rad_from_two_phi(p1_phi, p2_phi);
        }

        has_val = false;
        return 0.0;
    }
};

static bool passes_global_dispatch(const Branches& b,
                                   const PeriodTags& tags) {
    const GlobalCutConfig& cfg = default_global_cuts();

    if (!(b.has_t1 && b.has_open_angle_ep2)) return false;
    if (cfg.enable_pTmiss_cut && !b.has_pTmiss) return false;
    if (b.has_runnum && is_excluded_run(b.runnum)) return false;

    if (!(b.has_detector1 && b.has_detector2)) {
        fatal("[eppi0_norm] FATAL: missing detector1/detector2.");
    }

    if (global_cuts_require_sector_phi(cfg)) {
        if (!(b.has_e_phi && b.has_p1_phi && b.has_p2_phi)) {
            fatal("[eppi0_norm] FATAL: sector selection requires e_phi, p1_phi, p2_phi.");
        }
    }

    if (global_cuts_require_auxiliary_kinematics(cfg)) {
        if (!(b.has_e_theta && b.has_e_phi &&
              b.has_p1_theta && b.has_p1_phi &&
              b.has_p2_p && b.has_p2_theta && b.has_p2_phi)) {
            fatal("[eppi0_norm] FATAL: auxiliary fiducial cuts require e_theta, e_phi, p1_theta, p1_phi, p2_p, p2_theta, p2_phi branches.");
        }

        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  tags.period_label,
                                  b.e_p, b.e_theta, b.e_phi,
                                  b.p1_theta, b.p1_phi,
                                  b.p2_p, b.p2_theta, b.p2_phi,
                                  cfg);
    }

    if (cfg.enable_dvcsgen_ycol_cut) {
        if (!(b.has_e_p && b.has_e_theta && b.has_e_phi &&
              b.has_p2_p && b.has_p2_theta && b.has_p2_phi)) {
            fatal("[eppi0_norm] FATAL: missing branches required by global ycol cuts.");
        }

        if (global_cuts_require_sector_phi(cfg)) {
            return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                      b.detector1, b.detector2,
                                      tags.period_label,
                                      b.e_p, b.e_theta, b.e_phi, b.p1_theta, b.p1_phi,
                                      b.p2_p, b.p2_theta, b.p2_phi,
                                      cfg);
        }

        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  tags.period_label,
                                  b.e_p, b.e_theta, b.e_phi,
                                  b.p2_p, b.p2_theta, b.p2_phi,
                                  cfg);
    }

    if (global_cuts_require_sector_phi(cfg)) {
        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  tags.period_label,
                                  b.e_phi, b.p1_phi, b.p2_phi,
                                  cfg);
    }

    return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                              b.detector1, b.detector2,
                              cfg);
}

static bool passes_sigma_dispatch(const ChannelConfig& cfg,
                                  const PeriodTags& tags,
                                  const TopoCutMap& cuts,
                                  const Branches& b) {
    if (!(b.has_detector1 && b.has_detector2)) return false;
    const std::string topo=topo_dir(b.detector1,b.detector2);
    if (topo.empty()) return false;
    const std::string key=cfg.cut_prefix+"_"+tags.period_code+"_"+topo;
    auto it=cuts.find(key);
    if (it==cuts.end()) fatal("[eppi0_norm] FATAL: missing production exclusivity cut key: "+key);
    const CutVarMap& vm=it->second;
    bool has_delta_phi=false;
    const double delta_phi=b.delta_phi_value(has_delta_phi);
    if (!check_sigma(vm,"Delta_phi",has_delta_phi,delta_phi)) return false;
    if (!check_sigma(vm,"theta",b.has_theta,b.theta)) return false;
    if (cfg.csv_channel=="ep->eppi0") {
        if (!check_sigma(vm,"theta_gamma_gamma",b.has_theta_pi0_pi0,b.theta_pi0_pi0)) return false;
    } else {
        if (!check_sigma(vm,"theta_gamma_gamma",b.has_theta_gamma_gamma,b.theta_gamma_gamma)) return false;
    }
    if (!check_sigma(vm,"pTmiss",b.has_pTmiss,b.pTmiss)) return false;
    if (!check_sigma(vm,"Emiss2",b.has_Emiss2,b.Emiss2)) return false;
    if (!check_sigma(vm,"Mx2",b.has_Mx2,b.Mx2)) return false;
    if (!check_sigma(vm,"Mx2_2",b.has_Mx2_2,b.Mx2_2)) return false;
    return true;
}

static bool passes_event_selection(const ChannelConfig& cfg,
                                   const PeriodTags& tags,
                                   const TopoCutMap& cuts,
                                   const Branches& b) {
    if (!passes_global_dispatch(b, tags)) {
        return false;
    }

    if (!passes_sigma_dispatch(cfg, tags, cuts, b)) {
        return false;
    }

    return true;
}

// -----------------------------------------------------------------------------
// Histogram configuration
// -----------------------------------------------------------------------------

struct VarConfig {
    std::string key;
    std::string title;
    std::string x_title;
    int particle = 1;
    int kind = 0; // 0 theta, 1 momentum, 2 phi, 3 kinematics
    int n_panels = 7;
};

static std::vector<VarConfig> variable_configs() {
    return {
        {"p1_theta", "p_{1} #theta", "p_{1} #theta (deg)", 1, 0, 7},
        {"p1_p", "p_{1} momentum", "p_{1} momentum (GeV)", 1, 1, 7},
        {"p1_phi", "p_{1} #phi", "p_{1} #phi (deg)", 1, 2, 2},

        {"p2_theta", "p_{2} #theta", "p_{2} #theta (deg)", 2, 0, 7},
        {"p2_p", "p_{2} momentum", "p_{2} momentum (GeV)", 2, 1, 7},
        {"p2_phi", "p_{2} #phi", "p_{2} #phi (deg)", 2, 2, 2},

        {"x", "x_{B}", "x_{B}", 0, 3, 1},
        {"Q2", "Q^{2}", "Q^{2} (GeV^{2})", 0, 3, 1},
        {"minus_t1", "-t", "-t (GeV^{2})", 0, 3, 1},
        {"Mx2", "M_{X}^{2}", "M_{X}^{2} (GeV^{2})", 0, 3, 1},
        {"theta", "#theta", "#theta (rad)", 0, 3, 1},
        {"theta_pi0_pi0", "#theta_{#pi^{0}#pi^{0}}", "#theta_{#pi^{0}#pi^{0}} (rad)", 0, 3, 1},
        {"Emiss2", "E_{miss}^{2}", "E_{miss}^{2} (GeV^{2})", 0, 3, 1},
        {"Delta_phi", "#Delta#phi", "#Delta#phi (rad)", 0, 3, 1},
        {"Mx2_2", "M_{X}^{2}(e#gamma)", "M_{X}^{2}(e#gamma) (GeV^{2})", 0, 3, 1},
        {"pTmiss", "p_{T}^{miss}", "p_{T}^{miss} (GeV)", 0, 3, 1}
    };
}

static int sector_from_phi(double phi) {
    const double p = wrap_phi_deg(phi);

    if ((p >= 330.0 && p < 360.0) || (p >= 0.0 && p < 30.0)) return 1;
    if (p >= 30.0 && p < 90.0) return 2;
    if (p >= 90.0 && p < 150.0) return 3;
    if (p >= 150.0 && p < 210.0) return 4;
    if (p >= 210.0 && p < 270.0) return 5;
    if (p >= 270.0 && p < 330.0) return 6;

    return 0;
}

static int panel_index(const VarConfig& v, const Branches& b) {
    if (v.kind == 3) {
        return 0;
    }

    double theta = (v.particle == 1) ? b.p1_theta_deg() : b.p2_theta_deg();
    double phi = (v.particle == 1) ? b.p1_phi_deg() : b.p2_phi_deg();

    if (v.kind == 2) {
        if (v.particle == 1) {
            if (theta >= 0.0 && theta < 40.0) return 0;
            if (theta >= 40.0 && theta < 70.0) return 1;
        } else {
            if (theta >= 5.0 && theta < 40.0) return 0;
            if (theta >= 0.0 && theta < 5.0) return 1;
        }

        return -1;
    }

    if (v.particle == 1) {
        if (theta >= 0.0 && theta < 40.0) {
            int sec = sector_from_phi(phi);
            return (sec >= 1 && sec <= 6) ? sec - 1 : -1;
        }

        if (theta >= 40.0 && theta < 70.0) return 6;

        return -1;
    }

    if (theta >= 5.0 && theta < 40.0) {
        int sec = sector_from_phi(phi);
        return (sec >= 1 && sec <= 6) ? sec - 1 : -1;
    }

    if (theta >= 0.0 && theta < 5.0) return 6;

    return -1;
}

static double value_for_var(const VarConfig& v, const Branches& b) {
    if (v.kind == 3) {
        if (v.key == "x") return b.x;
        if (v.key == "Q2") return b.Q2;
        if (v.key == "minus_t1") return -b.t1;
        if (v.key == "Mx2") return b.Mx2;
        if (v.key == "theta") return b.theta;
        if (v.key == "theta_pi0_pi0") return b.theta_pi0_pi0;
        if (v.key == "Emiss2") return b.Emiss2;
        if (v.key == "Delta_phi") { bool has=false; return b.delta_phi_value(has); }
        if (v.key == "Mx2_2") return b.Mx2_2;
        if (v.key == "pTmiss") return b.pTmiss;

        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: unknown kinematic variable key: " << v.key;
        fatal(ss.str());
    }

    if (v.particle == 1) {
        if (v.kind == 0) return b.p1_theta_deg();
        if (v.kind == 1) return b.p1_p;
        return b.p1_phi_deg();
    }

    if (v.kind == 0) return b.p2_theta_deg();
    if (v.kind == 1) return b.p2_p;

    return b.p2_phi_deg();
}

static int nbins_for_panel(const VarConfig& v, int panel) {
    if (v.kind == 3) {
        if (v.key == "x") return 35;
        if (v.key == "Q2") return 36;
        if (v.key == "minus_t1") return 40;
        if (v.key == "Mx2") return 60;
        if (v.key == "theta") return 60;
        if (v.key == "theta_pi0_pi0") return 60;
        if (v.key == "Emiss2") return 60;
        if (v.key == "Delta_phi") return 60;
        if (v.key == "Mx2_2") return 60;
        if (v.key == "pTmiss") return 60;

        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: unknown kinematic variable key: " << v.key;
        fatal(ss.str());
    }

    if (v.kind == 0) return (panel < 6) ? 12 : 23;
    if (v.kind == 1) return (panel < 6) ? 12 : 23;

    return (panel == 0) ? 12 : 24;
}

static void range_for_panel(const VarConfig& v, int panel, double& xmin, double& xmax) {
    if (v.kind == 3) {
        if (v.key == "x") {
            xmin = 0.0;
            xmax = 0.7;
            return;
        }

        if (v.key == "Q2") {
            xmin = 1.0;
            xmax = 7.0;
            return;
        }

        if (v.key == "minus_t1") {
            xmin = 0.0;
            xmax = 1.0;
            return;
        }

        if (v.key == "Mx2") {
            xmin = -0.03;
            xmax = 0.03;
            return;
        }

        if (v.key == "theta" || v.key == "theta_pi0_pi0") {
            xmin = 0.0; xmax = 0.2; return;
        }
        if (v.key == "Emiss2") {
            xmin = -1.0; xmax = 2.0; return;
        }
        if (v.key == "Delta_phi") {
            xmin = -0.5; xmax = 0.5; return;
        }

        if (v.key == "Mx2_2") {
            xmin = 0.0;
            xmax = 3.0;
            return;
        }

        if (v.key == "pTmiss") {
            xmin = 0.0;
            xmax = 0.3;
            return;
        }

        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: unknown kinematic variable key: " << v.key;
        fatal(ss.str());
    }

    if (v.kind == 0) {
        if (v.particle == 1) {
            xmin = (panel < 6) ? 0.0 : 40.0;
            xmax = (panel < 6) ? 40.0 : 70.0;
        } else {
            xmin = (panel < 6) ? 5.0 : 0.0;
            xmax = (panel < 6) ? 40.0 : 5.0;
        }

        return;
    }

    if (v.kind == 1) {
        xmin = (v.particle == 1) ? 0.3 : 2.0;
        xmax = (v.particle == 1) ? 1.3 : 6.0;
        return;
    }

    xmin = 0.0;
    xmax = 360.0;
}

static std::string panel_label(const VarConfig& v, int panel) {
    if (v.kind == 3) {
        return v.title;
    }

    if (v.kind == 2) {
        if (v.particle == 1) return (panel == 0) ? "FD" : "CD";
        return (panel == 0) ? "FD" : "FT";
    }

    if (panel < 6) {
        std::ostringstream ss;
        ss << "Sector " << panel + 1;
        return ss.str();
    }

    if (v.particle == 1) return "CD";

    return "FT";
}

static std::string normalization_region_for_event(const Branches& b) {
    const double theta = b.p1_theta_deg();

    if (theta >= 0.0 && theta < 40.0) {
        const int sec = sector_from_phi(b.p1_phi_deg());

        if (sec >= 1 && sec <= 6) {
            std::ostringstream ss;
            ss << "Sector " << sec;
            return ss.str();
        }

        return "";
    }

    if (theta >= 40.0 && theta < 70.0) {
        return "CD";
    }

    return "";
}

struct HistSet {
    std::map<std::string, std::vector<TH1D*>> hists;
};

static HistSet make_hist_set(const std::string& prefix) {
    HistSet hs;

    for (const VarConfig& v : variable_configs()) {
        std::vector<TH1D*> vec;

        for (int p = 0; p < v.n_panels; ++p) {
            double xmin = 0.0;
            double xmax = 1.0;
            range_for_panel(v, p, xmin, xmax);

            const int nb = nbins_for_panel(v, p);

            std::ostringstream name;
            name << prefix << "_" << v.key << "_panel_" << p;

            TH1D* h = new TH1D(name.str().c_str(), "", nb, xmin, xmax);
            h->Sumw2();
            h->GetXaxis()->SetTitle(v.x_title.c_str());
            h->GetYaxis()->SetTitle("Counts");

            vec.push_back(h);
        }

        hs.hists[v.key] = vec;
    }

    return hs;
}

static void delete_hist_set(HistSet& hs) {
    for (auto& kv : hs.hists) {
        for (TH1D* h : kv.second) {
            delete h;
        }

        kv.second.clear();
    }

    hs.hists.clear();
}

static void fill_hist_set(HistSet& hs, const Branches& b, double w) {
    for (const VarConfig& v : variable_configs()) {
        const int p = panel_index(v, b);

        if (p < 0 || p >= v.n_panels) {
            continue;
        }

        const double value = value_for_var(v, b);
        hs.hists[v.key][p]->Fill(value, w);
    }
}

static void add_hist_set(HistSet& dest, const HistSet& src) {
    for (const auto& kv : src.hists) {
        auto it = dest.hists.find(kv.first);

        if (it == dest.hists.end()) {
            continue;
        }

        for (size_t i = 0; i < kv.second.size(); ++i) {
            it->second[i]->Add(kv.second[i]);
        }
    }
}

static void add_bin_to_compatible_hist(TH1D& target,
                                       double x,
                                       double content,
                                       double error) {
    if (!(content != 0.0 || error != 0.0)) {
        return;
    }

    const int b = target.FindBin(x);

    if (b < 1 || b > target.GetNbinsX()) {
        return;
    }

    const double old_content = target.GetBinContent(b);
    const double old_error = target.GetBinError(b);

    target.SetBinContent(b, old_content + content);
    target.SetBinError(b, std::sqrt(old_error * old_error + error * error));
}

static void add_hist_to_compatible_hist(TH1D& target, const TH1D* source) {
    if (!source) {
        return;
    }

    for (int b = 1; b <= source->GetNbinsX(); ++b) {
        const double x = source->GetBinCenter(b);
        const double content = source->GetBinContent(b);
        const double error = source->GetBinError(b);

        add_bin_to_compatible_hist(target, x, content, error);
    }
}

static void build_p1_theta_fit_histograms_by_region(const HistSet& data_hists,
                                                    const HistSet& mc_hists,
                                                    const std::string& period,
                                                    std::map<std::string, TH1D*>& h_data_fit,
                                                    std::map<std::string, TH1D*>& h_mc_fit) {
    auto itd = data_hists.hists.find("p1_theta");
    auto itm = mc_hists.hists.find("p1_theta");

    if (itd == data_hists.hists.end() || itm == mc_hists.hists.end()) {
        fatal("[eppi0_norm] FATAL: p1_theta histograms are missing while building regional fit histograms.");
    }

    if (itd->second.size() != 7 || itm->second.size() != 7) {
        fatal("[eppi0_norm] FATAL: p1_theta regional histogram count is not 7.");
    }

    const std::vector<std::string> regions = normalization_regions();

    for (int panel = 0; panel < 7; ++panel) {
        const std::string& region = regions[panel];

        h_data_fit[region] = (TH1D*)itd->second[panel]->Clone(
            ("h_data_fit_" + period_dir(period) + "_" + std::to_string(panel)).c_str()
        );

        h_mc_fit[region] = (TH1D*)itm->second[panel]->Clone(
            ("h_mc_fit_" + period_dir(period) + "_" + std::to_string(panel)).c_str()
        );

        h_data_fit[region]->SetDirectory(nullptr);
        h_mc_fit[region]->SetDirectory(nullptr);

        std::cout << "[eppi0_norm] " << period << " " << region
                  << " p1_theta fit histogram integrals: data=" << h_data_fit[region]->Integral()
                  << " mc=" << h_mc_fit[region]->Integral() << std::endl;
    }
}

static CubicFit fit_p1_theta_ratio_region(const std::string& period,
                                          const std::string& region,
                                          const std::string& outdir,
                                          TH1D* h_data,
                                          TH1D* h_mc,
                                          CubicFit* legacy_raw_out,
                                          bool momentum_residual = false) {
    CubicFit p;

    if (!h_data || !h_mc) {
        return p;
    }

    TGraphErrors gr;
    TGraphErrors gr_ratio;
    int ip = 0;

    double fit_xmin = std::numeric_limits<double>::infinity();
    double fit_xmax = -std::numeric_limits<double>::infinity();

    for (int b = 1; b <= h_data->GetNbinsX(); ++b) {
        const double d = h_data->GetBinContent(b);
        const double m = h_mc->GetBinContent(b);

        if (!(d > 0.0 && m > 0.0)) {
            continue;
        }

        const double x = h_data->GetBinCenter(b);
        const double ed = h_data->GetBinError(b);
        const double em = h_mc->GetBinError(b);
        const double r = d / m;

        double er = 0.0;

        if (ed > 0.0 || em > 0.0) {
            const double rd = (ed > 0.0) ? ed / d : 0.0;
            const double rm = (em > 0.0) ? em / m : 0.0;
            er = std::fabs(r) * std::sqrt(rd * rd + rm * rm);
        }

        if (!(er > 0.0)) {
            er = 1.0;
        }

        // Fit ln(DATA/MC), rather than DATA/MC itself.  Exponentiating the
        // fitted cubic preserves the same smooth four-parameter flexibility
        // while enforcing the physical requirement DATA/MC > 0 everywhere.
        // The uncertainty transformation is the first-order propagation
        // sigma_lnR = sigma_R/R.
        gr.SetPoint(ip, x, std::log(r));
        gr.SetPointError(ip, 0.0, er / r);
        gr_ratio.SetPoint(ip, x, r);
        gr_ratio.SetPointError(ip, 0.0, er);
        ++ip;

        const double low = h_data->GetBinLowEdge(b);
        const double high = h_data->GetBinLowEdge(b + 1);

        fit_xmin = std::min(fit_xmin, low);
        fit_xmax = std::max(fit_xmax, high);
    }

    if (ip < 4 || !(fit_xmax > fit_xmin)) {
        if (momentum_residual) {
            std::ostringstream ss;
            ss << "[eppi0_norm] FATAL: " << period << " " << region
               << " residual proton-momentum fit has only " << ip
               << " valid DATA/(theta-corrected MC) bins. Refusing silent unity fallback.";
            fatal(ss.str());
        }
        p.a[0] = 1.0;
        p.x_min = h_data->GetXaxis()->GetXmin();
        p.x_max = h_data->GetXaxis()->GetXmax();
        p.valid = true;

        if (legacy_raw_out) *legacy_raw_out = p;
        std::cout << "[eppi0_norm] WARNING: " << period << " " << region
                  << " has fewer than four valid data/MC bins. Using unity fit."
                  << std::endl;

        return p;
    }

    CubicFit legacy_raw;
    {
        TF1 fraw("f_ratio_pol3_legacy", "pol3", fit_xmin, fit_xmax);
        TFitResultPtr raw_result = gr_ratio.Fit(&fraw, "SQ0", "", fit_xmin, fit_xmax);
        (void)raw_result;
        for (int i = 0; i < 4; ++i) {
            legacy_raw.a[i] = fraw.GetParameter(i);
            legacy_raw.ea[i] = fraw.GetParError(i);
        }
        legacy_raw.x_min = fit_xmin;
        legacy_raw.x_max = fit_xmax;
        legacy_raw.valid = true;
        legacy_raw.log_space = false;
    }
    if (legacy_raw_out) *legacy_raw_out = legacy_raw;

    TF1 f("f_log_ratio_pol3", "pol3", fit_xmin, fit_xmax);
    TFitResultPtr fit_result = gr.Fit(&f, "SQ0", "", fit_xmin, fit_xmax);
    (void)fit_result;

    for (int i = 0; i < 4; ++i) {
        p.a[i] = f.GetParameter(i);
        p.ea[i] = f.GetParError(i);
    }

    p.x_min = fit_xmin;
    p.x_max = fit_xmax;
    p.valid = true;
    p.log_space = true;

    const std::string fit_outdir = outdir + "/proton/fits";
    mkdir_p(fit_outdir);

    std::string safe_region = region;

    for (char& c : safe_region) {
        if (c == ' ') {
            c = '_';
        }
    }

    TCanvas c(("c_p1_theta_ratio_fit_" + safe_region).c_str(), "", 1000, 750);
    c.SetGrid(1, 1);
    c.SetLeftMargin(0.14);
    c.SetRightMargin(0.05);
    c.SetBottomMargin(0.13);
    c.SetTopMargin(0.08);

    const double xframe_min = h_data->GetXaxis()->GetXmin();
    const double xframe_max = h_data->GetXaxis()->GetXmax();

    TH1D* frame = (TH1D*)gPad->DrawFrame(xframe_min, RATIO_Y_MIN, xframe_max, RATIO_Y_MAX);
    const std::string fit_kind = momentum_residual ? "residual p_{1} momentum" : "p_{1} #theta";
    frame->SetTitle((period + "  " + region + "  ep #rightarrow ep#pi_{0}  " + fit_kind + " ratio positive log-cubic fit").c_str());
    frame->GetXaxis()->SetTitle(momentum_residual ? "p_{1} momentum (GeV)" : "p_{1} #theta (deg)");
    frame->GetYaxis()->SetTitle("data / MC");
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);

    TLine* unity_line = new TLine(xframe_min, 1.0, xframe_max, 1.0);
    unity_line->SetLineStyle(2);
    unity_line->SetLineColor(kRed + 1);
    unity_line->SetLineWidth(2);
    unity_line->SetBit(TObject::kCanDelete);
    unity_line->Draw("SAME");

    gr_ratio.SetMarkerStyle(20);
    gr_ratio.SetMarkerColor(kBlack);
    gr_ratio.SetLineColor(kBlack);
    gr_ratio.Draw("PE SAME");

    TF1 fdraw("f_log_ratio_pol3_draw", "exp([0]+x*([1]+x*([2]+x*[3])))", fit_xmin, fit_xmax);

    for (int i = 0; i < 4; ++i) {
        fdraw.SetParameter(i, p.a[i]);
    }

    TF1 frawdraw("f_ratio_pol3_legacy_draw", "pol3", fit_xmin, fit_xmax);
    for (int i = 0; i < 4; ++i) frawdraw.SetParameter(i, legacy_raw.a[i]);
    frawdraw.SetLineColor(kGray + 2);
    frawdraw.SetLineStyle(2);
    frawdraw.SetLineWidth(2);
    frawdraw.Draw("L SAME");

    fdraw.SetLineColor(kRed + 1);
    fdraw.SetLineWidth(2);
    fdraw.Draw("L SAME");

    TLegend leg(0.56, 0.66, 0.90, 0.84);
    leg.SetFillColor(kWhite);
    leg.SetFillStyle(1001);
    leg.SetBorderSize(1);
    leg.AddEntry(&gr_ratio, "data / MC", "pe");
    leg.AddEntry(&frawdraw, "old raw cubic", "l");
    leg.AddEntry(&fdraw, "production positive log-cubic", "l");
    leg.Draw();

    const std::string fit_filename = momentum_residual
        ? ("/proton_momentum_residual_ratio_logcubic_fit_" + safe_region + ".png")
        : ("/proton_theta_ratio_logcubic_fit_" + safe_region + ".png");
    c.SaveAs((fit_outdir + fit_filename).c_str());

    return p;
}

static std::vector<TGraphErrors*> make_ratio_graphs(const std::vector<TH1D*>& hd,
                                                    const std::vector<TH1D*>& hm) {
    std::vector<TGraphErrors*> out;

    for (size_t i = 0; i < hd.size(); ++i) {
        TGraphErrors* g = new TGraphErrors();
        int ip = 0;

        for (int b = 1; b <= hd[i]->GetNbinsX(); ++b) {
            const double d = hd[i]->GetBinContent(b);
            const double m = hm[i]->GetBinContent(b);

            if (!(d > 0.0 && m > 0.0)) {
                continue;
            }

            const double ed = hd[i]->GetBinError(b);
            const double em = hm[i]->GetBinError(b);
            const double r = d / m;

            const double er = std::fabs(r) * std::sqrt((ed / d) * (ed / d) + (em / m) * (em / m));

            g->SetPoint(ip, hd[i]->GetBinCenter(b), r);
            g->SetPointError(ip, 0.0, er);
            ++ip;
        }

        g->SetMarkerStyle(20);
        g->SetMarkerColor(kBlack);
        g->SetLineColor(kBlack);

        out.push_back(g);
    }

    return out;
}

static SummaryRatioCurve make_summary_ratio_curve(const std::string& period,
                                                  const VarConfig& v,
                                                  const std::vector<TH1D*>& hd,
                                                  const std::vector<TH1D*>& hm) {
    SummaryRatioCurve curve;
    curve.key = v.key;
    curve.title = v.title;
    curve.x_title = v.x_title;

    if (hd.empty() || hm.empty() || !hd[0] || !hm[0]) {
        return curve;
    }

    TH1D* h_data = hd[0];
    TH1D* h_mc = hm[0];

    const int n_bins = std::min(h_data->GetNbinsX(), h_mc->GetNbinsX());

    for (int b = 1; b <= n_bins; ++b) {
        const double d = h_data->GetBinContent(b);
        const double m = h_mc->GetBinContent(b);

        if (!(d > 0.0 && m > 0.0)) {
            continue;
        }

        const double ed = h_data->GetBinError(b);
        const double em = h_mc->GetBinError(b);
        const double ratio = d / m;

        const double rel_d = (ed > 0.0) ? ed / d : 0.0;
        const double rel_m = (em > 0.0) ? em / m : 0.0;
        const double ratio_err = std::fabs(ratio) * std::sqrt(rel_d * rel_d + rel_m * rel_m);

        curve.x.push_back(h_data->GetBinCenter(b));
        curve.y.push_back(ratio);
        curve.ey.push_back(ratio_err);
    }

    std::cout << "[eppi0_norm] " << period
              << " summary ratio curve " << v.key
              << " points=" << curve.x.size() << std::endl;

    return curve;
}

struct PlotNormInfo {
    double total_charge_mc = 0.0;
    double integrated_luminosity_pb_inv = 0.0;
    double n_gen = 0.0;
    double event_norm = 0.0;
};

static void style_hist_for_plot(TH1D* h, int color, int marker) {
    if (!h) {
        return;
    }

    h->SetLineColor(color);
    h->SetLineWidth(2);
    h->SetMarkerColor(color);
    h->SetMarkerStyle(marker);
    h->SetMarkerSize(0.8);
    h->SetStats(false);
    h->GetXaxis()->CenterTitle(true);
    h->GetYaxis()->CenterTitle(true);
    h->GetXaxis()->SetTitleSize(0.050);
    h->GetYaxis()->SetTitleSize(0.050);
    h->GetXaxis()->SetLabelSize(0.045);
    h->GetYaxis()->SetLabelSize(0.045);
    h->GetYaxis()->SetTitleOffset(1.45);
}

static void style_ratio_frame(TH1D* frame) {
    if (!frame) {
        return;
    }

    frame->SetStats(false);
    frame->SetMinimum(RATIO_Y_MIN);
    frame->SetMaximum(RATIO_Y_MAX);
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);
    frame->GetXaxis()->SetTitleSize(0.050);
    frame->GetYaxis()->SetTitleSize(0.050);
    frame->GetXaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetTitleOffset(1.45);
}

static void draw_panel_title(const std::string& text) {
    TLatex latex;
    latex.SetNDC(true);
    latex.SetTextFont(42);
    latex.SetTextSize(0.050);
    latex.DrawLatex(0.18, 0.925, text.c_str());
}

static void draw_normalization_pad(const std::string& period,
                                   const VarConfig& v,
                                   const PlotNormInfo& norm,
                                   bool ratio_mode) {
    TPad* pad = (TPad*)gPad;

    if (!pad) {
        return;
    }

    pad->Clear();
    pad->SetFillColor(kWhite);
    pad->SetLeftMargin(0.08);
    pad->SetRightMargin(0.04);
    pad->SetTopMargin(0.04);
    pad->SetBottomMargin(0.04);

    TLatex latex;
    latex.SetNDC(true);
    latex.SetTextFont(42);
    latex.SetTextSize((v.kind == 2) ? 0.040 : 0.034);

    const double x0 = 0.10;

    latex.DrawLatex(x0, 0.90, period.c_str());

    if (v.kind == 3) {
        latex.DrawLatex(x0, 0.80, "kinematics");
    } else {
        latex.DrawLatex(x0, 0.80, (v.particle == 1) ? "p_{1}" : "p_{2}");
    }

    latex.DrawLatex(x0, 0.70, v.title.c_str());
    latex.DrawLatex(x0, 0.60, ratio_mode ? "Ratio normalization" : "MC normalization");

    std::ostringstream ss;

    ss << std::setprecision(6) << "Q = " << norm.total_charge_mc << " mC";
    latex.DrawLatex(x0, 0.49, ss.str().c_str());

    ss.str("");
    ss.clear();
    ss << std::setprecision(6) << "L_{int} = " << norm.integrated_luminosity_pb_inv << " pb^{-1}";
    latex.DrawLatex(x0, 0.39, ss.str().c_str());

    ss.str("");
    ss.clear();
    ss << std::setprecision(6) << "N_{gen} = " << norm.n_gen;
    latex.DrawLatex(x0, 0.29, ss.str().c_str());

    ss.str("");
    ss.clear();
    ss << std::setprecision(6) << "event weight = " << norm.event_norm;
    latex.DrawLatex(x0, 0.19, ss.str().c_str());

    latex.DrawLatex(x0, 0.09, ratio_mode ? "ratio: data / MC" : "MC fill: const AAOgen norm");
}

static TLegend* make_comparison_legend(TH1D* h_data, TH1D* h_mc) {
    TLegend* leg = new TLegend(0.56, 0.705, 0.90, 0.875);
    leg->SetBorderSize(1);
    leg->SetFillStyle(1001);
    leg->SetFillColor(kWhite);
    leg->SetTextSize(0.032);
    leg->SetMargin(0.22);
    leg->AddEntry(h_data, "data", "l");
    leg->AddEntry(h_mc, "AAOgen MC", "l");

    return leg;
}

static std::pair<double, double> common_y_range(const std::vector<TH1D*>& hd,
                                                const std::vector<TH1D*>& hm,
                                                const std::vector<int>& panels,
                                                bool /*log_y*/) {
    double ymax = 0.0;

    for (int p : panels) {
        if (p < 0 || p >= (int)hd.size() || p >= (int)hm.size()) {
            continue;
        }

        ymax = std::max(ymax, hd[p]->GetMaximum());
        ymax = std::max(ymax, hm[p]->GetMaximum());
    }

    if (!(ymax > 0.0)) {
        ymax = 1.0;
    }

    return {0.0, 1.20 * ymax};
}

static std::pair<double, double> y_range_for_panel(const VarConfig& v,
                                                   const std::vector<TH1D*>& hd,
                                                   const std::vector<TH1D*>& hm,
                                                   int panel,
                                                   bool log_y) {
    if (v.kind == 3) {
        return common_y_range(hd, hm, {0}, log_y);
    }

    if (v.kind == 2) {
        if (panel == 0) return common_y_range(hd, hm, {0}, log_y);
        if (panel == 1) return common_y_range(hd, hm, {1}, log_y);
    } else {
        if (panel >= 0 && panel <= 5) return common_y_range(hd, hm, {0, 1, 2, 3, 4, 5}, log_y);
        if (panel == 6) return common_y_range(hd, hm, {6}, log_y);
    }

    return {0.0, 1.0};
}

static void draw_comparison_panel(const std::string& /*period*/,
                                  const VarConfig& v,
                                  TH1D* h_data,
                                  TH1D* h_mc,
                                  int panel,
                                  const std::pair<double, double>& yr,
                                  bool /*log_y*/) {
    TPad* pad = (TPad*)gPad;

    pad->SetLeftMargin(0.16);
    pad->SetRightMargin(0.06);
    pad->SetTopMargin(0.12);
    pad->SetBottomMargin(0.14);
    pad->SetLogy(false);
    pad->SetGrid(0, 0);

    style_hist_for_plot(h_data, kBlue + 1, 20);
    style_hist_for_plot(h_mc, kRed + 1, 24);

    double xmin = 0.0;
    double xmax = 1.0;
    range_for_panel(v, panel, xmin, xmax);

    TH1D* frame = (TH1D*)pad->DrawFrame(xmin, yr.first, xmax, yr.second);
    frame->SetStats(false);
    frame->SetTitle("");
    frame->GetXaxis()->SetTitle(v.x_title.c_str());
    frame->GetYaxis()->SetTitle("Counts");
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);
    frame->GetXaxis()->SetTitleSize(0.050);
    frame->GetYaxis()->SetTitleSize(0.050);
    frame->GetXaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetTitleOffset(1.45);

    h_data->Draw("HIST SAME");
    h_mc->Draw("HIST SAME");

    draw_panel_title(panel_label(v, panel));

    TLegend* leg = make_comparison_legend(h_data, h_mc);
    leg->Draw();

    pad->RedrawAxis();
}

static void draw_ratio_panel(const std::string& /*period*/,
                             const VarConfig& v,
                             TGraphErrors* gr,
                             int panel,
                             const std::map<std::string, CubicFit>* fits_for_p1_theta) {
    TPad* pad = (TPad*)gPad;

    pad->SetLeftMargin(0.16);
    pad->SetRightMargin(0.06);
    pad->SetTopMargin(0.12);
    pad->SetBottomMargin(0.14);
    pad->SetGrid(0, 0);

    double xmin = 0.0;
    double xmax = 1.0;
    range_for_panel(v, panel, xmin, xmax);

    TH1D* frame = (TH1D*)pad->DrawFrame(xmin, RATIO_Y_MIN, xmax, RATIO_Y_MAX);
    frame->SetTitle("");
    frame->GetXaxis()->SetTitle(v.x_title.c_str());
    frame->GetYaxis()->SetTitle("data / MC");
    style_ratio_frame(frame);

    TLine* unity_line = new TLine(xmin, 1.0, xmax, 1.0);
    unity_line->SetLineStyle(2);
    unity_line->SetLineColor(kRed + 1);
    unity_line->SetLineWidth(2);
    unity_line->SetBit(TObject::kCanDelete);
    unity_line->Draw("SAME");

    if (gr) {
        gr->SetMarkerStyle(20);
        gr->SetMarkerSize(0.8);
        gr->SetMarkerColor(kBlack);
        gr->SetLineColor(kBlack);
        gr->Draw("PE SAME");
    }

    if (fits_for_p1_theta && v.key == "p1_theta") {
        const std::string region = panel_label(v, panel);
        auto it_fit = fits_for_p1_theta->find(region);

        if (it_fit != fits_for_p1_theta->end() && it_fit->second.valid) {
            const CubicFit& fit = it_fit->second;
            const double draw_xmin = std::max(xmin, fit.x_min);
            const double draw_xmax = std::min(xmax, fit.x_max);

            if (draw_xmax > draw_xmin) {
                TF1 f("f_cubic_overlay", "pol3", draw_xmin, draw_xmax);

                for (int i = 0; i < 4; ++i) {
                    f.SetParameter(i, fit.a[i]);
                }

                f.SetLineColor(kRed + 1);
                f.SetLineWidth(2);
                f.DrawCopy("L SAME");
            }
        }
    }

    draw_panel_title(panel_label(v, panel));
    pad->RedrawAxis();
}

static void draw_sector_comparison_canvas(const std::string& out_png,
                                          const std::string& period,
                                          const VarConfig& v,
                                          const std::vector<TH1D*>& hd,
                                          const std::vector<TH1D*>& hm,
                                          const PlotNormInfo& norm,
                                          bool log_y) {
    TCanvas canvas(("canvas_" + v.key + (log_y ? "_comparison_log" : "_comparison_linear")).c_str(), "", 1600, 900);
    canvas.Divide(4, 2);

    const int canvas_pad_for_panel[7] = {1, 2, 3, 5, 6, 7, 8};

    for (int panel = 0; panel < 7; ++panel) {
        canvas.cd(canvas_pad_for_panel[panel]);

        const auto yr = y_range_for_panel(v, hd, hm, panel, log_y);

        draw_comparison_panel(period,
                              v,
                              hd[panel],
                              hm[panel],
                              panel,
                              yr,
                              log_y);
    }

    canvas.cd(4);
    draw_normalization_pad(period, v, norm, false);

    canvas.SaveAs(out_png.c_str());
}

static void draw_phi_comparison_canvas(const std::string& out_png,
                                       const std::string& period,
                                       const VarConfig& v,
                                       const std::vector<TH1D*>& hd,
                                       const std::vector<TH1D*>& hm,
                                       const PlotNormInfo& norm,
                                       bool log_y) {
    TCanvas canvas(("canvas_" + v.key + (log_y ? "_comparison_log" : "_comparison_linear")).c_str(), "", 1600, 500);
    canvas.Divide(3, 1);

    for (int panel = 0; panel < 2; ++panel) {
        canvas.cd(panel + 1);

        const auto yr = y_range_for_panel(v, hd, hm, panel, log_y);

        draw_comparison_panel(period,
                              v,
                              hd[panel],
                              hm[panel],
                              panel,
                              yr,
                              log_y);
    }

    canvas.cd(3);
    draw_normalization_pad(period, v, norm, false);

    canvas.SaveAs(out_png.c_str());
}

static void draw_kinematics_comparison_canvas(const std::string& out_png,
                                              const std::string& period,
                                              const VarConfig& v,
                                              const std::vector<TH1D*>& hd,
                                              const std::vector<TH1D*>& hm,
                                              const PlotNormInfo& norm,
                                              bool log_y) {
    TCanvas canvas(("canvas_" + v.key + (log_y ? "_comparison_log" : "_comparison_linear")).c_str(), "", 1100, 750);
    canvas.Divide(2, 1);

    canvas.cd(1);

    const auto yr = y_range_for_panel(v, hd, hm, 0, log_y);

    draw_comparison_panel(period,
                          v,
                          hd[0],
                          hm[0],
                          0,
                          yr,
                          log_y);

    canvas.cd(2);
    draw_normalization_pad(period, v, norm, false);

    canvas.SaveAs(out_png.c_str());
}

static void draw_sector_ratio_canvas(const std::string& out_png,
                                     const std::string& period,
                                     const VarConfig& v,
                                     const std::vector<TGraphErrors*>& gr,
                                     const PlotNormInfo& norm,
                                     const std::map<std::string, CubicFit>* fits_for_p1_theta) {
    TCanvas canvas(("canvas_" + v.key + "_ratio_linear").c_str(), "", 1600, 900);
    canvas.Divide(4, 2);

    const int canvas_pad_for_panel[7] = {1, 2, 3, 5, 6, 7, 8};

    for (int panel = 0; panel < 7; ++panel) {
        canvas.cd(canvas_pad_for_panel[panel]);

        draw_ratio_panel(period,
                         v,
                         gr[panel],
                         panel,
                         fits_for_p1_theta);
    }

    canvas.cd(4);
    draw_normalization_pad(period, v, norm, true);

    canvas.SaveAs(out_png.c_str());
}

static void draw_phi_ratio_canvas(const std::string& out_png,
                                  const std::string& period,
                                  const VarConfig& v,
                                  const std::vector<TGraphErrors*>& gr,
                                  const PlotNormInfo& norm,
                                  const std::map<std::string, CubicFit>* fits_for_p1_theta) {
    TCanvas canvas(("canvas_" + v.key + "_ratio_linear").c_str(), "", 1600, 500);
    canvas.Divide(3, 1);

    for (int panel = 0; panel < 2; ++panel) {
        canvas.cd(panel + 1);

        draw_ratio_panel(period,
                         v,
                         gr[panel],
                         panel,
                         fits_for_p1_theta);
    }

    canvas.cd(3);
    draw_normalization_pad(period, v, norm, true);

    canvas.SaveAs(out_png.c_str());
}

static void draw_kinematics_ratio_canvas(const std::string& out_png,
                                         const std::string& period,
                                         const VarConfig& v,
                                         const std::vector<TGraphErrors*>& gr,
                                         const PlotNormInfo& norm,
                                         const std::map<std::string, CubicFit>* fits_for_p1_theta) {
    TCanvas canvas(("canvas_" + v.key + "_ratio_linear").c_str(), "", 1100, 750);
    canvas.Divide(2, 1);

    canvas.cd(1);

    draw_ratio_panel(period,
                     v,
                     gr[0],
                     0,
                     fits_for_p1_theta);

    canvas.cd(2);
    draw_normalization_pad(period, v, norm, true);

    canvas.SaveAs(out_png.c_str());
}

static void plot_variable(const std::string& outdir,
                          const std::string& period,
                          const VarConfig& v,
                          const std::vector<TH1D*>& hd,
                          const std::vector<TH1D*>& hm,
                          const PlotNormInfo& norm,
                          const std::map<std::string, CubicFit>* fits_for_p1_theta) {
    mkdir_p(outdir);

    std::string subdir;

    if (v.kind == 3) {
        subdir = outdir + "/kinematics";
    } else {
        subdir = outdir + ((v.particle == 1) ? "/proton" : "/pi0");
    }

    mkdir_p(subdir);

    const std::string linear_png = subdir + "/" + v.key + "_comparison_linear.png";
    const std::string ratio_png = subdir + "/" + v.key + "_ratio_linear.png";

    if (v.kind == 3) {
        draw_kinematics_comparison_canvas(linear_png,
                                          period,
                                          v,
                                          hd,
                                          hm,
                                          norm,
                                          false);
    } else if (v.kind == 2) {
        draw_phi_comparison_canvas(linear_png,
                                   period,
                                   v,
                                   hd,
                                   hm,
                                   norm,
                                   false);
    } else {
        draw_sector_comparison_canvas(linear_png,
                                      period,
                                      v,
                                      hd,
                                      hm,
                                      norm,
                                      false);
    }

    std::vector<TGraphErrors*> gr = make_ratio_graphs(hd, hm);

    if (v.kind == 3) {
        draw_kinematics_ratio_canvas(ratio_png,
                                     period,
                                     v,
                                     gr,
                                     norm,
                                     fits_for_p1_theta);
    } else if (v.kind == 2) {
        draw_phi_ratio_canvas(ratio_png,
                              period,
                              v,
                              gr,
                              norm,
                              fits_for_p1_theta);
    } else {
        draw_sector_ratio_canvas(ratio_png,
                                 period,
                                 v,
                                 gr,
                                 norm,
                                 fits_for_p1_theta);
    }

    for (TGraphErrors* g : gr) {
        delete g;
    }
}

// -----------------------------------------------------------------------------
// Production current-response model
// -----------------------------------------------------------------------------

static constexpr int kCurrentRegionCount = 7;

static const std::array<std::string, kCurrentRegionCount>& current_region_names() {
    static const std::array<std::string, kCurrentRegionCount> names = {
        "FT", "S1", "S2", "S3", "S4", "S5", "S6"
    };
    return names;
}

static std::string photon_pair_topology(const Branches& b) {
    // eppi0 EPGG convention used elsewhere in this suite: 0 = FT, 1 = FD.
    if (!(b.has_detector_gamma1 && b.has_detector_gamma2)) return "";
    const int d1 = b.detector_gamma1;
    const int d2 = b.detector_gamma2;
    if (d1 == 0 && d2 == 0) return "FT-FT";
    if ((d1 == 0 && d2 == 1) || (d1 == 1 && d2 == 0)) return "FT-FD";
    if (d1 == 1 && d2 == 1) return "FD-FD";
    return "";
}

static const std::vector<std::string>& photon_pair_topologies() {
    static const std::vector<std::string> v = {"FT-FT", "FT-FD", "FD-FD"};
    return v;
}

static int current_region_index(int detector2, double p2_phi_rad, bool has_p2_phi) {
    if (detector2 == 0) return 0;
    if (detector2 != 1 || !has_p2_phi || !std::isfinite(p2_phi_rad)) return -1;
    double phi = std::fmod(p2_phi_rad * RAD2DEG, 360.0);
    if (phi < 0.0) phi += 360.0;
    int sector = 0;
    if (phi >= 330.0 || phi < 30.0) sector = 1;
    else if (phi < 90.0) sector = 2;
    else if (phi < 150.0) sector = 3;
    else if (phi < 210.0) sector = 4;
    else if (phi < 270.0) sector = 5;
    else if (phi < 330.0) sector = 6;
    return (sector >= 1 && sector <= 6) ? sector : -1;
}

struct CurrentResponseEntry {
    bool valid = false;
    double parameter = std::numeric_limits<double>::quiet_NaN();
    bool has_angular_model = false;
    double angular_center = 0.0;
    double angular_gradient = 0.0;
};

struct CurrentResponseModel {
    std::map<std::string, std::map<std::string, std::array<CurrentResponseEntry, kCurrentRegionCount>>> data;
    std::map<std::string, std::map<std::string, std::array<CurrentResponseEntry, kCurrentRegionCount>>> mc;
    std::map<std::string, std::unordered_map<int, int>> run_current_nA;
    std::map<std::string, std::unordered_set<int>> excluded_data_runs;
};

static CurrentResponseModel load_current_response_model(const std::string& path) {
    std::ifstream fin(path);
    if (!fin.is_open()) fatal("[eppi0_norm] FATAL: cannot open current-response model JSON: " + path);
    nlohmann::json j; fin >> j;
    CurrentResponseModel model;

    auto load_block = [&](const char* sample, auto& dst, const char* value_key) {
        if (!j.contains(sample) || !j[sample].is_object()) return;
        for (auto ch = j[sample].begin(); ch != j[sample].end(); ++ch) {
            for (auto per = ch.value().begin(); per != ch.value().end(); ++per) {
                std::array<CurrentResponseEntry, kCurrentRegionCount> arr{};
                for (int ir = 0; ir < kCurrentRegionCount; ++ir) {
                    const std::string& rn = current_region_names()[ir];
                    if (!per.value().contains(rn)) continue;
                    const auto& e = per.value()[rn];
                    if (!e.contains(value_key)) continue;
                    const double v = e[value_key].get<double>();
                    if (!std::isfinite(v)) continue;
                    arr[ir].valid = true;
                    arr[ir].parameter = v;
                    if (std::string(sample) == "data" && e.contains("angular_model") && e["angular_model"].is_object()) {
                        const auto& a = e["angular_model"];
                        if (a.value("variable", std::string()) == "e_theta") {
                            const double center = a.value("center", std::numeric_limits<double>::quiet_NaN());
                            const double grad = a.value("gradient_per_nA_per_deg", std::numeric_limits<double>::quiet_NaN());
                            if (std::isfinite(center) && std::isfinite(grad)) {
                                arr[ir].has_angular_model = true;
                                arr[ir].angular_center = center;
                                arr[ir].angular_gradient = grad;
                            }
                        }
                    }
                }
                dst[ch.key()][per.key()] = arr;
            }
        }
    };
    load_block("data", model.data, "relative_slope_per_nA");
    load_block("mc", model.mc, "reference_factor");

    if (j.contains("run_current_nA")) {
        for (auto per = j["run_current_nA"].begin(); per != j["run_current_nA"].end(); ++per)
            for (auto rr = per.value().begin(); rr != per.value().end(); ++rr)
                model.run_current_nA[per.key()][std::stoi(rr.key())] = rr.value().get<int>();
    }
    if (j.contains("excluded_data_runs")) {
        for (auto per = j["excluded_data_runs"].begin(); per != j["excluded_data_runs"].end(); ++per)
            for (auto rr = per.value().begin(); rr != per.value().end(); ++rr)
                model.excluded_data_runs[per.key()].insert(std::stoi(rr.key()));
    }
    return model;
}

template <typename Table>
static const CurrentResponseEntry* find_current_response_entry(
    const Table& table, const std::string& channel, const std::string& period, int region) {
    auto ic = table.find(channel);
    if (ic == table.end()) return nullptr;
    auto ip = ic->second.find(period);
    if (ip == ic->second.end() || region < 0 || region >= kCurrentRegionCount) return nullptr;
    return &ip->second[region];
}

static double event_current_weight(const CurrentResponseModel& model,
                                         const std::string& channel,
                                         const std::string& period,
                                         const Branches& b,
                                         bool is_data,
                                         bool& skip) {
    skip = false;
    const int region = current_region_index(b.detector2, b.p2_phi, b.has_p2_phi);
    if (region < 0) fatal("[eppi0_norm] FATAL: cannot determine photon current-response region.");

    if (is_data) {
        const CurrentResponseEntry* e = find_current_response_entry(model.data, channel, period, region);
        if (!e || !e->valid) fatal("[eppi0_norm] FATAL: missing DATA " + channel + " current response for " + period + "/" + current_region_names()[region]);
        auto ip = model.run_current_nA.find(period);
        if (ip == model.run_current_nA.end()) fatal("[eppi0_norm] FATAL: missing run-current map for " + period);
        auto ir = ip->second.find(b.runnum);
        if (ir == ip->second.end()) {
            auto ie = model.excluded_data_runs.find(period);
            if (ie != model.excluded_data_runs.end() && ie->second.count(b.runnum)) { skip = true; return 0.0; }
            fatal("[eppi0_norm] FATAL: run " + std::to_string(b.runnum) + " has no current assignment for " + period);
        }
        double slope = e->parameter;
        if (e->has_angular_model) {
            if (!b.has_e_theta || !std::isfinite(b.e_theta)) fatal("[eppi0_norm] FATAL: angular current model requires e_theta.");
            slope += e->angular_gradient * (b.e_theta * RAD2DEG - e->angular_center);
        }
        const double response = 1.0 + slope * static_cast<double>(ir->second);
        if (!(std::isfinite(response) && response > 0.0)) fatal("[eppi0_norm] FATAL: non-positive DATA current response.");
        return 1.0 / response;
    }

    const CurrentResponseEntry* e = find_current_response_entry(model.mc, channel, period, region);
    if (!e || !e->valid || !(e->parameter > 0.0)) fatal("[eppi0_norm] FATAL: missing MC " + channel + " current response for " + period + "/" + current_region_names()[region]);
    return 1.0 / e->parameter;
}

static void draw_kinematics_overview_canvases(const std::string& outdir,
                                                const std::string& period,
                                                const HistSet& data,
                                                const HistSet& mc) {
    mkdir_p(outdir);
    std::vector<VarConfig> vars;
    for (const VarConfig& v : variable_configs()) if (v.kind == 3) vars.push_back(v);
    if (vars.empty()) return;

    const int nx = 2;
    const int ny = static_cast<int>((vars.size() + 1) / 2);
    TCanvas ccmp(("c_kin_overview_cmp_" + period_dir(period)).c_str(), "", 1500, 320 * ny);
    ccmp.Divide(nx, ny, 0.002, 0.002);
    for (size_t i = 0; i < vars.size(); ++i) {
        const VarConfig& v = vars[i];
        ccmp.cd(static_cast<int>(i) + 1);
        const auto yr = y_range_for_panel(v, data.hists.at(v.key), mc.hists.at(v.key), 0, false);
        draw_comparison_panel(period, v, data.hists.at(v.key)[0], mc.hists.at(v.key)[0], 0, yr, false);
    }
    ccmp.SaveAs((outdir + "/kinematics_data_mc_overview.png").c_str());

    TCanvas crat(("c_kin_overview_ratio_" + period_dir(period)).c_str(), "", 1500, 320 * ny);
    crat.Divide(nx, ny, 0.002, 0.002);
    std::vector<TGraphErrors*> keep_ratio_graphs;
    for (size_t i = 0; i < vars.size(); ++i) {
        const VarConfig& v = vars[i];
        std::vector<TGraphErrors*> gr = make_ratio_graphs(data.hists.at(v.key), mc.hists.at(v.key));
        crat.cd(static_cast<int>(i) + 1);
        draw_ratio_panel(period, v, gr[0], 0, nullptr);
        keep_ratio_graphs.insert(keep_ratio_graphs.end(), gr.begin(), gr.end());
    }
    crat.SaveAs((outdir + "/kinematics_data_over_mc_overview.png").c_str());
    for (TGraphErrors* g : keep_ratio_graphs) delete g;
}

// -----------------------------------------------------------------------------
// Period data/MC normalization histograms
// -----------------------------------------------------------------------------

struct PeriodHistResult {
    std::string period;
    HistSet data_hists;
    HistSet mc_hists;
    CubicFit poly;
    double integrated_ratio = 1.0;
    double integrated_ratio_err = 0.0;

    PeriodHistResult() :
        data_hists(make_hist_set("data_empty")),
        mc_hists(make_hist_set("mc_empty")) {
    }
};

static double data_charge_for_tree(TTree* tree,
                                   const std::unordered_map<int, double>& charge_map) {
    if (!tree) {
        return 0.0;
    }

    Branches b;
    b.bind(tree, false);

    if (!b.has_runnum) {
        fatal("[eppi0_norm] FATAL: data tree missing runnum.");
    }

    std::set<int> runs;
    const Long64_t N = tree->GetEntries();

    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);
        runs.insert(b.runnum);
    }

    double q = 0.0;

    for (int run : runs) {
        auto it = charge_map.find(run);

        if (it == charge_map.end()) {
            std::ostringstream ss;
            ss << "[eppi0_norm] FATAL: run " << run << " missing from charge CSV.";
            fatal(ss.str());
        }

        q += it->second;
    }

    return q;
}

static void fill_eppi0_data_hists_analysis(const ChannelConfig& cfg,
                                           const PeriodTags& tags,
                                           TTree* tree,
                                           const TopoCutMap& data_cuts,
                                           const CurrentResponseModel& current_model,
                                           HistSet& hists) {
    if (!tree) return;
    Branches b; b.bind(tree, false);
    const Long64_t N = tree->GetEntries();
    long long n_pass = 0, n_current_skip = 0;
    double sum_weight = 0.0;
    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);
        if (!passes_event_selection(cfg, tags, data_cuts, b)) continue;
        bool skip = false;
        const double w = event_current_weight(current_model, "ep->eppi0", tags.display, b, true, skip);
        if (skip) { ++n_current_skip; continue; }
        ++n_pass; sum_weight += w; fill_hist_set(hists, b, w);
    }
    std::cout << "[eppi0_norm] analysis DATA " << tags.display
              << " entries=" << (long long)N << " pass=" << n_pass
              << " current_skipped=" << n_current_skip
              << " sum_current_weight=" << sum_weight
              << " current_model=event_by_event_regional" << std::endl;
}


static void fill_p1_momentum_mc_after_theta(const ChannelConfig& cfg,
                                               const PeriodTags& tags,
                                               TTree* tree,
                                               const TopoCutMap& mc_cuts,
                                               double event_norm,
                                               const CurrentResponseModel& current_model,
                                               const HistSet& data_hists,
                                               const std::map<std::string, RegionNormalization>& regions,
                                               std::map<std::string, TH1D*>& out) {
    if (!tree) return;
    // IMPORTANT: clone the DATA p1_p histograms and reset them.  The previous
    // implementation accidentally used 0--6 GeV FD and 0--3 GeV CD MC
    // histograms while DATA uses the production 0.3--1.3 GeV p1_p range.
    // fit_p1_theta_ratio_region compares corresponding bin numbers, so that
    // mismatch made essentially every FD residual fit fall back to unity.
    auto itp = data_hists.hists.find("p1_p");
    if (itp == data_hists.hists.end() || itp->second.size() != 7)
        fatal("[eppi0_norm] FATAL: p1_p DATA templates missing for sequential momentum fit.");
    const std::vector<std::string> regs = normalization_regions();
    for (int panel=0; panel<7; ++panel) {
        const std::string& r = regs[panel];
        out[r] = (TH1D*)itp->second[panel]->Clone(
            ("h_p_resid_mc_"+period_dir(tags.display)+"_"+std::to_string(panel)).c_str());
        out[r]->Reset("ICES");
        out[r]->SetDirectory(nullptr);
        out[r]->Sumw2();
    }
    Branches b; b.bind(tree,true);
    const Long64_t N=tree->GetEntries();
    for(Long64_t i=0;i<N;++i){
        tree->GetEntry(i);
        if(!passes_event_selection(cfg,tags,mc_cuts,b)) continue;
        const std::string region=normalization_region_for_event(b);
        auto ir=regions.find(region); if(ir==regions.end() || !ir->second.fit.valid) continue;
        double th=b.p1_theta_deg();
        th=std::max(ir->second.fit.x_min,std::min(ir->second.fit.x_max,th));
        const double wtheta=ir->second.fit.eval(th);
        if(!(std::isfinite(wtheta)&&wtheta>0.0)) continue;
        bool skip=false;
        const double wc=event_current_weight(current_model,"ep->eppi0",tags.display,b,false,skip);
        if(skip) continue;
        out[region]->Fill(b.p1_p,event_norm*wc*wtheta);
    }
}

static void plot_p1_momentum_sequential_closure(const std::string& period,
                                                  const std::string& region,
                                                  const std::string& outdir,
                                                  TH1D* h_data,
                                                  TH1D* h_mc_after_theta,
                                                  const CubicFit& pfit) {
    if (!h_data || !h_mc_after_theta || !pfit.valid) return;
    TGraphErrors before, after;
    int ibefore=0, iafter=0;
    for (int b=1; b<=h_data->GetNbinsX(); ++b) {
        const double d=h_data->GetBinContent(b), ed=h_data->GetBinError(b);
        const double m=h_mc_after_theta->GetBinContent(b), em=h_mc_after_theta->GetBinError(b);
        if (!(d>0.0 && m>0.0)) continue;
        const double x=h_data->GetBinCenter(b);
        const double r0=d/m;
        const double er0=std::fabs(r0)*std::sqrt((ed/d)*(ed/d)+(em/m)*(em/m));
        before.SetPoint(ibefore,x,r0); before.SetPointError(ibefore,0.0,er0); ++ibefore;
        const double xe=std::max(pfit.x_min,std::min(pfit.x_max,x));
        const double wp=pfit.eval(xe);
        if (!(std::isfinite(wp)&&wp>0.0)) continue;
        const double mf=m*wp, emf=em*wp;
        const double r1=d/mf;
        const double er1=std::fabs(r1)*std::sqrt((ed/d)*(ed/d)+(emf/mf)*(emf/mf));
        after.SetPoint(iafter,x,r1); after.SetPointError(iafter,0.0,er1); ++iafter;
    }
    const std::string fit_outdir=outdir+"/proton/fits"; mkdir_p(fit_outdir);
    std::string safe=region; for(char& c:safe) if(c==' ') c='_';
    TCanvas c(("c_p_seq_closure_"+safe).c_str(),"",1000,750);
    c.SetGrid(1,1); c.SetLeftMargin(0.14); c.SetRightMargin(0.05); c.SetBottomMargin(0.13); c.SetTopMargin(0.08);
    const double xmin=h_data->GetXaxis()->GetXmin(), xmax=h_data->GetXaxis()->GetXmax();
    TH1D* frame=(TH1D*)gPad->DrawFrame(xmin,RATIO_Y_MIN,xmax,RATIO_Y_MAX);
    frame->SetTitle((period+"  "+region+"  sequential proton-momentum closure").c_str());
    frame->GetXaxis()->SetTitle("p_{1} momentum (GeV)"); frame->GetYaxis()->SetTitle("data / MC");
    TLine* unity=new TLine(xmin,1.0,xmax,1.0); unity->SetLineStyle(2); unity->SetLineWidth(2); unity->SetBit(TObject::kCanDelete); unity->Draw("SAME");
    before.SetMarkerStyle(24); before.Draw("PE SAME");
    after.SetMarkerStyle(20); after.Draw("PE SAME");
    TLegend leg(0.52,0.70,0.90,0.86); leg.SetFillStyle(1001); leg.SetBorderSize(1);
    leg.AddEntry(&before,"after #theta correction","pe"); leg.AddEntry(&after,"after #theta #times residual-p","pe"); leg.Draw();
    c.SaveAs((fit_outdir+"/proton_momentum_sequential_closure_"+safe+".png").c_str());
}

// -----------------------------------------------------------------------------
// Accepted reconstructed-AAOgen population for external pi0-model folding
// -----------------------------------------------------------------------------
// Fine enough that a smooth external correction M(xB,Q2,-t) can later be
// evaluated at the weighted mean of each occupied cell without writing one CSV
// row per MC event.  Only occupied cells are exported.
struct AcceptedMcCell {
    long long raw_events = 0;
    double sumw = 0.0;
    double sumw2 = 0.0;
    double sumw_x = 0.0;
    double sumw_q2 = 0.0;
    double sumw_t = 0.0;
    // Krishna/Neupane epsilon_data/epsilon_MC proton-efficiency ratio,
    // evaluated on the accepted reconstructed AAOgen proton kinematics.
    // This is exported only as a diagnostic moment; it is NOT multiplied into
    // the eppi0 normalization weights here.
    double sumw_proton_eff_ratio = 0.0;
    double sumw_proton_data_weight = 0.0;
    // Accepted pi0 Trento-phi moments.  These let the external analysis fold
    // sigma_LT*cos(phi) and sigma_TT*cos(2phi) through the actual accepted
    // AAOgen population without any event reprocessing.
    double sumw_cos_phi = 0.0;
    double sumw_cos_2phi = 0.0;
    std::array<double,12> sumw_phi_bins{};
    std::array<double,12> sumw2_phi_bins{};
};

static double eppi0_neupane_proton_efficiency_ratio(double p_gev,
                                                     double theta_rad,
                                                     double phi_rad) {
    if (!(std::isfinite(p_gev) && std::isfinite(theta_rad) && std::isfinite(phi_rad))) return 1.0;
    const double theta_deg = theta_rad * 180.0 / M_PI;
    double phi_deg = std::fmod(phi_rad * 180.0 / M_PI, 360.0);
    if (phi_deg < 0.0) phi_deg += 360.0;
    struct C { double a2, a1, a0; };
    C c{0.0,0.0,1.0};
    double p_eval=p_gev;
    if (theta_deg < 37.0) {
        static const std::array<C,6> coeff{{
            {0.04437,-0.14271,1.03439},{0.00490,0.00554,0.91770},
            {0.03671,-0.11680,1.03002},{0.01863,-0.07756,1.02308},
            {0.04915,-0.17173,1.11768},{0.01077,-0.01328,0.96242}}};
        int ib=static_cast<int>(std::floor(phi_deg/60.0)); ib=std::max(0,std::min(5,ib));
        c=coeff[static_cast<std::size_t>(ib)]; p_eval=std::max(0.4,std::min(4.0,p_eval));
    } else {
        static const std::array<C,3> coeff{{
            {0.20052,-0.79964,1.38699},{0.16842,-0.64970,1.31246},
            {0.18845,-0.75824,1.41677}}};
        int ib=static_cast<int>(std::floor(phi_deg/120.0)); ib=std::max(0,std::min(2,ib));
        c=coeff[static_cast<std::size_t>(ib)]; p_eval=std::max(0.5,std::min(2.2,p_eval));
    }
    const double ratio=c.a2*p_eval*p_eval+c.a1*p_eval+c.a0;
    if (!(std::isfinite(ratio) && ratio>0.20 && ratio<1.80)) return 1.0;
    return ratio;
}

struct AcceptedMcPopulation {
    static constexpr double X_MIN = 0.0, X_MAX = 0.8, DX = 0.02;
    static constexpr double Q_MIN = 1.0, Q_MAX = 9.0, DQ = 0.10;
    static constexpr double T_MIN = 0.0, T_MAX = 3.0, DT = 0.05;
    static constexpr int NX = 40, NQ = 80, NT = 60;
    std::map<std::string, std::map<int, AcceptedMcCell>> cells;
    long long selected_events = 0;
    long long missing_kinematics = 0;
    long long outside_grid = 0;

    AcceptedMcPopulation() {
        cells["ALL"] = {};
        for (const std::string& t : photon_pair_topologies()) cells[t] = {};
    }

    static int index(double x, double q2, double mt) {
        if (!(std::isfinite(x) && std::isfinite(q2) && std::isfinite(mt))) return -1;
        if (x < X_MIN || x >= X_MAX || q2 < Q_MIN || q2 >= Q_MAX || mt < T_MIN || mt >= T_MAX) return -1;
        const int ix = static_cast<int>((x-X_MIN)/DX);
        const int iq = static_cast<int>((q2-Q_MIN)/DQ);
        const int it = static_cast<int>((mt-T_MIN)/DT);
        return (ix*NQ + iq)*NT + it;
    }

    static void decode(int idx, int& ix, int& iq, int& it) {
        it = idx % NT; idx /= NT;
        iq = idx % NQ; idx /= NQ;
        ix = idx;
    }

    void add(const Branches& b, double w) {
        ++selected_events;
        if (!(b.has_x && b.has_Q2 && b.has_t1)) { ++missing_kinematics; return; }
        const double mt = -b.t1;
        const int idx = index(b.x, b.Q2, mt);
        if (idx < 0) { ++outside_grid; return; }
        const std::string topo = photon_pair_topology(b);
        std::vector<std::string> keys = {"ALL"};
        if (!topo.empty()) keys.push_back(topo);
        for (const std::string& key : keys) {
            AcceptedMcCell& c = cells[key][idx];
            ++c.raw_events;
            c.sumw += w; c.sumw2 += w*w;
            c.sumw_x += w*b.x; c.sumw_q2 += w*b.Q2; c.sumw_t += w*mt;
            double proton_ratio = 1.0;
            if (b.has_p1_p && b.has_p1_theta && b.has_p1_phi)
                proton_ratio = eppi0_neupane_proton_efficiency_ratio(b.p1_p,b.p1_theta,b.p1_phi);
            c.sumw_proton_eff_ratio += w*proton_ratio;
            c.sumw_proton_data_weight += w/proton_ratio;
            if (b.has_phi2 && std::isfinite(b.phi2)) {
                c.sumw_cos_phi += w*std::cos(b.phi2);
                c.sumw_cos_2phi += w*std::cos(2.0*b.phi2);
                double ph=std::fmod(b.phi2,2.0*M_PI); if(ph<0.0) ph+=2.0*M_PI;
                int iphi=std::min(11,std::max(0,static_cast<int>(ph/(2.0*M_PI)*12.0)));
                c.sumw_phi_bins[static_cast<std::size_t>(iphi)] += w;
                c.sumw2_phi_bins[static_cast<std::size_t>(iphi)] += w*w;
            }
        }
    }
};

static void write_accepted_mc_population_csv(
        const std::string& path,
        const std::map<std::string, AcceptedMcPopulation>& populations) {
    const std::filesystem::path pp(path);
    if (pp.has_parent_path()) mkdir_p(pp.parent_path().string());
    std::ofstream out(path.c_str());
    if (!out.is_open()) fatal("[eppi0_norm] FATAL: cannot write accepted AAOgen population CSV: " + path);
    out << "period,photon_topology,ix,iq,it,xB_low,xB_high,Q2_low_GeV2,Q2_high_GeV2,minus_t_low_GeV2,minus_t_high_GeV2,raw_events,sum_weight,sum_weight2,xB_weighted_mean,Q2_weighted_mean_GeV2,minus_t_weighted_mean_GeV2,proton_efficiency_ratio_mean,proton_data_weight_mean,cos_phi_weighted_mean,cos_2phi_weighted_mean\n";
    out << std::setprecision(12);
    for (const auto& pkv : populations) {
        const std::string& period = pkv.first;
        const AcceptedMcPopulation& pop = pkv.second;
        for (const auto& tkv : pop.cells) {
            for (const auto& ckv : tkv.second) {
                int ix=0,iq=0,it=0; AcceptedMcPopulation::decode(ckv.first,ix,iq,it);
                const AcceptedMcCell& c=ckv.second;
                if (!(c.sumw>0.0)) continue;
                out << period << ',' << tkv.first << ',' << ix << ',' << iq << ',' << it << ','
                    << AcceptedMcPopulation::X_MIN+ix*AcceptedMcPopulation::DX << ','
                    << AcceptedMcPopulation::X_MIN+(ix+1)*AcceptedMcPopulation::DX << ','
                    << AcceptedMcPopulation::Q_MIN+iq*AcceptedMcPopulation::DQ << ','
                    << AcceptedMcPopulation::Q_MIN+(iq+1)*AcceptedMcPopulation::DQ << ','
                    << AcceptedMcPopulation::T_MIN+it*AcceptedMcPopulation::DT << ','
                    << AcceptedMcPopulation::T_MIN+(it+1)*AcceptedMcPopulation::DT << ','
                    << c.raw_events << ',' << c.sumw << ',' << c.sumw2 << ','
                    << c.sumw_x/c.sumw << ',' << c.sumw_q2/c.sumw << ',' << c.sumw_t/c.sumw << ','
                    << c.sumw_proton_eff_ratio/c.sumw << ','
                    << c.sumw_proton_data_weight/c.sumw << ','
                    << c.sumw_cos_phi/c.sumw << ','
                    << c.sumw_cos_2phi/c.sumw << '\n';
            }
        }
    }
    std::cout << "[eppi0_norm] Wrote accepted AAOgen population grid: " << path << std::endl;
    const std::string phi_path = pp.has_parent_path() ? (pp.parent_path().string() + "/accepted_aao_phi_population.csv") : "accepted_aao_phi_population.csv";
    std::ofstream pout(phi_path.c_str());
    if (!pout.is_open()) fatal("[eppi0_norm] FATAL: cannot write accepted AAOgen phi population CSV: " + phi_path);
    pout << "period,photon_topology,ix,iq,it,phi_bin,phi_low_deg,phi_high_deg,sum_weight,sum_weight2\n";
    pout << std::setprecision(12);
    for (const auto& pkv : populations) for (const auto& tkv : pkv.second.cells) for (const auto& ckv : tkv.second) {
        const AcceptedMcCell& c=ckv.second; int ix=0,iq=0,it=0; AcceptedMcPopulation::decode(ckv.first,ix,iq,it);
        for(int ip=0;ip<12;++ip) if(c.sumw_phi_bins[static_cast<std::size_t>(ip)]>0.0)
            pout << '"' << pkv.first << "\",\"" << tkv.first << "\"," << ix << ',' << iq << ',' << it << ',' << ip << ',' << ip*30.0 << ',' << (ip+1)*30.0 << ',' << c.sumw_phi_bins[static_cast<std::size_t>(ip)] << ',' << c.sumw2_phi_bins[static_cast<std::size_t>(ip)] << '\n';
    }
    std::cout << "[eppi0_norm] Wrote accepted AAOgen phi population: " << phi_path << std::endl;
}

static void fill_eppi0_mc_hists_analysis(const ChannelConfig& cfg,
                                         const PeriodTags& tags,
                                         TTree* tree,
                                         const TopoCutMap& mc_cuts,
                                         double event_norm,
                                         const CurrentResponseModel& current_model,
                                         HistSet& hists,
                                         AcceptedMcPopulation* accepted_population = nullptr) {
    if (!tree) return;
    Branches b; b.bind(tree, true);
    const Long64_t N = tree->GetEntries();
    long long n_pass = 0; double sum_weight = 0.0;
    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);
        if (!passes_event_selection(cfg, tags, mc_cuts, b)) continue;
        bool skip = false;
        const double current_w = event_current_weight(current_model, "ep->eppi0", tags.display, b, false, skip);
        const double w = event_norm * current_w;
        ++n_pass; sum_weight += w; fill_hist_set(hists, b, w);
        if (accepted_population) accepted_population->add(b, w);
    }
    std::cout << "[eppi0_norm] analysis MC " << tags.display
              << " entries=" << (long long)N << " pass=" << n_pass
              << " sum_weight=" << sum_weight << " event_norm=" << event_norm
              << " current_model=event_by_event_regional" << std::endl;
}


struct TopologyCellAccum {
    double sumw = 0.0;
    double sumw2 = 0.0;
    long long raw_events = 0;
};

struct TopologyKinematicGrid {
    // Deliberately coarse.  The purpose is common-support control, not a fine
    // differential measurement.  All three photon topologies must populate a
    // cell before it can enter the controlled comparison.
    static constexpr int NX = 7;
    static constexpr int NQ = 6;
    static constexpr int NT = 5;
    static constexpr int NCELL = NX * NQ * NT;
    std::map<std::string, std::array<TopologyCellAccum, NCELL>> cells;

    TopologyKinematicGrid() {
        for (const std::string& topo : photon_pair_topologies()) cells[topo] = {};
    }

    static int index(double x, double q2, double tabs) {
        if (!(std::isfinite(x) && std::isfinite(q2) && std::isfinite(tabs))) return -1;
        if (x < 0.0 || x >= 0.7 || q2 < 1.0 || q2 >= 7.0 || tabs < 0.0 || tabs >= 1.0) return -1;
        const int ix = std::min(NX - 1, static_cast<int>(x / 0.1));
        const int iq = std::min(NQ - 1, static_cast<int>((q2 - 1.0) / 1.0));
        const int it = std::min(NT - 1, static_cast<int>(tabs / 0.2));
        return (ix * NQ + iq) * NT + it;
    }
};

static void fill_eppi0_photon_topology_grid(const ChannelConfig& cfg,
                                             const PeriodTags& tags,
                                             TTree* tree,
                                             const TopoCutMap& cuts,
                                             const CurrentResponseModel& current_model,
                                             bool is_data,
                                             double event_norm,
                                             TopologyKinematicGrid& grid) {
    if (!tree) return;
    Branches b; b.bind(tree, !is_data);
    if (!(b.has_detector_gamma1 && b.has_detector_gamma2 && b.has_x && b.has_Q2 && b.has_t1)) return;
    const Long64_t N = tree->GetEntries();
    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);
        if (!passes_event_selection(cfg, tags, cuts, b)) continue;
        const std::string topo = photon_pair_topology(b);
        if (topo.empty()) continue;
        const int cell = TopologyKinematicGrid::index(b.x, b.Q2, std::fabs(b.t1));
        if (cell < 0) continue;
        bool skip = false;
        const double cw = event_current_weight(current_model, "ep->eppi0", tags.display, b, is_data, skip);
        if (skip) continue;
        const double w = is_data ? cw : event_norm * cw;
        TopologyCellAccum& a = grid.cells[topo][cell];
        a.sumw += w;
        a.sumw2 += w * w;
        ++a.raw_events;
    }
}

static ControlledTopologyComparison make_controlled_topology_comparison(
        const TopologyKinematicGrid& data,
        const TopologyKinematicGrid& mc,
        int min_raw_events_per_sample) {
    ControlledTopologyComparison out;
    out.min_raw_events_per_sample = min_raw_events_per_sample;
    std::vector<int> support;
    for (int k = 0; k < TopologyKinematicGrid::NCELL; ++k) {
        bool ok = true;
        for (const std::string& topo : photon_pair_topologies()) {
            const auto& d = data.cells.at(topo)[k];
            const auto& m = mc.cells.at(topo)[k];
            if (d.raw_events < min_raw_events_per_sample || m.raw_events < min_raw_events_per_sample ||
                !(d.sumw > 0.0) || !(m.sumw > 0.0)) { ok = false; break; }
        }
        if (ok) support.push_back(k);
    }
    out.common_cells = static_cast<int>(support.size());
    if (support.empty()) return out;

    // One topology-neutral reference population: the combined reconstructed
    // AAOgen yield in each common cell.  The same normalized f_k is then used
    // for FT-FT, FT-FD and FD-FD.  Data never determine these weights.
    double ref_total = 0.0;
    std::vector<double> ref(support.size(), 0.0);
    for (size_t j = 0; j < support.size(); ++j) {
        for (const std::string& topo : photon_pair_topologies()) ref[j] += mc.cells.at(topo)[support[j]].sumw;
        ref_total += ref[j];
    }
    if (!(ref_total > 0.0)) return out;

    for (const std::string& topo : photon_pair_topologies()) {
        ControlledTopologyResult r; r.topology = topo;
        double var = 0.0, d_all = 0.0, d_sup = 0.0, m_all = 0.0, m_sup = 0.0;
        for (int k = 0; k < TopologyKinematicGrid::NCELL; ++k) {
            d_all += data.cells.at(topo)[k].sumw;
            m_all += mc.cells.at(topo)[k].sumw;
        }
        for (size_t j = 0; j < support.size(); ++j) {
            const int k = support[j];
            const auto& d = data.cells.at(topo)[k];
            const auto& m = mc.cells.at(topo)[k];
            const double fk = ref[j] / ref_total;
            const double rk = d.sumw / m.sumw;
            const double rel_d2 = d.sumw2 / (d.sumw * d.sumw);
            const double rel_m2 = m.sumw2 / (m.sumw * m.sumw);
            const double erk = std::fabs(rk) * std::sqrt(std::max(0.0, rel_d2 + rel_m2));
            r.controlled_ratio += fk * rk;
            var += fk * fk * erk * erk;
            d_sup += d.sumw; m_sup += m.sumw;
        }
        r.controlled_ratio_err = std::sqrt(std::max(0.0, var));
        r.data_support_fraction = d_all > 0.0 ? d_sup / d_all : 0.0;
        r.mc_support_fraction = m_all > 0.0 ? m_sup / m_all : 0.0;
        out.topologies[topo] = r;
    }
    const double rtt = out.topologies["FT-FT"].controlled_ratio;
    const double rtf = out.topologies["FT-FD"].controlled_ratio;
    const double rff = out.topologies["FD-FD"].controlled_ratio;
    if (rtt > 0.0 && rff > 0.0) out.closure = rtf * rtf / (rtt * rff);
    return out;
}

static void write_topology_kinematic_grid_csv(const std::string& path,
                                               const std::string& period,
                                               const TopologyKinematicGrid& data,
                                               const TopologyKinematicGrid& mc) {
    const std::filesystem::path pp(path);
    if (pp.has_parent_path()) mkdir_p(pp.parent_path().string());
    std::ofstream out(path.c_str());
    if (!out.is_open()) fatal("[eppi0_norm] FATAL: cannot write topology closure grid: " + path);
    out << "period,photon_topology,ix,iq,it,xB_low,xB_high,Q2_low_GeV2,Q2_high_GeV2,minus_t_low_GeV2,minus_t_high_GeV2,data_raw_events,data_sum_weight,data_sum_weight2,mc_raw_events,mc_sum_weight,mc_sum_weight2,data_over_mc,stat_err\n";
    out << std::setprecision(12);
    for (const std::string& topo : photon_pair_topologies()) {
        for (int ix=0; ix<TopologyKinematicGrid::NX; ++ix) for (int iq=0; iq<TopologyKinematicGrid::NQ; ++iq) for (int it=0; it<TopologyKinematicGrid::NT; ++it) {
            const int k=(ix*TopologyKinematicGrid::NQ+iq)*TopologyKinematicGrid::NT+it;
            const auto& d=data.cells.at(topo)[k]; const auto& m=mc.cells.at(topo)[k];
            if (!(d.sumw>0.0 && m.sumw>0.0)) continue;
            const double r=d.sumw/m.sumw;
            const double rel2=d.sumw2/(d.sumw*d.sumw)+m.sumw2/(m.sumw*m.sumw);
            const double er=std::fabs(r)*std::sqrt(std::max(0.0,rel2));
            out << '"' << period << "\",\"" << topo << "\"," << ix << ',' << iq << ',' << it << ','
                << ix*0.1 << ',' << (ix+1)*0.1 << ',' << 1.0+iq << ',' << 2.0+iq << ',' << it*0.2 << ',' << (it+1)*0.2 << ','
                << d.raw_events << ',' << d.sumw << ',' << d.sumw2 << ',' << m.raw_events << ',' << m.sumw << ',' << m.sumw2 << ',' << r << ',' << er << '\n';
        }
    }
}

static void fill_eppi0_photon_topology_hists(const ChannelConfig& cfg,
                                               const PeriodTags& tags,
                                               TTree* tree,
                                               const TopoCutMap& cuts,
                                               const CurrentResponseModel& current_model,
                                               bool is_data,
                                               double event_norm,
                                               std::map<std::string, HistSet>& out,
                                               std::map<std::string, long long>& event_counts) {
    if (!tree) return;
    Branches b; b.bind(tree, !is_data);
    if (!(b.has_detector_gamma1 && b.has_detector_gamma2)) {
        std::cout << "[eppi0_norm] WARNING: " << tags.display
                  << " tree lacks detector_gamma1/detector_gamma2; photon-pair topology study unavailable for this tree.\n";
        return;
    }
    const Long64_t N = tree->GetEntries();
    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);
        if (!passes_event_selection(cfg, tags, cuts, b)) continue;
        const std::string topo = photon_pair_topology(b);
        if (topo.empty()) continue;
        bool skip = false;
        const double cw = event_current_weight(current_model, "ep->eppi0", tags.display, b, is_data, skip);
        if (skip) continue;
        const double w = is_data ? cw : event_norm * cw;
        fill_hist_set(out.at(topo), b, w);
        ++event_counts[topo];
    }
}

static double hist_integral_and_error(const TH1D* h, double& err) {
    double e2 = 0.0;
    double sum = 0.0;
    for (int b = 1; b <= h->GetNbinsX(); ++b) {
        sum += h->GetBinContent(b);
        e2 += h->GetBinError(b) * h->GetBinError(b);
    }
    err = std::sqrt(std::max(0.0, e2));
    return sum;
}

static PhotonTopologyNormalization make_photon_topology_normalization(
        const std::string& period,
        const std::string& topology,
        const HistSet& data,
        const HistSet& mc,
        long long data_events,
        long long mc_events) {
    PhotonTopologyNormalization out;
    out.topology = topology;
    out.data_events = data_events;
    out.mc_events = mc_events;
    double de = 0.0, me = 0.0;
    const double d = hist_integral_and_error(data.hists.at("x")[0], de);
    const double m = hist_integral_and_error(mc.hists.at("x")[0], me);
    if (d > 0.0 && m > 0.0) {
        out.integrated_ratio = d / m;
        out.integrated_ratio_err = std::fabs(out.integrated_ratio) *
            std::sqrt((de*de)/(d*d) + (me*me)/(m*m));
    }
    for (const std::string& key : {std::string("x"), std::string("Q2"), std::string("minus_t1")}) {
        VarConfig vc;
        for (const VarConfig& v : variable_configs()) if (v.key == key) { vc = v; break; }
        const int rebin = (key == "x") ? 5 : ((key == "Q2") ? 3 : 4);
        TH1D* hd = static_cast<TH1D*>(data.hists.at(key)[0]->Clone(("coarse_d_" + period_dir(period) + "_" + topology + "_" + key).c_str()));
        TH1D* hm = static_cast<TH1D*>(mc.hists.at(key)[0]->Clone(("coarse_m_" + period_dir(period) + "_" + topology + "_" + key).c_str()));
        hd->SetDirectory(nullptr); hm->SetDirectory(nullptr);
        hd->Rebin(rebin); hm->Rebin(rebin);
        std::vector<TH1D*> vd{hd}, vm{hm};
        out.ratio_curves[key] = make_summary_ratio_curve(period + " " + topology, vc, vd, vm);
        delete hd; delete hm;
    }
    return out;
}

static PeriodNormalization run_period_normalization(const std::string& period,
                                                    TTree* data_tree,
                                                    TTree* rec_tree,
                                                    const CSV& csv,
                                                    const std::unordered_map<int, double>& charge_map,
                                                    const TopoCutMap& data_cuts,
                                                    const TopoCutMap& mc_cuts,
                                                    const std::string& output_dir,
                                                    const std::string& normalization_json_path,
                                                    const CurrentResponseModel& current_model,
                                                    AcceptedMcPopulation* accepted_population) {
    const ChannelConfig epi = eppi0_config();
    const PeriodTags parsed = parse_period_from_key(period);

    PeriodTags tags;
    tags.display = period;
    tags.period_label = parsed.period_label;
    tags.period_code = parsed.period_code;

    const double q_raw = data_charge_for_tree(data_tree, charge_map);
    const double q_mc = q_raw * CHARGE_TO_MC_FACTOR;
    const double lint = RGA_LUMINOSITY_FACTOR_PB_INV_PER_MC * q_mc;

    const AaoPeriodInput aao_input = read_aao_period_input(normalization_json_path, period);
    const double n_gen = aao_input.generated_events;
    const double sigma_integrated_pb = aao_input.sigma_mid_microbarn * 1.0e6;
    const double expected_generated_yield = lint * sigma_integrated_pb;
    const double event_norm = expected_generated_yield / n_gen;

    PlotNormInfo norm_info;
    norm_info.total_charge_mc = q_mc;
    norm_info.integrated_luminosity_pb_inv = lint;
    norm_info.n_gen = n_gen;
    norm_info.event_norm = event_norm;

    const std::string period_root = output_dir + "/periods/" + period_dir(period);
    mkdir_p(period_root);

    HistSet ana_data = make_hist_set("ana_data_" + period_dir(period));
    HistSet ana_mc = make_hist_set("ana_mc_" + period_dir(period));

    fill_eppi0_data_hists_analysis(epi,
                                   tags,
                                   data_tree,
                                   data_cuts,
                                   current_model,
                                   ana_data);

    fill_eppi0_mc_hists_analysis(epi,
                                 tags,
                                 rec_tree,
                                 mc_cuts,
                                 event_norm,
                                 current_model,
                                 ana_mc,
                                 accepted_population);

    std::map<std::string, HistSet> photon_topo_data;
    std::map<std::string, HistSet> photon_topo_mc;
    std::map<std::string, long long> photon_topo_data_counts;
    std::map<std::string, long long> photon_topo_mc_counts;
    for (const std::string& topo : photon_pair_topologies()) {
        photon_topo_data.emplace(topo, make_hist_set("photon_topo_data_" + period_dir(period) + "_" + topo));
        photon_topo_mc.emplace(topo, make_hist_set("photon_topo_mc_" + period_dir(period) + "_" + topo));
        photon_topo_data_counts[topo] = 0;
        photon_topo_mc_counts[topo] = 0;
    }
    fill_eppi0_photon_topology_hists(epi, tags, data_tree, data_cuts, current_model,
                                     true, 1.0, photon_topo_data, photon_topo_data_counts);
    fill_eppi0_photon_topology_hists(epi, tags, rec_tree, mc_cuts, current_model,
                                     false, event_norm, photon_topo_mc, photon_topo_mc_counts);
    std::map<std::string, PhotonTopologyNormalization> photon_topology_norms;
    for (const std::string& topo : photon_pair_topologies()) {
        photon_topology_norms[topo] = make_photon_topology_normalization(
            period, topo, photon_topo_data.at(topo), photon_topo_mc.at(topo),
            photon_topo_data_counts[topo], photon_topo_mc_counts[topo]);
    }

    TopologyKinematicGrid topology_grid_data, topology_grid_mc;
    fill_eppi0_photon_topology_grid(epi, tags, data_tree, data_cuts, current_model,
                                    true, 1.0, topology_grid_data);
    fill_eppi0_photon_topology_grid(epi, tags, rec_tree, mc_cuts, current_model,
                                    false, event_norm, topology_grid_mc);
    const ControlledTopologyComparison controlled_nominal =
        make_controlled_topology_comparison(topology_grid_data, topology_grid_mc, 10);
    const ControlledTopologyComparison controlled_strict =
        make_controlled_topology_comparison(topology_grid_data, topology_grid_mc, 20);
    write_topology_kinematic_grid_csv(output_dir + "/photon_topology/" + period_dir(period) + "_kinematic_closure_grid.csv",
                                      period, topology_grid_data, topology_grid_mc);

    std::map<std::string, SummaryRatioCurve> summary_ratio_curves;

    for (const VarConfig& v : variable_configs()) {
        if (v.key == "minus_t1" || v.key == "Q2" || v.key == "x") {
            summary_ratio_curves[v.key] = make_summary_ratio_curve(period,
                                                                    v,
                                                                    ana_data.hists[v.key],
                                                                    ana_mc.hists[v.key]);
        }
    }

    for (const VarConfig& v : variable_configs()) {
        // Kinematic variables are collected into compact overview canvases below.
        // Keep particle-level variables as sector/topology canvases.
        if (v.kind == 3) continue;
        plot_variable(period_root,
                      period,
                      v,
                      ana_data.hists[v.key],
                      ana_mc.hists[v.key],
                      norm_info,
                      nullptr);
    }

    draw_kinematics_overview_canvases(period_root + "/kinematics",
                                      period,
                                      ana_data,
                                      ana_mc);

    std::map<std::string, TH1D*> h_data_fit;
    std::map<std::string, TH1D*> h_mc_fit;

    build_p1_theta_fit_histograms_by_region(ana_data,
                                            ana_mc,
                                            period,
                                            h_data_fit,
                                            h_mc_fit);

    std::map<std::string, RegionNormalization> region_norms;

    for (const std::string& region : normalization_regions()) {
        CubicFit legacy_raw;
        CubicFit fit = fit_p1_theta_ratio_region(period,
                                                 region,
                                                 period_root,
                                                 h_data_fit[region],
                                                 h_mc_fit[region],
                                                 &legacy_raw);

        const double data_int_region = h_data_fit[region]->Integral();
        const double mc_int_region = h_mc_fit[region]->Integral();

        double data_err2_region = 0.0;
        double mc_err2_region = 0.0;

        for (int b = 1; b <= h_data_fit[region]->GetNbinsX(); ++b) {
            data_err2_region += h_data_fit[region]->GetBinError(b) * h_data_fit[region]->GetBinError(b);
            mc_err2_region += h_mc_fit[region]->GetBinError(b) * h_mc_fit[region]->GetBinError(b);
        }

        double ratio_region = 1.0;
        double ratio_err_region = 0.0;

        if (data_int_region > 0.0 && mc_int_region > 0.0) {
            ratio_region = data_int_region / mc_int_region;
            ratio_err_region = std::fabs(ratio_region) * std::sqrt(
                data_err2_region / (data_int_region * data_int_region) +
                mc_err2_region / (mc_int_region * mc_int_region)
            );
        }

        RegionNormalization rn;
        rn.region = region;
        rn.fit = fit;
        rn.legacy_raw_cubic = legacy_raw;
        rn.integrated_ratio = ratio_region;
        rn.integrated_ratio_err = ratio_err_region;

        region_norms[region] = rn;
    }

    // Pass-1 sequential construction: after applying the theta efficiency map
    // to reconstructed AAOgen, fit the remaining DATA/MC discrepancy versus
    // proton momentum. The production MC weight is theta_weight * p_residual.
    std::map<std::string, TH1D*> h_mc_p_after_theta;
    fill_p1_momentum_mc_after_theta(epi, tags, rec_tree, mc_cuts, event_norm,
                                    current_model, ana_data, region_norms, h_mc_p_after_theta);
    auto itd_p = ana_data.hists.find("p1_p");
    if (itd_p == ana_data.hists.end() || itd_p->second.size()!=7)
        fatal("[eppi0_norm] FATAL: p1_p DATA histograms missing for sequential momentum fit.");
    for (int panel=0; panel<7; ++panel) {
        const std::string region=normalization_regions()[panel];
        TH1D* hd=(TH1D*)itd_p->second[panel]->Clone(("h_p_resid_data_"+period_dir(period)+"_"+std::to_string(panel)).c_str());
        hd->SetDirectory(nullptr);
        CubicFit legacy;
        // Same positive log-cubic representation used for theta, now fitted to
        // DATA/(MC already weighted by theta), with momentum-specific ranges,
        // axis labels, filenames, and a post-correction closure plot.
        region_norms[region].momentum_fit = fit_p1_theta_ratio_region(period, region, period_root, hd, h_mc_p_after_theta.at(region), &legacy, true);
        plot_p1_momentum_sequential_closure(period, region, period_root, hd,
                                            h_mc_p_after_theta.at(region), region_norms[region].momentum_fit);
        delete hd;
    }
    for(auto& kv:h_mc_p_after_theta) delete kv.second;

    // Aggregate all six FD proton sectors separately from CD.  This is the
    // meaningful FD-vs-CD comparison; ALL is often CD dominated.
    {
        double dsum = 0.0, msum = 0.0, de2 = 0.0, me2 = 0.0;
        for (int isec = 1; isec <= 6; ++isec) {
            const std::string region = "Sector " + std::to_string(isec);
            TH1D* hd = h_data_fit.at(region);
            TH1D* hm = h_mc_fit.at(region);
            for (int ib = 1; ib <= hd->GetNbinsX(); ++ib) {
                dsum += hd->GetBinContent(ib); msum += hm->GetBinContent(ib);
                de2 += hd->GetBinError(ib)*hd->GetBinError(ib);
                me2 += hm->GetBinError(ib)*hm->GetBinError(ib);
            }
        }
        RegionNormalization fd;
        fd.region = "FD";
        fd.fit.valid = false;
        if (dsum > 0.0 && msum > 0.0) {
            fd.integrated_ratio = dsum / msum;
            fd.integrated_ratio_err = std::fabs(fd.integrated_ratio) *
                std::sqrt(de2/(dsum*dsum) + me2/(msum*msum));
        }
        region_norms["FD"] = fd;
    }

    for (const VarConfig& v : variable_configs()) {
        if (v.key == "p1_theta") {
            std::map<std::string, CubicFit> fits_for_plot;

            for (const std::string& region : normalization_regions()) {
                auto it = region_norms.find(region);
                if (it != region_norms.end()) fits_for_plot[region] = it->second.fit;
            }

            plot_variable(period_root,
                          period,
                          v,
                          ana_data.hists[v.key],
                          ana_mc.hists[v.key],
                          norm_info,
                          &fits_for_plot);
        }
    }

    double data_int = 0.0;
    double mc_int = 0.0;
    double data_err2 = 0.0;
    double mc_err2 = 0.0;

    for (const std::string& region : normalization_regions()) {
        data_int += h_data_fit[region]->Integral();
        mc_int += h_mc_fit[region]->Integral();

        for (int b = 1; b <= h_data_fit[region]->GetNbinsX(); ++b) {
            data_err2 += h_data_fit[region]->GetBinError(b) * h_data_fit[region]->GetBinError(b);
            mc_err2 += h_mc_fit[region]->GetBinError(b) * h_mc_fit[region]->GetBinError(b);
        }
    }

    double ratio = 1.0;
    double ratio_err = 0.0;

    if (data_int > 0.0 && mc_int > 0.0) {
        ratio = data_int / mc_int;
        ratio_err = std::fabs(ratio) * std::sqrt(
            data_err2 / (data_int * data_int) +
            mc_err2 / (mc_int * mc_int)
        );
    }

    std::ofstream dbg((period_root + "/normalization_debug_summary.txt").c_str());

    if (dbg.is_open()) {
        dbg << "period " << period << "\n";
        dbg << "current_correction event_by_event_regional_production_model\n";
        dbg << "current_response_model_json production calibration\n";
        dbg << "krishna_proton_efficiency_applied false\n";
        dbg << "data_charge_nC " << std::setprecision(12) << q_raw << "\n";
        dbg << "charge_to_mc_factor " << std::setprecision(12) << CHARGE_TO_MC_FACTOR << "\n";
        dbg << "integrated_luminosity_pb_inv " << std::setprecision(12) << lint << "\n";
        dbg << "normalization_json_path " << normalization_json_path << "\n";
        dbg << "sigma_min_microbarn " << std::setprecision(12) << aao_input.sigma_min_microbarn << "\n";
        dbg << "sigma_max_microbarn " << std::setprecision(12) << aao_input.sigma_max_microbarn << "\n";
        dbg << "sigma_mid_microbarn " << std::setprecision(12) << aao_input.sigma_mid_microbarn << "\n";
        dbg << "sigma_half_width_microbarn " << std::setprecision(12) << aao_input.sigma_half_width_microbarn << "\n";
        dbg << "sigma_relative_uncertainty_from_range " << std::setprecision(12) << aao_input.sigma_relative_uncertainty_from_range << "\n";
        dbg << "n_gen " << std::setprecision(12) << n_gen << "\n";
        dbg << "expected_generated_yield " << std::setprecision(12) << expected_generated_yield << "\n";
        dbg << "event_norm " << std::setprecision(12) << event_norm << "\n";
        dbg << "analysis_data_integral_p1_theta " << std::setprecision(12) << data_int << "\n";
        dbg << "analysis_mc_integral_p1_theta " << std::setprecision(12) << mc_int << "\n";
        dbg << "analysis_ratio " << std::setprecision(12) << ratio << "\n";
        dbg << "analysis_ratio_stat " << std::setprecision(12) << ratio_err << "\n";
    }

    PeriodNormalization out;
    out.period = period;
    out.integrated_ratio = ratio;
    out.integrated_ratio_err = ratio_err;
    out.regions = region_norms;
    out.summary_ratio_curves = summary_ratio_curves;
    out.photon_topologies = photon_topology_norms;
    out.controlled_nominal = controlled_nominal;
    out.controlled_strict = controlled_strict;

    for (auto& kv : photon_topo_data) delete_hist_set(kv.second);
    for (auto& kv : photon_topo_mc) delete_hist_set(kv.second);

    for (auto& kv : h_data_fit) {
        delete kv.second;
    }

    for (auto& kv : h_mc_fit) {
        delete kv.second;
    }

    delete_hist_set(ana_data);
    delete_hist_set(ana_mc);

    std::cout << "[eppi0_norm] " << period
              << " regional_positive_fits=" << region_norms.size()
              << " integrated_ratio=" << ratio
              << " +/- " << ratio_err
              << " current_model=event_by_event_regional"
              << " sigma_mid_microbarn=" << aao_input.sigma_mid_microbarn
              << " n_gen=" << n_gen
              << " event_norm=" << event_norm
              << std::endl;

    return out;
}

static std::string key_for_period_map(const std::map<std::string, TTree*>& trees,
                                      const std::string& period) {
    for (const auto& kv : trees) {
        PeriodTags tags = parse_period_from_key(kv.first);

        if (tags.display == period) {
            return kv.first;
        }
    }

    return "";
}

static TTree* tree_for_period(const std::map<std::string, TTree*>& trees,
                              const std::string& period,
                              const std::string& label) {
    const std::string key = key_for_period_map(trees, period);

    if (key.empty()) {
        std::ostringstream ss;
        ss << "[eppi0_norm] FATAL: missing " << label << " tree for period " << period;
        fatal(ss.str());
    }

    return trees.at(key);
}

// -----------------------------------------------------------------------------
// Normalized raw yield filling
//
// Sp18 Inb and Sp18 Out are unpolarized-only for downstream normalized
// data yields because they do not have usable helicity-resolved charge.
// -----------------------------------------------------------------------------

struct WeightedCount {
    double sum_w = 0.0;
    double sum_w2 = 0.0;
    double factor_var_sum = 0.0;
};

struct HelCounts {
    WeightedCount unpol;
    WeightedCount pos;
    WeightedCount neg;
};

static inline void add_weighted_count(WeightedCount& c,
                                      double weight,
                                      double current_rel_stat,
                                      double ratio_rel_stat) {
    c.sum_w += weight;
    c.sum_w2 += weight * weight;
    const double rel2 = current_rel_stat * current_rel_stat + ratio_rel_stat * ratio_rel_stat;
    c.factor_var_sum += weight * weight * rel2;
}

static inline WeightedCount sum_weighted_counts(const WeightedCount& a,
                                                const WeightedCount& b,
                                                const WeightedCount& c) {
    WeightedCount out;
    out.sum_w = a.sum_w + b.sum_w + c.sum_w;
    out.sum_w2 = a.sum_w2 + b.sum_w2 + c.sum_w2;
    out.factor_var_sum = a.factor_var_sum + b.factor_var_sum + c.factor_var_sum;
    return out;
}

static inline std::string format_weighted_count_triple(const WeightedCount& c) {
    if (!(std::isfinite(c.sum_w) && c.sum_w >= 0.0) ||
        !(std::isfinite(c.sum_w2) && c.sum_w2 >= 0.0) ||
        !(std::isfinite(c.factor_var_sum) && c.factor_var_sum >= 0.0)) {
        return "";
    }

    // Statistical uncertainty of a weighted event count is sum(w^2).
    // factor_var_sum contains uncertainty from common fitted correction
    // functions; that uncertainty is correlated across events and must be
    // treated as a calibration/systematic uncertainty, not independent
    // event-counting noise.
    const double var = c.sum_w2;
    const double stat = (var > 0.0) ? std::sqrt(var) : 0.0;
    return tuple3(c.sum_w, stat, 0.0);
}

using RowCounts = std::unordered_map<int, HelCounts>;

static void accumulate_normalized_yields_for_tree(const ChannelConfig& cfg,
                                                  const PeriodTags& tags,
                                                  TTree* tree,
                                                  const std::vector<RowBin>& rows,
                                                  const TopoCutMap& data_cuts,
                                                  const CurrentResponseModel& current_model,
                                                  const PeriodNormalization& norm,
                                                  std::unordered_map<std::string, RowCounts>& out) {
    if (!tree) {
        return;
    }

    Branches b;
    b.bind(tree, false);

    if (!b.has_helicity) {
        fatal("[eppi0_norm] FATAL: data tree missing helicity.");
    }

    const Long64_t N = tree->GetEntries();

    for (Long64_t i = 0; i < N; ++i) {
        tree->GetEntry(i);

        if (!passes_event_selection(cfg, tags, data_cuts, b)) {
            continue;
        }

        const std::string topo = topo_dir(b.detector1, b.detector2);

        if (topo.empty()) {
            continue;
        }

        const double theta = b.p1_theta_deg();
        const std::string region = normalization_region_for_event(b);

        if (region.empty()) {
            continue;
        }

        auto it_region = norm.regions.find(region);

        if (it_region == norm.regions.end()) {
            std::ostringstream ss;
            ss << "[eppi0_norm] FATAL: missing normalization region " << region
               << " for period " << norm.period;
            fatal(ss.str());
        }

        const CubicFit& fit = it_region->second.fit;
        const double theta_eval = std::max(fit.x_min, std::min(theta, fit.x_max));
        const double ratio = fit.eval(theta_eval);

        if (!(std::isfinite(ratio) && ratio > 0.0)) {
            continue;
        }

        const double ratio_stat = cubic_eval_stat_diag(fit, theta_eval);
        const double ratio_rel_stat = (ratio_stat > 0.0) ? ratio_stat / ratio : 0.0;

        bool current_skip = false;
        const double current_weight = event_current_weight(
            current_model, cfg.csv_channel, tags.display, b, true, current_skip);
        if (current_skip) continue;
        if (!(std::isfinite(current_weight) && current_weight > 0.0)) continue;

        // Pass-1-style empirical eppi0 correction.  R_pi0 = DATA/MC, so the
        // event is weighted by 1/R_pi0 on top of the production current-response
        // correction.  Krishna/Neupane is deliberately not applied separately.
        const double weight = current_weight / ratio;
        const double current_rel_stat = 0.0; // current calibration uncertainty is propagated separately
        const double phi = b.phi_deg();
        const double tabs = b.t_abs();

        for (int r = 0; r < (int)rows.size(); ++r) {
            if (!row_accepts(rows[r], b.x, b.Q2, tabs, phi)) {
                continue;
            }

            HelCounts& hc = out[topo][r];

            if (b.helicity > 0) {
                add_weighted_count(hc.pos, weight, current_rel_stat, ratio_rel_stat);
            } else if (b.helicity < 0) {
                add_weighted_count(hc.neg, weight, current_rel_stat, ratio_rel_stat);
            } else {
                add_weighted_count(hc.unpol, weight, current_rel_stat, ratio_rel_stat);
            }
        }
    }
}

static void write_normalized_counts_to_csv(CSV& csv,
                                           const ChannelConfig& cfg,
                                           const std::string& period,
                                           const std::unordered_map<std::string, RowCounts>& topo_counts) {
    for (const auto& kt : topo_counts) {
        const std::string topo_label = topo_label_for_csv(kt.first);

        if (topo_label.empty()) {
            continue;
        }

        const int c_unpol = col_strict(csv, normalized_raw_yield_col(cfg, topo_label, period, "unpol"));
        const bool write_helicity_resolved = has_helicity_resolved_data_columns(period);
        const int c_pos = write_helicity_resolved
                          ? col_strict(csv, normalized_raw_yield_col(cfg, topo_label, period, "pos"))
                          : -1;
        const int c_neg = write_helicity_resolved
                          ? col_strict(csv, normalized_raw_yield_col(cfg, topo_label, period, "neg"))
                          : -1;

        for (const auto& kr : kt.second) {
            const int row = kr.first;

            if (row < 0 || row >= (int)csv.rows.size()) {
                fatal("[eppi0_norm] FATAL: row index out of range.");
            }

            const HelCounts& h = kr.second;
            const WeightedCount unpol = sum_weighted_counts(h.pos, h.neg, h.unpol);

            csv.rows[row][c_unpol] = format_weighted_count_triple(unpol);

            if (write_helicity_resolved) {
                csv.rows[row][c_pos] = format_weighted_count_triple(h.pos);
                csv.rows[row][c_neg] = format_weighted_count_triple(h.neg);
            }
        }
    }
}

static const PeriodNormalization& find_norm(const std::vector<PeriodNormalization>& norms,
                                            const std::string& period) {
    for (const auto& n : norms) {
        if (n.period == period) {
            return n;
        }
    }

    std::ostringstream ss;
    ss << "[eppi0_norm] FATAL: missing normalization result for " << period;
    fatal(ss.str());

    return norms.front();
}

static void fill_normalized_yields(CSV& csv,
                                   const std::vector<RowBin>& rows,
                                   const std::map<std::string, TTree*>& dvcsDataTrees,
                                   const std::map<std::string, TTree*>& eppi0DataTrees,
                                   const std::vector<PeriodNormalization>& norms,
                                   const TopoCutMap& data_cuts,
                                   const CurrentResponseModel& current_model,
                                   int max_workers) {
    struct WorkItem {
        ChannelConfig cfg;
        PeriodTags tags;
        TTree* tree = nullptr;
        PeriodNormalization norm;
    };

    std::vector<WorkItem> items;

    const ChannelConfig dvcs = dvcs_config();
    const ChannelConfig epi = eppi0_config();

    auto add_items = [&](const ChannelConfig& cfg, const std::map<std::string, TTree*>& trees) {
        for (const auto& kv : trees) {
            PeriodTags tags = parse_period_from_key(kv.first);

            if (tags.display == "Fa18 Inb Supp") {
                continue;
            }

            WorkItem w;
            w.cfg = cfg;
            w.tags = tags;
            w.tree = kv.second;
            w.norm = find_norm(norms, tags.display);

            items.push_back(w);
        }
    };

    add_items(dvcs, dvcsDataTrees);
    add_items(epi, eppi0DataTrees);

    std::vector<std::unordered_map<std::string, RowCounts>> results(items.size());

    int nth = std::max(1, std::min(5, max_workers));
    nth = std::min(nth, std::max(1, (int)items.size()));

#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic, 1) num_threads(nth)
#endif
    for (int i = 0; i < (int)items.size(); ++i) {
        accumulate_normalized_yields_for_tree(items[i].cfg,
                                              items[i].tags,
                                              items[i].tree,
                                              rows,
                                              data_cuts,
                                              current_model,
                                              items[i].norm,
                                              results[i]);
    }

    for (int i = 0; i < (int)items.size(); ++i) {
        write_normalized_counts_to_csv(csv,
                                       items[i].cfg,
                                       items[i].tags.display,
                                       results[i]);
    }
}

// -----------------------------------------------------------------------------
// Parent summary plots
// -----------------------------------------------------------------------------

static std::string region_short_label(const std::string& region) {
    if (region == "CD") {
        return "CD";
    }

    return region;
}

static int color_for_period_index(int i) {
    static const int colors[5] = {
        kBlack,
        kRed + 1,
        kBlue + 1,
        kGreen + 2,
        kMagenta + 1
    };

    if (i < 0) {
        return kBlack;
    }

    return colors[i % 5];
}

static const PeriodNormalization* find_norm_ptr(const std::vector<PeriodNormalization>& norms,
                                                const std::string& period) {
    for (const PeriodNormalization& n : norms) {
        if (n.period == period) {
            return &n;
        }
    }

    return nullptr;
}

static const RegionNormalization* find_region_norm_ptr(const PeriodNormalization& norm,
                                                       const std::string& region) {
    auto it = norm.regions.find(region);

    if (it == norm.regions.end()) {
        return nullptr;
    }

    return &it->second;
}

static void draw_fit_canvas_frame(TPad* pad,
                                  const std::string& panel_label,
                                  double x_min,
                                  double x_max,
                                  const std::string& title_suffix) {
    pad->cd();
    pad->SetGrid(1, 1);
    pad->SetLeftMargin(0.16);
    pad->SetRightMargin(0.05);
    pad->SetBottomMargin(0.16);
    pad->SetTopMargin(0.09);

    TH1D* frame = (TH1D*)pad->DrawFrame(x_min, RATIO_Y_MIN, x_max, RATIO_Y_MAX);
    frame->SetTitle("");
    frame->GetXaxis()->SetTitle("p_{1} #theta (deg)");
    frame->GetYaxis()->SetTitle("data / MC");
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);
    frame->GetXaxis()->SetTitleSize(0.055);
    frame->GetYaxis()->SetTitleSize(0.055);
    frame->GetXaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetLabelSize(0.045);

    TLine* unity_line = new TLine(x_min, 1.0, x_max, 1.0);
    unity_line->SetLineStyle(2);
    unity_line->SetLineColor(kRed + 1);
    unity_line->SetLineWidth(2);
    unity_line->SetBit(TObject::kCanDelete);
    unity_line->Draw("SAME");

    TLatex latex;
    latex.SetNDC(true);
    latex.SetTextSize(0.052);
    latex.SetTextFont(42);
    latex.DrawLatex(0.20, 0.84, (panel_label + title_suffix).c_str());
}

static void save_all_period_p1_theta_fit_summary(const std::string& output_dir,
                                                 const std::vector<PeriodNormalization>& norms) {
    mkdir_p(output_dir);

    TCanvas c("c_eppi0_p1_theta_fit_summary_all_periods", "", 1800, 900);
    c.Divide(4, 2, 0.001, 0.001);

    std::vector<TF1*> owned_funcs;

    const std::vector<std::string> regions = normalization_regions();

    for (int ipanel = 0; ipanel < 7; ++ipanel) {
        const int pad_index = (ipanel < 3) ? (ipanel + 1) : (ipanel + 2);
        TPad* pad = (TPad*)c.cd(pad_index);

        const std::string& region = regions[ipanel];
        const bool is_cd = (region == "CD");

        const double x_min = is_cd ? 40.0 : 0.0;
        const double x_max = is_cd ? 70.0 : 40.0;

        draw_fit_canvas_frame(pad,
                              region_short_label(region),
                              x_min,
                              x_max,
                              "");

        for (int ip = 0; ip < (int)CSV_PERIOD_ORDER.size(); ++ip) {
            const std::string& period = CSV_PERIOD_ORDER[ip];

            const PeriodNormalization* pn = find_norm_ptr(norms, period);

            if (!pn) {
                continue;
            }

            const RegionNormalization* rn = find_region_norm_ptr(*pn, region);

            if (!rn || !rn->fit.valid) {
                continue;
            }

            const CubicFit& fit = rn->fit;

            if (!(fit.x_max > fit.x_min)) {
                continue;
            }

            TF1* f = new TF1(("f_all_period_" + period_dir(period) + "_" + std::to_string(ipanel)).c_str(),
                             fit.log_space ? "exp([0]+x*([1]+x*([2]+x*[3])))" : "pol3",
                             fit.x_min,
                             fit.x_max);

            for (int k = 0; k < 4; ++k) {
                f->SetParameter(k, fit.a[k]);
            }

            f->SetLineColor(color_for_period_index(ip));
            f->SetLineWidth(3);
            f->Draw("L SAME");

            owned_funcs.push_back(f);
        }
    }

    TPad* info = (TPad*)c.cd(4);
    info->SetLeftMargin(0.05);
    info->SetRightMargin(0.05);
    info->SetTopMargin(0.05);
    info->SetBottomMargin(0.05);
    info->Clear();

    TLatex latex;
    latex.SetNDC(true);
    latex.SetTextFont(42);
    latex.SetTextSize(0.055);
    latex.DrawLatex(0.08, 0.90, "ep #rightarrow ep#pi_{0}");
    latex.DrawLatex(0.08, 0.82, "p_{1} #theta normalization fits");
    latex.DrawLatex(0.08, 0.74, "Pass-2 positive log-cubic fits");
    latex.DrawLatex(0.08, 0.66, "Line ranges: populated data/MC bins only");

    TLegend* legend = new TLegend(0.08, 0.20, 0.88, 0.58);
    legend->SetFillColor(kWhite);
    legend->SetFillStyle(1001);
    legend->SetBorderSize(1);
    legend->SetTextSize(0.045);

    std::vector<TF1*> legend_funcs;

    for (int ip = 0; ip < (int)CSV_PERIOD_ORDER.size(); ++ip) {
        TF1* dummy = new TF1(("f_legend_period_" + std::to_string(ip)).c_str(), "pol0", 0.0, 1.0);
        dummy->SetParameter(0, 1.0);
        dummy->SetLineColor(color_for_period_index(ip));
        dummy->SetLineWidth(3);

        legend_funcs.push_back(dummy);
        legend->AddEntry(dummy, CSV_PERIOD_ORDER[ip].c_str(), "l");
    }

    legend->Draw();

    c.SaveAs((output_dir + "/eppi0_p1_theta_cubic_fits_all_periods.png").c_str());

    for (TF1* f : owned_funcs) {
        delete f;
    }

    for (TF1* f : legend_funcs) {
        delete f;
    }

    delete legend;
}

static bool pass1_quartic_coefficients(const std::string& period,
                                       const std::string& region,
                                       QuarticFit& q) {
    const int region_index = (region == "Sector 1") ? 0 :
                             (region == "Sector 2") ? 1 :
                             (region == "Sector 3") ? 2 :
                             (region == "Sector 4") ? 3 :
                             (region == "Sector 5") ? 4 :
                             (region == "Sector 6") ? 5 :
                             (region == "CD")       ? 6 : -1;

    if (region_index < 0) {
        return false;
    }

    static const double inb[7][5] = {
        { 5.205723e-6, -6.553104e-4,  2.857282e-2, -5.275748e-1,  4.390724 },
        { 1.736551e-5, -1.905288e-3,  7.459240e-2, -1.243871e0,  8.406038 },
        {-3.858605e-6,  4.012865e-4, -1.489836e-2,  2.088062e-1,  8.284200e-2},
        { 8.245591e-6, -8.403340e-4,  2.952225e-2, -4.468835e-1,  3.527616 },
        {-7.027999e-6,  4.804512e-4, -8.624948e-3, -3.522498e-2,  2.414833 },
        {-9.300985e-6,  8.132209e-4, -2.646195e-2,  3.715724e-1, -9.530212e-1},
        { 2.430049e-5, -5.364220e-3,  4.440329e-1, -1.633226e1,  2.258644e2}
    };

    static const double out[7][5] = {
        { 6.193140e-5, -7.809714e-3,  3.609521e-1, -7.247023e0,  5.419993e1},
        {-3.086642e-5,  3.301421e-3, -1.326819e-1,  2.385607e0, -1.532828e1},
        { 1.265237e-5, -2.382045e-3,  1.419987e-1, -3.430274e0,  3.015195e1},
        {-3.351760e-5,  3.303882e-3, -1.176380e-1,  1.776518e0, -8.604291e0},
        { 2.073593e-5, -3.141968e-3,  1.675443e-1, -3.791117e0,  3.185059e1},
        {-1.690791e-4,  1.976225e-2, -8.510287e-1,  1.595090e1, -1.084887e2},
        { 7.497258e-6, -1.734757e-3,  1.505486e-1, -5.804050e0,  8.456443e1}
    };

    const double (*src)[5] = nullptr;

    if (period == "Fa18 Inb") {
        src = inb;
    } else if (period == "Fa18 Out") {
        src = out;
    } else {
        return false;
    }

    q.a[0] = src[region_index][4];
    q.a[1] = src[region_index][3];
    q.a[2] = src[region_index][2];
    q.a[3] = src[region_index][1];
    q.a[4] = src[region_index][0];

    return true;
}

static void save_pass1_pass2_p1_theta_comparison(const std::string& output_dir,
                                                 const std::vector<PeriodNormalization>& norms,
                                                 const std::string& period) {
    mkdir_p(output_dir);

    const PeriodNormalization* pn = find_norm_ptr(norms, period);

    if (!pn) {
        std::cout << "[eppi0_norm] WARNING: skipping pass-1 comparison for missing period "
                  << period << std::endl;
        return;
    }

    TCanvas c(("c_eppi0_p1_theta_pass1_pass2_" + period_dir(period)).c_str(), "", 1800, 900);
    c.Divide(4, 2, 0.001, 0.001);

    std::vector<TF1*> owned_funcs;
    const std::vector<std::string> regions = normalization_regions();

    for (int ipanel = 0; ipanel < 7; ++ipanel) {
        const int pad_index = (ipanel < 3) ? (ipanel + 1) : (ipanel + 2);
        TPad* pad = (TPad*)c.cd(pad_index);

        const std::string& region = regions[ipanel];
        const bool is_cd = (region == "CD");

        const double x_frame_min = is_cd ? 40.0 : 0.0;
        const double x_frame_max = is_cd ? 70.0 : 40.0;

        draw_fit_canvas_frame(pad,
                              region_short_label(region),
                              x_frame_min,
                              x_frame_max,
                              "");

        const RegionNormalization* rn = find_region_norm_ptr(*pn, region);

        if (!rn || !rn->fit.valid) {
            continue;
        }

        const CubicFit& cfit = rn->fit;

        if (!(cfit.x_max > cfit.x_min)) {
            continue;
        }

        TF1* fpass2 = new TF1(("f_pass2_" + period_dir(period) + "_" + std::to_string(ipanel)).c_str(),
                              cfit.log_space ? "exp([0]+x*([1]+x*([2]+x*[3])))" : "pol3",
                              cfit.x_min,
                              cfit.x_max);

        for (int k = 0; k < 4; ++k) {
            fpass2->SetParameter(k, cfit.a[k]);
        }

        fpass2->SetLineColor(kBlue + 1);
        fpass2->SetLineWidth(3);
        fpass2->Draw("L SAME");

        owned_funcs.push_back(fpass2);

        QuarticFit qfit;

        if (pass1_quartic_coefficients(period, region, qfit)) {
            TF1* fpass1 = new TF1(("f_pass1_" + period_dir(period) + "_" + std::to_string(ipanel)).c_str(),
                                  "pol4",
                                  cfit.x_min,
                                  cfit.x_max);

            for (int k = 0; k < 5; ++k) {
                fpass1->SetParameter(k, qfit.a[k]);
            }

            fpass1->SetLineColor(kRed + 1);
            fpass1->SetLineWidth(3);
            fpass1->SetLineStyle(2);
            fpass1->Draw("L SAME");

            owned_funcs.push_back(fpass1);
        }
    }

    TPad* info = (TPad*)c.cd(4);
    info->SetLeftMargin(0.05);
    info->SetRightMargin(0.05);
    info->SetTopMargin(0.05);
    info->SetBottomMargin(0.05);
    info->Clear();

    TLatex latex;
    latex.SetNDC(true);
    latex.SetTextFont(42);
    latex.SetTextSize(0.055);
    latex.DrawLatex(0.08, 0.90, period.c_str());
    latex.DrawLatex(0.08, 0.82, "ep #rightarrow ep#pi_{0}");
    latex.DrawLatex(0.08, 0.74, "p_{1} #theta normalization");
    latex.DrawLatex(0.08, 0.66, "Pass-2 log-cubic vs pass-1 quartic");
    latex.DrawLatex(0.08, 0.58, "Both lines over pass-2 populated range");

    TLegend legend(0.08, 0.30, 0.88, 0.50);
    legend.SetFillColor(kWhite);
    legend.SetFillStyle(1001);
    legend.SetBorderSize(1);
    legend.SetTextSize(0.050);

    TF1 leg_pass2("leg_pass2", "pol0", 0.0, 1.0);
    leg_pass2.SetParameter(0, 1.0);
    leg_pass2.SetLineColor(kBlue + 1);
    leg_pass2.SetLineWidth(3);

    TF1 leg_pass1("leg_pass1", "pol0", 0.0, 1.0);
    leg_pass1.SetParameter(0, 1.0);
    leg_pass1.SetLineColor(kRed + 1);
    leg_pass1.SetLineWidth(3);
    leg_pass1.SetLineStyle(2);

    legend.AddEntry(&leg_pass2, "pass-2 log-cubic", "l");
    legend.AddEntry(&leg_pass1, "pass-1 quartic", "l");
    legend.Draw();

    c.SaveAs((output_dir + "/eppi0_p1_theta_pass1_pass2_" + period_dir(period) + ".png").c_str());

    for (TF1* f : owned_funcs) {
        delete f;
    }
}

static void save_all_period_kinematic_ratio_summary(const std::string& output_dir,
                                                    const std::vector<PeriodNormalization>& norms,
                                                    const std::string& key,
                                                    const std::string& title,
                                                    const std::string& x_title) {
    mkdir_p(output_dir);

    double x_min = 0.0;
    double x_max = 1.0;

    VarConfig frame_var;
    frame_var.key = key;
    frame_var.title = title;
    frame_var.x_title = x_title;
    frame_var.particle = 0;
    frame_var.kind = 3;
    frame_var.n_panels = 1;

    range_for_panel(frame_var, 0, x_min, x_max);

    const double y_min = RATIO_Y_MIN;
    const double y_max = RATIO_Y_MAX;

    TCanvas c(("c_eppi0_summary_ratio_" + key).c_str(), "", 1200, 850);
    c.SetGrid(1, 1);
    c.SetLeftMargin(0.14);
    c.SetRightMargin(0.05);
    c.SetBottomMargin(0.13);
    c.SetTopMargin(0.08);

    TH1D* frame = (TH1D*)gPad->DrawFrame(x_min, y_min, x_max, y_max);
    frame->SetTitle(("ep #rightarrow ep#pi_{0}  all periods  " + title + " ratio").c_str());
    frame->GetXaxis()->SetTitle(x_title.c_str());
    frame->GetYaxis()->SetTitle("data / MC");
    frame->GetXaxis()->CenterTitle(true);
    frame->GetYaxis()->CenterTitle(true);
    frame->GetXaxis()->SetTitleSize(0.050);
    frame->GetYaxis()->SetTitleSize(0.050);
    frame->GetXaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetLabelSize(0.045);
    frame->GetYaxis()->SetTitleOffset(1.25);

    TLine unity_line(x_min, 1.0, x_max, 1.0);
    unity_line.SetLineStyle(2);
    unity_line.SetLineColor(kGray + 2);
    unity_line.SetLineWidth(2);
    unity_line.Draw("SAME");

    std::vector<TGraphErrors*> graphs;

    TLegend legend(0.58, 0.66, 0.90, 0.88);
    legend.SetFillColor(kWhite);
    legend.SetFillStyle(1001);
    legend.SetBorderSize(1);
    legend.SetTextSize(0.035);

    for (int ip = 0; ip < (int)CSV_PERIOD_ORDER.size(); ++ip) {
        const std::string& period = CSV_PERIOD_ORDER[ip];
        const PeriodNormalization* pn = find_norm_ptr(norms, period);

        if (!pn) {
            continue;
        }

        auto it = pn->summary_ratio_curves.find(key);

        if (it == pn->summary_ratio_curves.end()) {
            continue;
        }

        const SummaryRatioCurve& curve = it->second;

        if (curve.x.empty()) {
            continue;
        }

        TGraphErrors* g = new TGraphErrors();

        for (int i = 0; i < (int)curve.x.size(); ++i) {
            g->SetPoint(i, curve.x[i], curve.y[i]);
            g->SetPointError(i, 0.0, curve.ey[i]);
        }

        const int color = color_for_period_index(ip);

        g->SetMarkerStyle(20 + ip);
        g->SetMarkerSize(0.85);
        g->SetMarkerColor(color);
        g->SetLineColor(color);
        g->SetLineWidth(1);
        g->Draw("PE SAME");

        legend.AddEntry(g, period.c_str(), "pe");
        graphs.push_back(g);
    }

    legend.Draw();

    c.SaveAs((output_dir + "/eppi0_summary_ratio_" + key + ".png").c_str());

    for (TGraphErrors* g : graphs) {
        delete g;
    }
}

static void save_all_period_kinematic_ratio_summaries(const std::string& output_dir,
                                                      const std::vector<PeriodNormalization>& norms) {
    if (norms.empty()) {
        return;
    }

    save_all_period_kinematic_ratio_summary(output_dir,
                                            norms,
                                            "minus_t1",
                                            "-t",
                                            "-t (GeV^{2})");

    save_all_period_kinematic_ratio_summary(output_dir,
                                            norms,
                                            "Q2",
                                            "Q^{2}",
                                            "Q^{2} (GeV^{2})");

    save_all_period_kinematic_ratio_summary(output_dir,
                                            norms,
                                            "x",
                                            "x_{B}",
                                            "x_{B}");
}

static void save_parent_fit_summary_plots(const std::string& output_dir,
                                          const std::vector<PeriodNormalization>& norms) {
    if (norms.empty()) {
        return;
    }

    mkdir_p(output_dir);

    save_all_period_p1_theta_fit_summary(output_dir, norms);
    save_all_period_kinematic_ratio_summaries(output_dir, norms);
    save_pass1_pass2_p1_theta_comparison(output_dir, norms, "Fa18 Inb");
    save_pass1_pass2_p1_theta_comparison(output_dir, norms, "Fa18 Out");
}

// -----------------------------------------------------------------------------
// CSV output for normalization fits
// -----------------------------------------------------------------------------

static void write_photon_topology_summary_csv(const std::string& output_dir,
                                              const std::vector<PeriodNormalization>& norms) {
    const std::string dir = output_dir + "/photon_topology";
    mkdir_p(dir);
    const std::string path = dir + "/photon_topology_summary.csv";
    std::ofstream out(path.c_str());
    if (!out.is_open()) fatal("[eppi0_norm] FATAL: could not write photon topology summary: " + path);
    out << "period,comparison,photon_topology,data_events,mc_events,data_over_mc,stat_err,factorization_double_ratio,common_cells,data_support_fraction,mc_support_fraction,min_raw_events_per_sample\n";
    out << std::setprecision(12);
    for (const PeriodNormalization& pn : norms) {
        double rtt = 0.0, rtf = 0.0, rff = 0.0;
        auto a=pn.photon_topologies.find("FT-FT"), b=pn.photon_topologies.find("FT-FD"), c=pn.photon_topologies.find("FD-FD");
        if (a!=pn.photon_topologies.end()) rtt=a->second.integrated_ratio;
        if (b!=pn.photon_topologies.end()) rtf=b->second.integrated_ratio;
        if (c!=pn.photon_topologies.end()) rff=c->second.integrated_ratio;
        const double closure = (rtt>0.0 && rff>0.0) ? (rtf*rtf)/(rtt*rff) : 0.0;
        for (const std::string& topo : photon_pair_topologies()) {
            auto it=pn.photon_topologies.find(topo); if (it==pn.photon_topologies.end()) continue;
            const auto& x=it->second;
            out << '"' << pn.period << "\",raw,\"" << topo << "\"," << x.data_events << "," << x.mc_events
                << "," << x.integrated_ratio << "," << x.integrated_ratio_err << "," << closure
                << ",0,1,1,0\n";
        }
        for (const auto& named : std::vector<std::pair<std::string, const ControlledTopologyComparison*>>{
                 {"controlled_nominal", &pn.controlled_nominal}, {"controlled_strict", &pn.controlled_strict}}) {
            const auto& cc = *named.second;
            for (const std::string& topo : photon_pair_topologies()) {
                auto it = cc.topologies.find(topo); if (it == cc.topologies.end()) continue;
                const auto& r = it->second;
                auto raw = pn.photon_topologies.find(topo);
                const long long nd = raw == pn.photon_topologies.end() ? 0 : raw->second.data_events;
                const long long nm = raw == pn.photon_topologies.end() ? 0 : raw->second.mc_events;
                out << '"' << pn.period << "\"," << named.first << ",\"" << topo << "\"," << nd << "," << nm
                    << "," << r.controlled_ratio << "," << r.controlled_ratio_err << "," << cc.closure
                    << "," << cc.common_cells << "," << r.data_support_fraction << "," << r.mc_support_fraction
                    << "," << cc.min_raw_events_per_sample << "\n";
            }
        }
    }
    std::cout << "[eppi0_norm] Wrote photon-pair topology summary: " << path << std::endl;
}

static void draw_photon_topology_summary_canvases(const std::string& output_dir,
                                                  const std::vector<PeriodNormalization>& norms) {
    const std::string dir = output_dir + "/photon_topology";
    mkdir_p(dir);
    const std::vector<std::string> keys = {"x", "Q2", "minus_t1"};
    const std::vector<std::string> xt = {"x_{B}", "Q^{2} (GeV^{2})", "-t (GeV^{2})"};
    const int cols[3] = {kBlue+1, kRed+1, kGreen+2};
    for (const PeriodNormalization& pn : norms) {
        TCanvas can(("c_photon_topology_"+period_dir(pn.period)).c_str(), "", 1400, 1000);
        can.Divide(2,2,0.002,0.002);
        std::vector<TGraphErrors*> keep;
        can.cd(1); gPad->SetGrid(1,1);
        TH1D* fr=(TH1D*)gPad->DrawFrame(0.0,0.0,3.0,1.4);
        fr->SetTitle((pn.period+" photon-pair topology;topology index;data / MC").c_str());
        fr->GetXaxis()->SetBinLabel(fr->GetXaxis()->FindBin(0.5),"FT-FT");
        fr->GetXaxis()->SetBinLabel(fr->GetXaxis()->FindBin(1.5),"FT-FD");
        fr->GetXaxis()->SetBinLabel(fr->GetXaxis()->FindBin(2.5),"FD-FD");
        TGraphErrors* gi=new TGraphErrors(); keep.push_back(gi); int ip=0;
        for (const std::string& topo:photon_pair_topologies()) { auto it=pn.photon_topologies.find(topo); if(it==pn.photon_topologies.end()) continue; gi->SetPoint(ip,ip+0.5,it->second.integrated_ratio); gi->SetPointError(ip,0,it->second.integrated_ratio_err); ++ip; }
        gi->SetMarkerStyle(20); gi->Draw("PE SAME");
        TLine* l1=new TLine(0,1,3,1); l1->SetLineStyle(2); l1->Draw("SAME");
        TGraphErrors* gc=new TGraphErrors(); keep.push_back(gc); ip=0;
        for (const std::string& topo:photon_pair_topologies()) {
            auto it=pn.controlled_nominal.topologies.find(topo); if(it==pn.controlled_nominal.topologies.end()) continue;
            gc->SetPoint(ip,ip+0.62,it->second.controlled_ratio);
            gc->SetPointError(ip,0,it->second.controlled_ratio_err); ++ip;
        }
        gc->SetMarkerStyle(24); gc->Draw("PE SAME");
        TLegend* ileg=new TLegend(0.58,0.74,0.92,0.90); ileg->SetBorderSize(0); ileg->SetFillStyle(0);
        ileg->AddEntry(gi,"raw","pe"); ileg->AddEntry(gc,"controlled (common x_{B}, Q^{2}, -t)","pe"); ileg->Draw();
        for (int ik=0;ik<3;++ik) {
            can.cd(ik+2); gPad->SetGrid(1,1);
            double xmin=1e99,xmax=-1e99;
            for(const auto& kv:pn.photon_topologies){ auto it=kv.second.ratio_curves.find(keys[ik]); if(it==kv.second.ratio_curves.end()) continue; for(double x:it->second.x){xmin=std::min(xmin,x);xmax=std::max(xmax,x);} }
            if(!(xmax>xmin)){xmin=0;xmax=1;}
            const double dx=0.05*(xmax-xmin);
            TH1D* f=(TH1D*)gPad->DrawFrame(xmin-dx,0.0,xmax+dx,1.4);
            f->SetTitle((pn.period+";"+xt[ik]+";data / MC").c_str());
            TLine* u=new TLine(xmin-dx,1,xmax+dx,1);u->SetLineStyle(2);u->Draw("SAME");
            TLegend* leg=new TLegend(0.68,0.70,0.92,0.90);leg->SetBorderSize(0);leg->SetFillStyle(0);
            int jt=0;
            for(const std::string& topo:photon_pair_topologies()){
                auto pt=pn.photon_topologies.find(topo); if(pt==pn.photon_topologies.end()) continue;
                auto rc=pt->second.ratio_curves.find(keys[ik]); if(rc==pt->second.ratio_curves.end()) continue;
                TGraphErrors* g=new TGraphErrors(); keep.push_back(g);
                for(size_t q=0;q<rc->second.x.size();++q){g->SetPoint(q,rc->second.x[q],rc->second.y[q]);g->SetPointError(q,0,rc->second.ey[q]);}
                g->SetMarkerStyle(20+jt);g->SetMarkerColor(cols[jt]);g->SetLineColor(cols[jt]);g->Draw("PE SAME");leg->AddEntry(g,topo.c_str(),"pe");++jt;
            }
            leg->Draw();
        }
        can.SaveAs((dir+"/"+period_dir(pn.period)+"_photon_topology_overview.png").c_str());
        for(TGraphErrors* g:keep) delete g;
    }
}

static void write_norm_summary_csv(const std::string& path,
                                   const std::vector<PeriodNormalization>& norms) {
    const std::size_t slash = path.find_last_of("/\\");
    if (slash != std::string::npos) {
        mkdir_p(path.substr(0, slash));
    }

    std::ofstream out(path.c_str());
    if (!out.is_open()) {
        fatal("[eppi0_norm] FATAL: could not write summary CSV: " + path);
    }

    out << "period,region,integrated_data_over_mc,integrated_stat_err,"
           "a0,a1,a2,a3,ea0,ea1,ea2,ea3,theta_min_deg,theta_max_deg,fit_valid,fit_model,"
           "p_a0,p_a1,p_a2,p_a3,p_ea0,p_ea1,p_ea2,p_ea3,p_min_GeV,p_max_GeV,p_fit_valid,p_fit_model\n";

    out << std::setprecision(12);
    for (const PeriodNormalization& pn : norms) {
        out << '"' << pn.period << "\",\"ALL\","
            << pn.integrated_ratio << "," << pn.integrated_ratio_err
            << ",,,,,,,,,,,0,none\n";
        auto it_fd = pn.regions.find("FD");
        if (it_fd != pn.regions.end()) {
            out << '"' << pn.period << "\",\"FD\","
                << it_fd->second.integrated_ratio << "," << it_fd->second.integrated_ratio_err
                << ",,,,,,,,,,,0,none\n";
        }
        for (const std::string& region : normalization_regions()) {
            auto it = pn.regions.find(region);
            if (it == pn.regions.end()) continue;
            const RegionNormalization& rn = it->second;
            out << '"' << pn.period << "\",\"" << region << "\"," 
                << rn.integrated_ratio << "," << rn.integrated_ratio_err;
            for (int i = 0; i < 4; ++i) out << "," << rn.fit.a[i];
            for (int i = 0; i < 4; ++i) out << "," << rn.fit.ea[i];
            out << "," << rn.fit.x_min << "," << rn.fit.x_max << ","
                << (rn.fit.valid ? 1 : 0) << "," << (rn.fit.log_space ? "log_cubic" : "cubic");
            for (int i=0;i<4;++i) out << "," << rn.momentum_fit.a[i];
            for (int i=0;i<4;++i) out << "," << rn.momentum_fit.ea[i];
            out << "," << rn.momentum_fit.x_min << "," << rn.momentum_fit.x_max << ","
                << (rn.momentum_fit.valid?1:0) << "," << (rn.momentum_fit.log_space?"log_cubic":"cubic") << "\n";
        }
    }

    std::cout << "[eppi0_norm] Wrote normalization study summary: " << path << std::endl;
}


static double quantile_sorted(const std::vector<double>& v, double q) {
    if (v.empty()) return std::numeric_limits<double>::quiet_NaN();
    const double pos = q * (double)(v.size() - 1);
    const std::size_t lo = (std::size_t)std::floor(pos);
    const std::size_t hi = (std::size_t)std::ceil(pos);
    if (lo == hi) return v[lo];
    const double f = pos - (double)lo;
    return v[lo] * (1.0 - f) + v[hi] * f;
}


static int find_interval_index(const std::vector<std::pair<double,double>>& bins, double x) {
    for (int i = 0; i < (int)bins.size(); ++i) {
        if (in_range(x, bins[i].first, bins[i].second)) return i;
    }
    return -1;
}

static void validate_eppi0_acceptance_shift(
    const std::vector<PeriodNormalization>& norms,
    const std::map<std::string, TTree*>& dvcsRecMcTrees,
    const std::vector<RowBin>& rows,
    const TopoCutMap& mc_cuts,
    const CurrentResponseModel& current_model,
    const std::string& output_dir) {

    const std::string outdir = output_dir + "/production_fit_test";
    mkdir_p(outdir);
    const std::string csv_path = outdir + "/eppi0_predicted_cross_section_shift.csv";
    std::ofstream out(csv_path.c_str());
    if (!out.is_open()) fatal("[eppi0-production-test] FATAL: could not write acceptance-shift CSV: " + csv_path);
    out << "period,row_index,xBmin,xBmax,Q2min,Q2max,t_abs_min,t_abs_max,phimin,phimax,"
           "rec_raw,rec_theta,rec_theta_p,acceptance_theta_over_raw,acceptance_theta_p_over_raw,"
           "sigma_theta_over_raw,sigma_theta_p_over_raw,sigma_theta_p_over_theta\n";
    out << std::setprecision(12);

    // Build the tiny xB/Q2/|t| lookup once.  Only the phi rows are scanned for
    // each selected event, avoiding an O(Nevent * 1445) validation loop.
    std::vector<std::pair<double,double>> xbins, qbins, tbins;
    auto add_unique = [](std::vector<std::pair<double,double>>& v, double lo, double hi) {
        for (const auto& p : v) if (std::abs(p.first-lo)<1e-12 && std::abs(p.second-hi)<1e-12) return;
        v.push_back({lo,hi});
    };
    for (const RowBin& r : rows) if (r.valid) {
        add_unique(xbins,r.xBmin,r.xBmax); add_unique(qbins,r.Q2min,r.Q2max); add_unique(tbins,r.tmin,r.tmax);
    }
    auto sorter=[](const auto& a,const auto& b){return a.first<b.first;};
    std::sort(xbins.begin(),xbins.end(),sorter); std::sort(qbins.begin(),qbins.end(),sorter); std::sort(tbins.begin(),tbins.end(),sorter);
    std::map<int,std::vector<int>> candidates;
    for (int r=0;r<(int)rows.size();++r) if(rows[r].valid){
        int ix=find_interval_index(xbins,0.5*(rows[r].xBmin+rows[r].xBmax));
        int iq=find_interval_index(qbins,0.5*(rows[r].Q2min+rows[r].Q2max));
        int it=find_interval_index(tbins,0.5*(rows[r].tmin+rows[r].tmax));
        if(ix>=0&&iq>=0&&it>=0) candidates[(ix*100+iq)*100+it].push_back(r);
    }

    const ChannelConfig dvcs = dvcs_config();
    struct Sums { double raw=0.0, theta=0.0, full=0.0; long long n=0; };
    std::cout << "\n[eppi0-production-test] Predicting cross-section shift from reconstructed-DVCS-MC acceptance numerators.\n";
    std::cout << "[eppi0-production-test] DATA and generated MC are unchanged; reconstructed MC is compared raw vs theta vs theta*p.\n";

    for (const PeriodNormalization& pn : norms) {
        TTree* tree = tree_for_period(dvcsRecMcTrees, pn.period, "DVCS reconstructed MC");
        PeriodTags tags = parse_period_from_key(pn.period);
        Branches b; b.bind(tree, false);
        std::vector<Sums> sums(rows.size());
        Sums total;
        const Long64_t N=tree->GetEntries();
        for(Long64_t i=0;i<N;++i){
            tree->GetEntry(i);
            if(!passes_event_selection(dvcs,tags,mc_cuts,b)) continue;
            const std::string region=normalization_region_for_event(b);
            auto ir=pn.regions.find(region); if(region.empty()||ir==pn.regions.end()) continue;
            const CubicFit& ft=ir->second.fit; const CubicFit& fp=ir->second.momentum_fit;
            if(!ft.valid||!fp.valid) fatal("[eppi0-production-test] FATAL: invalid sequential fit for "+pn.period+" "+region);
            const double rt=ft.eval(std::max(ft.x_min,std::min(ft.x_max,b.p1_theta_deg())));
            const double rp=fp.eval(std::max(fp.x_min,std::min(fp.x_max,b.p1_p)));
            if(!(std::isfinite(rt)&&rt>0.0&&std::isfinite(rp)&&rp>0.0)) fatal("[eppi0-production-test] FATAL: nonpositive sequential MC efficiency weight.");
            bool skip=false;
            const double cw=event_current_weight(current_model,"ep->epg",tags.display,b,false,skip);
            if(skip||!(std::isfinite(cw)&&cw>0.0)) continue;
            const double wr=cw, wt=cw*rt, wf=cw*rt*rp;
            const double tabs=b.t_abs(), phi=b.phi_deg();
            int ix=find_interval_index(xbins,b.x), iq=find_interval_index(qbins,b.Q2), it=find_interval_index(tbins,tabs);
            if(ix<0||iq<0||it<0) continue;
            auto ic=candidates.find((ix*100+iq)*100+it); if(ic==candidates.end()) continue;
            for(int r:ic->second){
                if(!row_accepts_phi(phi,rows[r].pmin,rows[r].pmax)) continue;
                sums[r].raw+=wr; sums[r].theta+=wt; sums[r].full+=wf; ++sums[r].n;
                total.raw+=wr; total.theta+=wt; total.full+=wf; ++total.n;
                break;
            }
        }
        std::vector<double> sig_theta, sig_full, sig_pstep;
        for(int r=0;r<(int)rows.size();++r){ const Sums& z=sums[r]; if(z.n<=0||z.raw<=0||z.theta<=0||z.full<=0) continue;
            const double at=z.theta/z.raw, af=z.full/z.raw;
            const double st=z.raw/z.theta, sf=z.raw/z.full, sp=z.theta/z.full;
            sig_theta.push_back(st); sig_full.push_back(sf); sig_pstep.push_back(sp);
            const RowBin& rb=rows[r];
            out<<'"'<<pn.period<<"\","<<r<<','<<rb.xBmin<<','<<rb.xBmax<<','<<rb.Q2min<<','<<rb.Q2max<<','<<rb.tmin<<','<<rb.tmax<<','<<rb.pmin<<','<<rb.pmax<<','
               <<z.raw<<','<<z.theta<<','<<z.full<<','<<at<<','<<af<<','<<st<<','<<sf<<','<<sp<<'\n';
        }
        std::sort(sig_theta.begin(),sig_theta.end()); std::sort(sig_full.begin(),sig_full.end()); std::sort(sig_pstep.begin(),sig_pstep.end());
        const double gst=total.raw/total.theta, gsf=total.raw/total.full, gsp=total.theta/total.full;
        std::cout<<"[eppi0-production-test][XS-SHIFT] "<<std::setw(9)<<pn.period
                 <<" selected_rec="<<total.n
                 <<" global sigma(theta)/raw="<<gst
                 <<" sigma(theta*p)/raw="<<gsf
                 <<" p-step="<<gsp
                 <<" | bin median full/raw="<<quantile_sorted(sig_full,0.50)
                 <<" p05="<<quantile_sorted(sig_full,0.05)
                 <<" p95="<<quantile_sorted(sig_full,0.95)
                 <<" | bin median p-step="<<quantile_sorted(sig_pstep,0.50)<<"\n";
    }
    out.close();
    std::cout<<"[eppi0-production-test] Wrote predicted bin-by-bin cross-section shifts: "<<csv_path<<"\n";
}

static void validate_eppi0_production_fits(
    const std::vector<PeriodNormalization>& norms,
    const std::map<std::string, TTree*>& dvcsRecMcTrees,
    const TopoCutMap& mc_cuts,
    const std::string& output_dir) {

    const std::string outdir = output_dir + "/production_fit_test";
    mkdir_p(outdir);
    const std::string csv_path = outdir + "/eppi0_production_fit_validation.csv";
    std::ofstream out(csv_path.c_str());
    if (!out.is_open()) fatal("[eppi0_norm] FATAL: could not write production-fit validation CSV: " + csv_path);
    out << "period,region,theta_min_deg,theta_max_deg,fit_min_ratio,fit_min_theta_deg,fit_max_ratio,"
           "fit_nonpositive,dvcs_selected_region_events,dvcs_clamp_low,dvcs_clamp_high,dvcs_clamp_fraction,"
           "dvcs_min_ratio,dvcs_max_ratio,dvcs_weight_p05,dvcs_weight_median,dvcs_weight_p95,dvcs_weight_max,"
           "dvcs_nonpositive_after_clamp,new_over_old_weight_median,new_over_old_weight_p95\n";
    out << std::setprecision(12);

    const ChannelConfig dvcs = dvcs_config();
    bool any_bad_fit = false;
    bool any_bad_event = false;

    std::cout << "\n[eppi0-production-test] Dense positive-fit scan + selected reconstructed-DVCS-MC event scan\n";
    std::cout << "[eppi0-production-test] Boundary policy: theta is clamped to the fitted interval; "
                 "the sequential production weight is R_theta * R_p on reconstructed DVCS MC; extreme weights are still reported.\n";

    for (const PeriodNormalization& pn : norms) {
        TTree* tree = tree_for_period(dvcsRecMcTrees, pn.period, "DVCS reconstructed MC");
        PeriodTags tags = parse_period_from_key(pn.period);
        Branches b;
        b.bind(tree, false);

        struct EvStats {
            long long n = 0, low = 0, high = 0, nonpos = 0;
            double min_ratio = std::numeric_limits<double>::infinity();
            double max_ratio = -std::numeric_limits<double>::infinity();
            std::vector<double> weights;
            std::vector<double> new_over_old_weight;
        };
        std::map<std::string, EvStats> stats;
        for (const std::string& r : normalization_regions()) stats[r] = EvStats{};

        const Long64_t N = tree->GetEntries();
        for (Long64_t i = 0; i < N; ++i) {
            tree->GetEntry(i);
            if (!passes_event_selection(dvcs, tags, mc_cuts, b)) continue;
            const std::string region = normalization_region_for_event(b);
            if (region.empty()) continue;
            auto ir = pn.regions.find(region);
            if (ir == pn.regions.end() || !ir->second.fit.valid) continue;
            const CubicFit& f = ir->second.fit;
            const double theta = b.p1_theta_deg();
            double x = theta;
            EvStats& st = stats[region];
            ++st.n;
            if (x < f.x_min) { x = f.x_min; ++st.low; }
            if (x > f.x_max) { x = f.x_max; ++st.high; }
            const double ratio = f.eval(x);
            const CubicFit& fp = ir->second.momentum_fit;
            const double p_eval = std::max(fp.x_min, std::min(fp.x_max, b.p1_p));
            const double pratio = fp.eval(p_eval);
            if (!(std::isfinite(ratio) && ratio > 0.0 && std::isfinite(pratio) && pratio > 0.0)) {
                ++st.nonpos;
                any_bad_event = true;
                continue;
            }
            st.min_ratio = std::min(st.min_ratio, ratio);
            st.max_ratio = std::max(st.max_ratio, ratio);
            const double wtheta = ratio;
            const double wnew = ratio * pratio;
            st.weights.push_back(wnew);
            st.new_over_old_weight.push_back(wnew / wtheta);
        }

        for (const std::string& region : normalization_regions()) {
            auto ir = pn.regions.find(region);
            if (ir == pn.regions.end()) continue;
            const CubicFit& f = ir->second.fit;
            double fit_min = std::numeric_limits<double>::infinity();
            double fit_max = -std::numeric_limits<double>::infinity();
            double fit_min_x = f.x_min;
            bool nonpos = false;
            const int NSCAN = 10000;
            for (int j = 0; j <= NSCAN; ++j) {
                const double x = f.x_min + (f.x_max - f.x_min) * (double)j / (double)NSCAN;
                const double y = f.eval(x);
                if (!std::isfinite(y) || y <= 0.0) nonpos = true;
                if (std::isfinite(y) && y < fit_min) { fit_min = y; fit_min_x = x; }
                if (std::isfinite(y) && y > fit_max) fit_max = y;
            }
            if (nonpos) any_bad_fit = true;

            EvStats& st = stats[region];
            std::sort(st.weights.begin(), st.weights.end());
            std::sort(st.new_over_old_weight.begin(), st.new_over_old_weight.end());
            const double clamp_frac = st.n > 0 ? (double)(st.low + st.high) / (double)st.n : 0.0;
            const double nan = std::numeric_limits<double>::quiet_NaN();
            const double emin = std::isfinite(st.min_ratio) ? st.min_ratio : nan;
            const double emax = std::isfinite(st.max_ratio) ? st.max_ratio : nan;
            const double w05 = quantile_sorted(st.weights, 0.05);
            const double w50 = quantile_sorted(st.weights, 0.50);
            const double w95 = quantile_sorted(st.weights, 0.95);
            const double wmax = st.weights.empty() ? nan : st.weights.back();
            const double rel50 = quantile_sorted(st.new_over_old_weight, 0.50);
            const double rel95 = quantile_sorted(st.new_over_old_weight, 0.95);

            std::cout << "[eppi0-production-test] " << std::setw(9) << pn.period
                      << "  " << std::setw(8) << region
                      << " fit=[" << f.x_min << "," << f.x_max << "]"
                      << " minR=" << fit_min << "@" << fit_min_x
                      << " maxR=" << fit_max
                      << " bad_fit=" << (nonpos ? "YES" : "no")
                      << " | DVCS N=" << st.n
                      << " clamp=" << (st.low + st.high) << " (" << 100.0*clamp_frac << "%)"
                      << " bad_events=" << st.nonpos
                      << " w50=" << w50 << " w95=" << w95 << " wmax=" << wmax
                      << " new/old_w50=" << rel50 << " new/old_w95=" << rel95
                      << "\n";

            out << '"' << pn.period << "\",\"" << region << "\"," << f.x_min << ',' << f.x_max << ','
                << fit_min << ',' << fit_min_x << ',' << fit_max << ',' << (nonpos ? 1 : 0) << ','
                << st.n << ',' << st.low << ',' << st.high << ',' << clamp_frac << ','
                << emin << ',' << emax << ',' << w05 << ',' << w50 << ',' << w95 << ',' << wmax << ','
                << st.nonpos << ',' << rel50 << ',' << rel95 << '\n';
        }
    }

    out.close();
    std::cout << "[eppi0-production-test] Wrote: " << csv_path << "\n";
    if (any_bad_fit || any_bad_event) {
        std::cout << "[eppi0-production-test] RESULT: FAIL -- at least one regional cubic is non-positive "
                     "inside its fitted interval. Do NOT run full production yet.\n";
    } else {
        std::cout << "[eppi0-production-test] RESULT: PASS -- all regional production fits are positive over their "
                     "fitted intervals and all selected DVCS correction weights are finite/positive.\n";
    }
}

static void write_norms_to_csv(CSV& csv, const std::vector<PeriodNormalization>& norms) {
    for (const std::string& period : CSV_PERIOD_ORDER) {
        const PeriodNormalization& n = find_norm(norms, period);

        for (const std::string& region : normalization_regions()) {
            auto it_region = n.regions.find(region);

            if (it_region == n.regions.end()) {
                std::ostringstream ss;
                ss << "[eppi0_norm] FATAL: missing " << region << " normalization for " << period;
                fatal(ss.str());
            }

            const int c_fit = col_strict(csv, norm_fit_col(period, region));
            const int c_factor = col_strict(csv, norm_factor_col(period, region));

            const std::string fit_cell = tuple4(it_region->second.fit);
            const std::string factor_cell = tuple2(it_region->second.integrated_ratio,
                                                   it_region->second.integrated_ratio_err);

            for (auto& row : csv.rows) {
                row[c_fit] = fit_cell;
                row[c_factor] = factor_cell;
            }
        }
    }
}

static std::vector<PeriodNormalization> unity_norms() {
    std::vector<PeriodNormalization> norms;

    for (const std::string& period : CSV_PERIOD_ORDER) {
        PeriodNormalization n;
        n.period = period;

        for (const std::string& region : normalization_regions()) {
            RegionNormalization rn;
            rn.region = region;
            rn.fit.valid = true;
            rn.fit.a[0] = 1.0;
            rn.fit.x_min = (region == "CD") ? 40.0 : 0.0;
            rn.fit.x_max = (region == "CD") ? 70.0 : 40.0;
            rn.integrated_ratio = 1.0;
            rn.integrated_ratio_err = 0.0;

            n.regions[region] = rn;
        }

        norms.push_back(n);
    }

    return norms;
}

} // namespace

bool update_eppi0_normalization_csv(
    const std::string& csv_path,
    const std::map<std::string, TTree*>& dvcsDataTrees,
    const std::map<std::string, TTree*>& eppi0DataTrees,
    const std::map<std::string, TTree*>& eppi0RecMcTrees,
    const std::map<std::string, TTree*>& dvcsRecMcTrees,
    const Eppi0NormalizationOptions& options) {
    try {
        ROOT::EnableThreadSafety();
        TH1::AddDirectory(kFALSE);
        gStyle->SetOptStat(0);

        CSV csv;
        load_csv_strict(csv_path, csv);

        const std::vector<RowBin> rows = load_rows(csv);

        const TopoCutMap data_cuts = load_sigma_cuts(options.combined_cuts_json, "data");
        const TopoCutMap mc_cuts = load_sigma_cuts(options.combined_cuts_json, "mc");

        std::vector<PeriodNormalization> norms;
        const CurrentResponseModel current_model =
            load_current_response_model(options.current_response_model_json);

        if (options.clean_output_dir && !options.override_to_unity) {
            std::error_code ec;
            std::filesystem::remove_all(options.output_dir, ec);
            if (ec) fatal("[eppi0_norm] FATAL: failed to clean output directory '" + options.output_dir + "': " + ec.message());
            std::cout << "[eppi0_norm] Cleared stale diagnostic output: " << options.output_dir << std::endl;
        }

        if (options.override_to_unity) {
            std::cout << "[eppi0_norm] Override enabled: using unity eppi0 normalization polynomial."
                      << std::endl;

            norms = unity_norms();
        } else {
            mkdir_p(options.output_dir);
            std::cout << "[eppi0_norm] Loaded production current-response model: "
                      << options.current_response_model_json << std::endl;

            const std::unordered_map<int, double> charge_map =
                read_charge_csv(options.charge_csv_path);

            std::map<std::string, AcceptedMcPopulation> accepted_mc_populations;

            for (const std::string& period : WORK_PERIOD_ORDER) {
                TTree* data_tree = tree_for_period(eppi0DataTrees, period, "eppi0 data");
                TTree* rec_tree = tree_for_period(eppi0RecMcTrees, period, "eppi0 reconstructed MC");

                PeriodNormalization n = run_period_normalization(period,
                                                                 data_tree,
                                                                 rec_tree,
                                                                 csv,
                                                                 charge_map,
                                                                 data_cuts,
                                                                 mc_cuts,
                                                                 options.output_dir,
                                                                 options.normalization_json_path,
                                                                 current_model,
                                                                 options.write_accepted_mc_population ? &accepted_mc_populations[period] : nullptr);

                norms.push_back(n);
            }

            if (options.write_accepted_mc_population) {
                for (const auto& kv : accepted_mc_populations) {
                    std::cout << "[eppi0_norm] accepted AAOgen population " << kv.first
                              << " selected=" << kv.second.selected_events
                              << " missing_kinematics=" << kv.second.missing_kinematics
                              << " outside_grid=" << kv.second.outside_grid << std::endl;
                }
                write_accepted_mc_population_csv(options.accepted_mc_population_csv_path,
                                                 accepted_mc_populations);
            }
        }

        if (!options.override_to_unity) {
            const std::string summary_dir = options.output_dir + "/summary";
            mkdir_p(summary_dir);
            save_parent_fit_summary_plots(summary_dir, norms);
            write_photon_topology_summary_csv(options.output_dir, norms);
            draw_photon_topology_summary_canvases(options.output_dir, norms);
        }

        write_norms_to_csv(csv, norms);

        if (options.write_summary_csv && !options.override_to_unity) {
            write_norm_summary_csv(options.summary_csv_path, norms);
        }

        if (options.validate_production_fits && !options.override_to_unity) {
            validate_eppi0_production_fits(norms, dvcsRecMcTrees, mc_cuts, options.output_dir);
            validate_eppi0_acceptance_shift(norms, dvcsRecMcTrees, rows, mc_cuts, current_model, options.output_dir);
        }

        if (options.write_normalized_yields) {
            fill_normalized_yields(csv,
                                   rows,
                                   dvcsDataTrees,
                                   eppi0DataTrees,
                                   norms,
                                   data_cuts,
                                   current_model,
                                   options.max_workers);
        } else {
            std::cout << "[eppi0_norm] Diagnostic mode: production normalized raw yields were NOT overwritten.\n";
        }

        write_csv_atomic(csv_path, csv);

        std::cout << "[eppi0_norm] Updated eppi0 normalization diagnostic columns in: "
                  << csv_path << std::endl;

        return true;
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return false;
    }
}