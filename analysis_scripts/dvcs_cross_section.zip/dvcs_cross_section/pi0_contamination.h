#ifndef PI0_CONTAMINATION_H
#define PI0_CONTAMINATION_H

#include <map>
#include <string>

class TTree;

struct Pi0ContaminationOptions {
    // The exclusivity-variable overlays are diagnostic-only: they do not feed
    // the contamination ratios or any downstream physics quantity. Keep them
    // for the nominal production pass, but allow internal systematic passes to
    // skip the otherwise expensive ROOT-tree scans.
    bool make_exclusivity_diagnostics = true;

    // Current correction convention for N_mis = ep->eppi0->epg MC.
    //
    // true  -> default: correct the misidentified-background MC with the
    //          ep->epg MC current-efficiency factor because the reconstructed
    //          final state being counted is epgamma.
    // false -> previous behavior: use the ep->eppi0 MC current-efficiency
    //          factor for the misidentified-background MC.
    bool use_epg_mc_current_factor_for_eppi0_bkg = true;
};

// Computes the pi0 contamination ratio using only quantities already stored in
// dvcs_pass2_analysis.csv. The TTree maps are used only by the optional
// exclusivity-variable validation diagnostics; they do not enter the
// contamination ratio itself.
//
// For each CSV row and period:
//
//   c = N_mis * N_pi0_data / (N_pi0_rec_mc * N_dvcs_data)
//
// where the terms are read from existing CSV columns:
//
//   N_dvcs_data   = sum_topo normalized raw yield, ep->epg,        topo, exp, period, unpol
//   N_pi0_data    = sum_topo normalized raw yield, ep->eppi0,      topo, exp, period, unpol
//   N_pi0_rec_mc  = sum_topo reconstructed current corrected yield, ep->eppi0,      topo, mc, period
//   N_mis         = sum_topo reconstructed yield, ep->eppi0->epg, topo, mc, period
//                   divided by either the ep->epg MC current-efficiency factor
//                   (default) or the ep->eppi0 MC current-efficiency factor
//                   (legacy option).
//
// The output is written to:
//
//   contamination ratio, <period>
//
// as a triplet:
//
//   (value,stat,sys)
//
// with sys currently set to 0.
bool compute_pi0_contamination_overall(
    const std::map<std::string, TTree*> &dvcsDataTrees,
    const std::map<std::string, TTree*> &eppi0DataTrees,
    const std::map<std::string, TTree*> &eppi0RecMcTrees,
    const std::map<std::string, TTree*> &eppi0BkgTrees,
    const std::string &combined_cuts_json,
    const std::string &csv_main,
    const std::string &output_root_dir,
    int max_workers,
    const Pi0ContaminationOptions& options = Pi0ContaminationOptions());

#endif // PI0_CONTAMINATION_H
