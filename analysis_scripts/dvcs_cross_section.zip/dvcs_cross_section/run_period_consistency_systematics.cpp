#include "run_period_consistency_systematics.h"

#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TLegend.h>
#include <TLatex.h>
#include <TLine.h>
#include <TROOT.h>
#include <TStyle.h>
#include <TAxis.h>
#include <TH1D.h>
#include <TPad.h>

#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace fs = std::filesystem;

namespace {

static constexpr double kScaleThetaMinDeg = 8.0;
static constexpr double kScaleThetaMaxDeg = 25.0;

struct CsvTable {
    std::vector<std::string> header;
    std::vector<std::vector<std::string> > rows;
    std::unordered_map<std::string, int> index;
};

struct TupleValue {
    bool ok = false;
    double value = 0.0;
    double stat = 0.0;
};

struct PeriodInput {
    std::string period;
    std::string source_period;
    std::string column;
};

struct ConsistencyCase {
    std::string label;
    std::string file_tag;
    std::string avg_label;
    std::string helicity;
    std::vector<PeriodInput> inputs;
};

struct PointPack {
    std::vector<double> x;
    std::vector<double> y;
    std::vector<double> ey;
};

struct VariableConfig {
    std::string key;
    std::string column_prefix;
    std::string title;
};

struct PeriodRatioAccumulator {
    double sum_w = 0.0;
    double sum_wr = 0.0;
    int n = 0;
};

struct PolynomialScale {
    bool ok = false;
    std::string period;
    int order = -1;
    std::vector<double> params;
};

static std::string trim(const std::string& s) {
    const size_t first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return "";
    }

    const size_t last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, last - first + 1);
}

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    cur.reserve(line.size());

    bool in_quotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];

        if (c == '"') {
            if (in_quotes && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }

    out.push_back(cur);
    return out;
}

static std::unordered_map<std::string, int>
build_header_index(const std::vector<std::string>& header) {
    std::unordered_map<std::string, int> idx;

    for (int i = 0; i < (int)header.size(); ++i) {
        idx[trim(header[(size_t)i])] = i;
    }

    return idx;
}

static void assert_no_duplicate_columns(const std::vector<std::string>& header) {
    std::set<std::string> seen;
    std::set<std::string> duplicates;

    for (const auto& raw_name : header) {
        const std::string name = trim(raw_name);

        if (!seen.insert(name).second) {
            duplicates.insert(name);
        }
    }

    if (!duplicates.empty()) {
        std::ostringstream msg;
        msg << "CSV header contains duplicate columns:";

        for (const auto& name : duplicates) {
            msg << "\n  - " << name;
        }

        throw std::runtime_error(msg.str());
    }
}

static CsvTable read_csv_or_throw(const std::string& path) {
    std::ifstream fin(path);

    if (!fin.is_open()) {
        throw std::runtime_error("Could not open CSV: " + path);
    }

    CsvTable table;

    std::string line;
    if (!std::getline(fin, line)) {
        throw std::runtime_error("CSV is empty: " + path);
    }

    table.header = split_csv_line(line);
    assert_no_duplicate_columns(table.header);
    table.index = build_header_index(table.header);

    while (std::getline(fin, line)) {
        if (line.empty()) {
            continue;
        }

        std::vector<std::string> row = split_csv_line(line);

        if (row.size() < table.header.size()) {
            row.resize(table.header.size());
        }

        if (row.size() != table.header.size()) {
            std::ostringstream msg;
            msg << "CSV row has " << row.size()
                << " columns, but header has " << table.header.size()
                << " columns. File: " << path;
            throw std::runtime_error(msg.str());
        }

        table.rows.push_back(std::move(row));
    }

    return table;
}

static void require_columns(const CsvTable& table,
                            const std::vector<std::string>& required,
                            const std::string& context) {
    std::vector<std::string> missing;

    for (const auto& name : required) {
        if (table.index.find(name) == table.index.end()) {
            missing.push_back(name);
        }
    }

    if (!missing.empty()) {
        std::ostringstream msg;
        msg << "Missing required columns for " << context << ":";

        for (const auto& name : missing) {
            msg << "\n  - " << name;
        }

        throw std::runtime_error(msg.str());
    }
}

static bool parse_double(const std::string& raw,
                         double& out) {
    const std::string s = trim(raw);

    if (s.empty()) {
        return false;
    }

    char* end = nullptr;
    out = std::strtod(s.c_str(), &end);

    if (end == s.c_str()) {
        return false;
    }

    while (end && *end != '\0') {
        if (!std::isspace((unsigned char)(*end))) {
            return false;
        }

        ++end;
    }

    return std::isfinite(out);
}

static bool parse_int(const std::string& raw,
                      int& out) {
    const std::string s = trim(raw);

    if (s.empty()) {
        return false;
    }

    char* end = nullptr;
    const long value = std::strtol(s.c_str(), &end, 10);

    if (end == s.c_str()) {
        return false;
    }

    while (end && *end != '\0') {
        if (!std::isspace((unsigned char)(*end))) {
            return false;
        }

        ++end;
    }

    out = (int)value;
    return true;
}

static bool parse_bool_string(const std::string& raw) {
    std::string s = trim(raw);

    for (char& c : s) {
        c = (char)std::tolower((unsigned char)c);
    }

    return s == "true" || s == "1" || s == "yes";
}

static bool parse_numeric_or_tuple_first(const std::string& raw,
                                         double& out) {
    if (parse_double(raw, out)) {
        return true;
    }

    std::string s = trim(raw);

    if (s.empty()) {
        return false;
    }

    if (s.front() == '(' && s.back() == ')') {
        s = trim(s.substr(1, s.size() - 2));
    }

    const std::vector<std::string> fields = split_csv_line(s);

    if (fields.empty()) {
        return false;
    }

    return parse_double(fields[0], out);
}

static TupleValue parse_tuple_value(const std::string& raw) {
    TupleValue out;
    std::string s = trim(raw);

    if (s.empty()) {
        return out;
    }

    if (s.front() == '(' && s.back() == ')') {
        s = trim(s.substr(1, s.size() - 2));
    }

    const std::vector<std::string> fields = split_csv_line(s);

    if (fields.size() < 2U) {
        return out;
    }

    double value = 0.0;
    double stat = 0.0;

    if (!parse_double(fields[0], value)) {
        return out;
    }

    if (!parse_double(fields[1], stat)) {
        return out;
    }

    if (!std::isfinite(value) || !std::isfinite(stat) || stat <= 0.0) {
        return out;
    }

    out.ok = true;
    out.value = value;
    out.stat = stat;
    return out;
}

static std::string get_string_field(const CsvTable& table,
                                    const std::vector<std::string>& row,
                                    const std::string& column) {
    const auto it = table.index.find(column);

    if (it == table.index.end()) {
        throw std::runtime_error("Missing required string column: " + column);
    }

    return trim(row[(size_t)it->second]);
}

static double get_numeric_or_nan(const CsvTable& table,
                                 const std::vector<std::string>& row,
                                 const std::string& column) {
    const auto it = table.index.find(column);

    if (it == table.index.end()) {
        throw std::runtime_error("Missing required numeric column: " + column);
    }

    double value = 0.0;

    if (!parse_numeric_or_tuple_first(row[(size_t)it->second], value)) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    return value;
}

static TupleValue get_tuple(const CsvTable& table,
                            const std::vector<std::string>& row,
                            const std::string& column) {
    const auto it = table.index.find(column);

    if (it == table.index.end()) {
        throw std::runtime_error("Missing required tuple column: " + column);
    }

    return parse_tuple_value(row[(size_t)it->second]);
}

static std::string cross_section_column(const std::string& period,
                                        const std::string& helicity) {
    return "normed cross sections, ep->epg, exp, " + period + ", " + helicity;
}

static std::string avg_column(const std::string& variable_prefix,
                              const std::string& avg_label) {
    return variable_prefix + ", " + avg_label;
}

static PeriodInput single_input(const std::string& period,
                                const std::string& helicity) {
    PeriodInput out;
    out.period = period;
    out.source_period = period;
    out.column = cross_section_column(period, helicity);
    return out;
}

static std::vector<std::string> base_periods() {
    return {
        "Fa18 Inb",
        "Fa18 Out",
        "Sp18 Inb",
        "Sp18 Out"
    };
}

static std::vector<ConsistencyCase> consistency_cases() {
    return {
        {
            "10.6 GeV unpol",
            "10p6_GeV_unpol",
            "10.6 GeV",
            "unpol",
            {
                single_input("Fa18 Inb", "unpol"),
                single_input("Fa18 Out", "unpol"),
                single_input("Sp18 Inb", "unpol"),
                single_input("Sp18 Out", "unpol")
            }
        },
        {
            "Fa18 unpol",
            "Fa18_unpol",
            "Fa18",
            "unpol",
            {
                single_input("Fa18 Inb", "unpol"),
                single_input("Fa18 Out", "unpol")
            }
        },
        {
            "Fa18 pos",
            "Fa18_pos",
            "Fa18",
            "pos",
            {
                single_input("Fa18 Inb", "pos"),
                single_input("Fa18 Out", "pos")
            }
        },
        {
            "Fa18 neg",
            "Fa18_neg",
            "Fa18",
            "neg",
            {
                single_input("Fa18 Inb", "neg"),
                single_input("Fa18 Out", "neg")
            }
        },
        {
            "Sp18 unpol",
            "Sp18_unpol",
            "Sp18",
            "unpol",
            {
                single_input("Sp18 Inb", "unpol"),
                single_input("Sp18 Out", "unpol")
            }
        }
    };
}

static std::vector<VariableConfig> variable_configs() {
    return {
        {"xB",      "xBavg",     "x_{B}"},
        {"Q2",      "Q2avg",     "Q^{2} (GeV^{2})"},
        {"t",       "t_abs_avg", "-t (GeV^{2})"},
        {"phi",     "phiavg",    "#phi (deg)"},
        {"e_theta", "e_theta",   "#theta_{e} (deg)"},
        {"p_theta", "p_theta",   "#theta_{p} (deg)"},
        {"g_theta", "g_theta",   "#theta_{#gamma} (deg)"}
    };
}

static std::vector<VariableConfig> physics_variable_configs() {
    return {
        {"xB",  "xBavg",     "x_{B}"},
        {"Q2",  "Q2avg",     "Q^{2} (GeV^{2})"},
        {"t",   "t_abs_avg", "-t (GeV^{2})"},
        {"phi", "phiavg",    "#phi (deg)"}
    };
}

static std::vector<VariableConfig> angle_variable_configs() {
    return {
        {"e_theta", "e_theta", "#theta_{e} (deg)"},
        {"p_theta", "p_theta", "#theta_{p} (deg)"},
        {"g_theta", "g_theta", "#theta_{#gamma} (deg)"}
    };
}

static void validate_schema(const CsvTable& table,
                            const std::vector<ConsistencyCase>& cases,
                            const std::vector<VariableConfig>& vars) {
    std::vector<std::string> required;

    for (const auto& c : cases) {
        for (const auto& input : c.inputs) {
            required.push_back(input.column);
        }

        for (const auto& var : vars) {
            required.push_back(avg_column(var.column_prefix, c.avg_label));
        }
    }

    required.push_back(avg_column("e_theta", "10.6 GeV"));

    require_columns(table, required, "run-period consistency systematics");
}

static bool compute_weighted_mean_skip_invalid(const std::vector<TupleValue>& values,
                                               double& mean,
                                               double& mean_stat) {
    double sum_w = 0.0;
    double sum_wx = 0.0;

    for (const auto& v : values) {
        if (!v.ok || v.stat <= 0.0 || !std::isfinite(v.value)) {
            continue;
        }

        const double w = 1.0 / (v.stat * v.stat);
        sum_w += w;
        sum_wx += w * v.value;
    }

    if (sum_w <= 0.0) {
        return false;
    }

    mean = sum_wx / sum_w;
    mean_stat = 1.0 / std::sqrt(sum_w);

    return std::isfinite(mean) && std::isfinite(mean_stat) && mean_stat > 0.0;
}

static bool compute_leave_one_out_mean(const std::vector<TupleValue>& values,
                                       size_t leave_out_index,
                                       double& mean,
                                       double& mean_stat) {
    double sum_w = 0.0;
    double sum_wx = 0.0;

    for (size_t i = 0; i < values.size(); ++i) {
        if (i == leave_out_index) {
            continue;
        }

        const TupleValue& v = values[i];

        if (!v.ok || v.stat <= 0.0 || !std::isfinite(v.value)) {
            continue;
        }

        const double w = 1.0 / (v.stat * v.stat);
        sum_w += w;
        sum_wx += w * v.value;
    }

    if (sum_w <= 0.0) {
        return false;
    }

    mean = sum_wx / sum_w;
    mean_stat = 1.0 / std::sqrt(sum_w);

    return std::isfinite(mean) && std::isfinite(mean_stat) && mean_stat > 0.0;
}

static double compute_chi2_reduced(const std::vector<TupleValue>& values,
                                   double mean) {
    int n = 0;
    double chi2 = 0.0;

    for (const auto& v : values) {
        if (!v.ok || v.stat <= 0.0 || !std::isfinite(v.value)) {
            continue;
        }

        const double residual = v.value - mean;
        chi2 += residual * residual / (v.stat * v.stat);
        ++n;
    }

    const double ndf = (double)n - 1.0;

    if (ndf <= 0.0) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    return chi2 / ndf;
}

static double compute_leave_one_out_chi2_reduced(const std::vector<TupleValue>& values) {
    int n = 0;
    double chi2 = 0.0;

    for (size_t i = 0; i < values.size(); ++i) {
        const TupleValue& v = values[i];

        if (!v.ok || v.stat <= 0.0 || !std::isfinite(v.value)) {
            continue;
        }

        double loo_mean = 0.0;
        double loo_mean_stat = 0.0;

        if (!compute_leave_one_out_mean(values, i, loo_mean, loo_mean_stat)) {
            continue;
        }

        const double var = v.stat * v.stat + loo_mean_stat * loo_mean_stat;

        if (!std::isfinite(var) || var <= 0.0) {
            continue;
        }

        const double residual = v.value - loo_mean;
        chi2 += residual * residual / var;
        ++n;
    }

    const double ndf = (double)n - 1.0;

    if (ndf <= 0.0) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    return chi2 / ndf;
}

static double eval_poly(const std::vector<double>& params,
                        double x) {
    double y = 0.0;
    double pow_x = 1.0;

    for (const double p : params) {
        y += p * pow_x;
        pow_x *= x;
    }

    return y;
}

static bool theta_in_scale_support(double theta) {
    return std::isfinite(theta) &&
           theta >= kScaleThetaMinDeg &&
           theta <= kScaleThetaMaxDeg;
}

static std::map<std::string, PolynomialScale>
load_e_theta_scale_polynomials(const fs::path& fit_summary_path) {
    CsvTable fit_table = read_csv_or_throw(fit_summary_path.string());

    require_columns(
        fit_table,
        {
            "case",
            "central mode",
            "reference type",
            "period",
            "variable",
            "polynomial order",
            "accepted",
            "p0",
            "p1",
            "p2",
            "p3",
            "p4",
            "p5"
        },
        "e_theta polynomial scale factors"
    );

    std::map<std::string, PolynomialScale> out;

    for (const auto& row : fit_table.rows) {
        const std::string case_name = get_string_field(fit_table, row, "case");
        const std::string central_mode = get_string_field(fit_table, row, "central mode");
        const std::string reference_type = get_string_field(fit_table, row, "reference type");
        const std::string period = get_string_field(fit_table, row, "period");
        const std::string variable = get_string_field(fit_table, row, "variable");
        const bool accepted = parse_bool_string(get_string_field(fit_table, row, "accepted"));

        if (case_name != "10.6 GeV unpol") {
            continue;
        }

        if (central_mode != "stat_weighted") {
            continue;
        }

        if (reference_type != "all_mean") {
            continue;
        }

        if (variable != "e_theta") {
            continue;
        }

        if (!accepted) {
            continue;
        }

        int order = -1;
        if (!parse_int(get_string_field(fit_table, row, "polynomial order"), order)) {
            continue;
        }

        if (order < 0 || order > 5) {
            continue;
        }

        std::vector<double> params;
        params.reserve((size_t)(order + 1));

        bool ok = true;

        for (int ip = 0; ip <= order; ++ip) {
            double p = 0.0;

            if (!parse_double(get_string_field(fit_table, row, "p" + std::to_string(ip)), p)) {
                ok = false;
                break;
            }

            params.push_back(p);
        }

        if (!ok) {
            continue;
        }

        PolynomialScale scale;
        scale.ok = true;
        scale.period = period;
        scale.order = order;
        scale.params = params;

        const auto it_existing = out.find(period);

        if (it_existing == out.end() || order > it_existing->second.order) {
            out[period] = scale;
        }
    }

    for (const auto& period : base_periods()) {
        const auto it = out.find(period);

        if (it == out.end() || !it->second.ok) {
            throw std::runtime_error(
                "Missing final accepted all_mean stat_weighted e_theta polynomial scale for period " +
                period + " in " + fit_summary_path.string()
            );
        }
    }

    std::cout << "[run-period-consistency] e_theta polynomial scale factors used for scaled plots:\n";

    for (const auto& period : base_periods()) {
        const PolynomialScale& scale = out.at(period);

        std::cout << "  " << std::left << std::setw(10) << period
                  << " order = " << std::right << scale.order
                  << " params =";

        for (const double p : scale.params) {
            std::cout << " " << std::setprecision(10) << p;
        }

        std::cout << "\n";
    }

    std::cout << "[run-period-consistency] e_theta polynomial reference values used only from "
              << kScaleThetaMinDeg << " to " << kScaleThetaMaxDeg << " degrees:\n";

    std::cout << std::left << std::setw(10) << "theta";

    for (const auto& period : base_periods()) {
        std::cout << std::right << std::setw(16) << period;
    }

    std::cout << "\n";

    for (int itheta = (int)std::ceil(kScaleThetaMinDeg);
         itheta <= (int)std::floor(kScaleThetaMaxDeg);
         ++itheta) {
        const double theta = (double)itheta;

        std::cout << std::left << std::setw(10) << std::setprecision(4) << theta;

        for (const auto& period : base_periods()) {
            const double scale_value = eval_poly(out.at(period).params, theta);
            std::cout << std::right << std::setw(16) << std::setprecision(8) << scale_value;
        }

        std::cout << "\n";
    }

    return out;
}

static TupleValue scaled_tuple(const TupleValue& input,
                               const std::string& source_period,
                               double e_theta_10p6,
                               bool use_scaling,
                               const std::map<std::string, PolynomialScale>& scale_by_period) {
    if (!input.ok) {
        return input;
    }

    if (!use_scaling) {
        return input;
    }

    if (!theta_in_scale_support(e_theta_10p6)) {
        return TupleValue();
    }

    const auto it = scale_by_period.find(source_period);

    if (it == scale_by_period.end() || !it->second.ok) {
        throw std::runtime_error("Missing e_theta polynomial scale for period " + source_period);
    }

    const double scale = eval_poly(it->second.params, e_theta_10p6);

    if (!std::isfinite(scale) || std::abs(scale) <= 0.0) {
        return TupleValue();
    }

    TupleValue out = input;
    out.value = input.value / scale;
    out.stat = input.stat / std::abs(scale);

    return out;
}

static TupleValue evaluate_input_for_row(const CsvTable& table,
                                         const std::vector<std::string>& row,
                                         const PeriodInput& input,
                                         bool use_scaling,
                                         const std::map<std::string, PolynomialScale>& scale_by_period) {
    TupleValue v = get_tuple(table, row, input.column);

    if (!use_scaling) {
        return v;
    }

    const double e_theta_10p6 =
        get_numeric_or_nan(table, row, avg_column("e_theta", "10.6 GeV"));

    return scaled_tuple(v,
                        input.source_period,
                        e_theta_10p6,
                        use_scaling,
                        scale_by_period);
}

static double percentile(std::vector<double> values,
                         double q) {
    std::vector<double> clean;

    for (const double v : values) {
        if (std::isfinite(v)) {
            clean.push_back(v);
        }
    }

    if (clean.empty()) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    std::sort(clean.begin(), clean.end());

    if (q <= 0.0) {
        return clean.front();
    }

    if (q >= 1.0) {
        return clean.back();
    }

    const double pos = q * (double)(clean.size() - 1);
    const size_t lo = (size_t)std::floor(pos);
    const size_t hi = (size_t)std::ceil(pos);
    const double frac = pos - (double)lo;

    if (lo == hi) {
        return clean[lo];
    }

    return clean[lo] * (1.0 - frac) + clean[hi] * frac;
}

static std::vector<double> choose_x_range(const std::vector<PointPack>& packs) {
    double xmin = std::numeric_limits<double>::infinity();
    double xmax = -std::numeric_limits<double>::infinity();

    for (const auto& pack : packs) {
        for (const double x : pack.x) {
            if (!std::isfinite(x)) {
                continue;
            }

            xmin = std::min(xmin, x);
            xmax = std::max(xmax, x);
        }
    }

    if (!std::isfinite(xmin) || !std::isfinite(xmax)) {
        return {0.0, 1.0};
    }

    if (xmin == xmax) {
        const double pad = (std::abs(xmin) > 0.0) ? 0.05 * std::abs(xmin) : 1.0;
        return {xmin - pad, xmax + pad};
    }

    const double pad = 0.07 * (xmax - xmin);
    return {xmin - pad, xmax + pad};
}

static std::vector<double> choose_chi2_y_range(const PointPack& pack) {
    std::vector<double> ys;

    for (const double y : pack.y) {
        if (std::isfinite(y) && y >= 0.0) {
            ys.push_back(y);
        }
    }

    if (ys.empty()) {
        return {0.0, 5.0};
    }

    double ymax = std::max(5.0, 1.25 * percentile(ys, 0.95));

    if (!std::isfinite(ymax) || ymax <= 0.0) {
        ymax = 5.0;
    }

    return {0.0, ymax};
}

static std::vector<double> choose_pull_y_range(const std::vector<PointPack>& packs) {
    std::vector<double> ys;

    for (const auto& pack : packs) {
        for (const double y : pack.y) {
            if (std::isfinite(y)) {
                ys.push_back(y);
            }
        }
    }

    if (ys.empty()) {
        return {-5.0, 5.0};
    }

    double ymin = std::min(-5.0, 1.25 * percentile(ys, 0.02));
    double ymax = std::max(5.0, 1.25 * percentile(ys, 0.98));

    if (!std::isfinite(ymin) || !std::isfinite(ymax) || ymin >= ymax) {
        return {-5.0, 5.0};
    }

    return {ymin, ymax};
}

static void set_pad_style() {
    gPad->SetLeftMargin(0.16);
    gPad->SetRightMargin(0.06);
    gPad->SetTopMargin(0.12);
    gPad->SetBottomMargin(0.15);
    gPad->SetTicks(1, 1);
    gPad->SetGrid(0, 0);
}

static TH1D* make_frame(const std::string& name,
                        const std::string& xtitle,
                        const std::string& ytitle,
                        double xmin,
                        double xmax,
                        double ymin,
                        double ymax) {
    TH1D* frame = new TH1D(name.c_str(), "", 100, xmin, xmax);
    frame->SetDirectory(nullptr);

    frame->SetMinimum(ymin);
    frame->SetMaximum(ymax);

    frame->GetXaxis()->SetTitle(xtitle.c_str());
    frame->GetYaxis()->SetTitle(ytitle.c_str());

    frame->GetXaxis()->CenterTitle();
    frame->GetYaxis()->CenterTitle();

    frame->GetXaxis()->SetTitleSize(0.060);
    frame->GetYaxis()->SetTitleSize(0.060);

    frame->GetXaxis()->SetLabelSize(0.047);
    frame->GetYaxis()->SetLabelSize(0.047);

    frame->GetXaxis()->SetTitleOffset(1.05);
    frame->GetYaxis()->SetTitleOffset(1.20);

    frame->GetXaxis()->SetNdivisions(505);
    frame->GetYaxis()->SetNdivisions(505);

    return frame;
}

static TGraphErrors* make_graph(const PointPack& pack,
                                int color,
                                int marker_style,
                                double marker_size) {
    TGraphErrors* graph = new TGraphErrors((int)pack.x.size());

    for (int i = 0; i < (int)pack.x.size(); ++i) {
        graph->SetPoint(i, pack.x[(size_t)i], pack.y[(size_t)i]);

        const double ey =
            ((size_t)i < pack.ey.size() && std::isfinite(pack.ey[(size_t)i]))
            ? pack.ey[(size_t)i]
            : 0.0;

        graph->SetPointError(i, 0.0, ey);
    }

    graph->SetMarkerColor(color);
    graph->SetLineColor(color);
    graph->SetMarkerStyle(marker_style);
    graph->SetMarkerSize(marker_size);
    graph->SetLineWidth(1);

    return graph;
}

static void draw_subpad_title(const std::string& text) {
    TLatex latex;
    latex.SetNDC();
    latex.SetTextFont(42);
    latex.SetTextSize(0.060);
    latex.SetTextAlign(22);
    latex.DrawLatex(0.50, 0.955, text.c_str());
}

static void draw_top_title(TPad* title_pad,
                           const std::string& text) {
    title_pad->cd();

    TLatex title;
    title.SetNDC();
    title.SetTextFont(42);
    title.SetTextSize(0.30);
    title.SetTextAlign(22);
    title.DrawLatex(0.50, 0.50, text.c_str());
}

static void make_title_and_grid_pads(TCanvas& canvas,
                                     TPad*& title_pad,
                                     TPad*& grid_pad,
                                     int ncols,
                                     int nrows) {
    canvas.cd();

    title_pad = new TPad("title_pad", "title_pad", 0.0, 0.925, 1.0, 1.0);
    title_pad->SetFillColor(kWhite);
    title_pad->SetFrameFillColor(kWhite);
    title_pad->SetBorderMode(0);
    title_pad->SetMargin(0.0, 0.0, 0.0, 0.0);
    title_pad->Draw();

    canvas.cd();

    grid_pad = new TPad("grid_pad", "grid_pad", 0.0, 0.0, 1.0, 0.925);
    grid_pad->SetFillColor(kWhite);
    grid_pad->SetFrameFillColor(kWhite);
    grid_pad->SetBorderMode(0);
    grid_pad->SetMargin(0.02, 0.02, 0.02, 0.02);
    grid_pad->Draw();
    grid_pad->Divide(ncols, nrows, 0.001, 0.001);
}

static std::string plot_prefix(bool use_scaling) {
    return use_scaling ? "scaled_etheta_poly" : "unscaled";
}

static std::string title_prefix(bool use_scaling) {
    return use_scaling ? "Scaled e_{#theta}-polynomial " : "Unscaled ";
}

static std::string canvas_tag_for_vars(const std::string& var_group_tag) {
    if (var_group_tag == "physics") {
        return "physics_kinematics";
    }

    if (var_group_tag == "angles") {
        return "polar_angles";
    }

    return var_group_tag;
}

static void draw_chi2_canvas(const fs::path& out_dir,
                             const ConsistencyCase& c,
                             const std::map<std::string, PointPack>& chi2_by_var,
                             const std::vector<VariableConfig>& vars,
                             const std::string& var_group_tag,
                             bool use_scaling,
                             const std::string& diagnostic_tag,
                             const std::string& diagnostic_title) {
    const int ncols = (var_group_tag == "angles") ? 3 : 2;
    const int nrows = (var_group_tag == "angles") ? 1 : 2;
    const int width = (var_group_tag == "angles") ? 1800 : 1600;
    const int height = (var_group_tag == "angles") ? 720 : 1200;

    const std::string prefix = plot_prefix(use_scaling);
    const std::string tag = canvas_tag_for_vars(var_group_tag);

    TCanvas canvas(("c_chi2_" + c.file_tag + "_" + prefix + "_" + diagnostic_tag + "_" + tag).c_str(),
                   ("Run-period reduced chi2: " + c.label).c_str(),
                   width,
                   height);
    canvas.SetFillColor(kWhite);

    TPad* title_pad = nullptr;
    TPad* grid_pad = nullptr;
    make_title_and_grid_pads(canvas, title_pad, grid_pad, ncols, nrows);
    draw_top_title(title_pad, title_prefix(use_scaling) + diagnostic_title + ": " + c.label + " (" + tag + ")");

    std::vector<std::unique_ptr<TH1D> > frames;
    std::vector<std::unique_ptr<TGraphErrors> > graphs;
    std::vector<std::unique_ptr<TLine> > lines;

    for (int ivar = 0; ivar < (int)vars.size(); ++ivar) {
        grid_pad->cd(ivar + 1);
        set_pad_style();

        PointPack pack;
        const auto it = chi2_by_var.find(vars[(size_t)ivar].key);

        if (it != chi2_by_var.end()) {
            pack = it->second;
        }

        const std::vector<PointPack> xpacks = {pack};
        const std::vector<double> xr = choose_x_range(xpacks);
        const std::vector<double> yr = choose_chi2_y_range(pack);

        std::unique_ptr<TH1D> frame(
            make_frame("frame_chi2_" + c.file_tag + "_" + prefix + "_" + diagnostic_tag + "_" + tag + "_" + vars[(size_t)ivar].key,
                       vars[(size_t)ivar].title,
                       "#chi^{2}/ndf",
                       xr[0],
                       xr[1],
                       yr[0],
                       yr[1])
        );

        frame->Draw("AXIS");

        std::unique_ptr<TLine> line(new TLine(xr[0], 1.0, xr[1], 1.0));
        line->SetLineStyle(2);
        line->SetLineWidth(2);
        line->SetLineColor(kRed + 1);
        line->Draw("SAME");

        if (!pack.x.empty()) {
            std::unique_ptr<TGraphErrors> graph(make_graph(pack, kBlack, 20, 0.50));
            graph->Draw("P SAME");
            graphs.push_back(std::move(graph));
        }

        draw_subpad_title(vars[(size_t)ivar].title);

        frames.push_back(std::move(frame));
        lines.push_back(std::move(line));
    }

    canvas.cd();
    canvas.Modified();
    canvas.Update();

    const fs::path png = out_dir / (prefix + "_" + diagnostic_tag + "_reduced_chi2_" + tag + ".png");
    canvas.SaveAs(png.string().c_str());
}

static void draw_multi_period_canvas(const fs::path& out_dir,
                                     const ConsistencyCase& c,
                                     const std::map<std::string, std::map<std::string, PointPack> >& by_var_period,
                                     const std::vector<VariableConfig>& vars,
                                     const std::string& var_group_tag,
                                     bool use_scaling,
                                     const std::string& kind,
                                     const std::string& ytitle,
                                     double ymin_fixed,
                                     double ymax_fixed,
                                     bool fixed_y,
                                     const std::string& diagnostic_title) {
    const int ncols = (var_group_tag == "angles") ? 3 : 2;
    const int nrows = (var_group_tag == "angles") ? 1 : 2;
    const int width = (var_group_tag == "angles") ? 1800 : 1600;
    const int height = (var_group_tag == "angles") ? 720 : 1200;

    const std::string prefix = plot_prefix(use_scaling);
    const std::string tag = canvas_tag_for_vars(var_group_tag);

    TCanvas canvas(("c_" + kind + "_" + c.file_tag + "_" + prefix + "_" + tag).c_str(),
                   ("Run-period " + kind + ": " + c.label).c_str(),
                   width,
                   height);
    canvas.SetFillColor(kWhite);

    TPad* title_pad = nullptr;
    TPad* grid_pad = nullptr;
    make_title_and_grid_pads(canvas, title_pad, grid_pad, ncols, nrows);
    draw_top_title(title_pad, title_prefix(use_scaling) + diagnostic_title + ": " + c.label + " (" + tag + ")");

    const std::vector<int> colors = {
        kBlack,
        kRed + 1,
        kBlue + 1,
        kGreen + 2,
        kMagenta + 1,
        kOrange + 7
    };

    const std::vector<int> markers = {
        20,
        24,
        21,
        25,
        22,
        26
    };

    std::vector<std::unique_ptr<TH1D> > frames;
    std::vector<std::unique_ptr<TGraphErrors> > graphs;
    std::vector<std::unique_ptr<TLine> > lines;
    std::vector<std::unique_ptr<TLegend> > legends;

    for (int ivar = 0; ivar < (int)vars.size(); ++ivar) {
        grid_pad->cd(ivar + 1);
        set_pad_style();

        std::vector<PointPack> xpacks;
        std::vector<PointPack> ypacks;

        const auto it_var = by_var_period.find(vars[(size_t)ivar].key);

        if (it_var != by_var_period.end()) {
            for (const auto& input : c.inputs) {
                const auto it_pack = it_var->second.find(input.period);

                if (it_pack == it_var->second.end()) {
                    continue;
                }

                xpacks.push_back(it_pack->second);
                ypacks.push_back(it_pack->second);
            }
        }

        const std::vector<double> xr = choose_x_range(xpacks);

        double ymin = ymin_fixed;
        double ymax = ymax_fixed;

        if (!fixed_y) {
            const std::vector<double> yr = choose_pull_y_range(ypacks);
            ymin = yr[0];
            ymax = yr[1];
        }

        std::unique_ptr<TH1D> frame(
            make_frame("frame_" + kind + "_" + c.file_tag + "_" + prefix + "_" + tag + "_" + vars[(size_t)ivar].key,
                       vars[(size_t)ivar].title,
                       ytitle,
                       xr[0],
                       xr[1],
                       ymin,
                       ymax)
        );

        frame->Draw("AXIS");

        const double ref_y = (kind.find("pulls") != std::string::npos) ? 0.0 : 1.0;

        std::unique_ptr<TLine> line(new TLine(xr[0], ref_y, xr[1], ref_y));
        line->SetLineStyle(2);
        line->SetLineWidth(2);
        line->SetLineColor(kRed + 1);
        line->Draw("SAME");

        std::unique_ptr<TLegend> legend(new TLegend(0.54, 0.68, 0.93, 0.89));
        legend->SetBorderSize(1);
        legend->SetFillStyle(1001);
        legend->SetFillColor(kWhite);
        legend->SetTextFont(42);
        legend->SetTextSize(0.040);

        int iper = 0;

        if (it_var != by_var_period.end()) {
            for (const auto& input : c.inputs) {
                const auto it_pack = it_var->second.find(input.period);

                if (it_pack == it_var->second.end() || it_pack->second.x.empty()) {
                    ++iper;
                    continue;
                }

                const int color = colors[(size_t)(iper % (int)colors.size())];
                const int marker = markers[(size_t)(iper % (int)markers.size())];

                std::unique_ptr<TGraphErrors> graph(make_graph(it_pack->second, color, marker, 0.48));
                graph->Draw("P SAME");
                legend->AddEntry(graph.get(), input.period.c_str(), "pe");
                graphs.push_back(std::move(graph));

                ++iper;
            }
        }

        legend->Draw();
        draw_subpad_title(vars[(size_t)ivar].title);

        frames.push_back(std::move(frame));
        lines.push_back(std::move(line));
        legends.push_back(std::move(legend));
    }

    canvas.cd();
    canvas.Modified();
    canvas.Update();

    const fs::path png = out_dir / (prefix + "_" + kind + "_" + tag + ".png");
    canvas.SaveAs(png.string().c_str());
}

static double mean_vec(const std::vector<double>& values) {
    if (values.empty()) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    double sum = 0.0;

    for (const double v : values) {
        sum += v;
    }

    return sum / (double)values.size();
}

static double rms_vec(const std::vector<double>& values) {
    if (values.empty()) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    const double mean = mean_vec(values);
    double sum = 0.0;

    for (const double v : values) {
        const double d = v - mean;
        sum += d * d;
    }

    return std::sqrt(sum / (double)values.size());
}

static void print_summary_block(const std::string& label,
                                const std::map<std::string, PointPack>& chi2_by_var,
                                const std::map<std::string, std::map<std::string, PointPack> >& pulls_by_var_period) {
    std::cout << label << "\n";

    for (const auto& var : variable_configs()) {
        const auto it = chi2_by_var.find(var.key);

        if (it == chi2_by_var.end()) {
            continue;
        }

        std::cout << "    chi2/ndf vs "
                  << std::left << std::setw(8) << var.key
                  << ": n=" << std::right << it->second.y.size()
                  << " mean=" << std::setprecision(8) << mean_vec(it->second.y)
                  << " rms=" << rms_vec(it->second.y)
                  << "\n";
    }

    const auto it_phi = pulls_by_var_period.find("phi");

    if (it_phi != pulls_by_var_period.end()) {
        for (const auto& kv : it_phi->second) {
            std::cout << "    pull "
                      << std::left << std::setw(10) << kv.first
                      << ": n=" << std::right << kv.second.y.size()
                      << " mean=" << std::setprecision(8) << mean_vec(kv.second.y)
                      << " rms=" << rms_vec(kv.second.y)
                      << "\n";
        }
    }
}

static void fill_case_outputs(const CsvTable& table,
                              const ConsistencyCase& c,
                              const std::map<std::string, PolynomialScale>& scale_by_period,
                              bool use_scaling,
                              std::map<std::string, PointPack>& chi2_by_var,
                              std::map<std::string, PointPack>& loo_chi2_by_var,
                              std::map<std::string, std::map<std::string, PointPack> >& ratios_by_var_period,
                              std::map<std::string, std::map<std::string, PointPack> >& pulls_by_var_period,
                              std::map<std::string, std::map<std::string, PointPack> >& loo_ratios_by_var_period,
                              std::map<std::string, std::map<std::string, PointPack> >& loo_pulls_by_var_period) {
    const std::vector<VariableConfig> vars = variable_configs();

    for (const auto& row : table.rows) {
        std::vector<TupleValue> values;
        values.reserve(c.inputs.size());

        for (const auto& input : c.inputs) {
            values.push_back(
                evaluate_input_for_row(table,
                                       row,
                                       input,
                                       use_scaling,
                                       scale_by_period)
            );
        }

        double mean = 0.0;
        double mean_stat = 0.0;

        if (!compute_weighted_mean_skip_invalid(values, mean, mean_stat)) {
            continue;
        }

        if (!std::isfinite(mean) || std::abs(mean) <= 0.0) {
            continue;
        }

        const double chi2_ndf = compute_chi2_reduced(values, mean);
        const double loo_chi2_ndf = compute_leave_one_out_chi2_reduced(values);

        if (!std::isfinite(chi2_ndf) && !std::isfinite(loo_chi2_ndf)) {
            continue;
        }

        for (const auto& var : vars) {
            const std::string col = avg_column(var.column_prefix, c.avg_label);
            const double x = get_numeric_or_nan(table, row, col);

            if (!std::isfinite(x)) {
                continue;
            }

            if (std::isfinite(chi2_ndf)) {
                chi2_by_var[var.key].x.push_back(x);
                chi2_by_var[var.key].y.push_back(chi2_ndf);
                chi2_by_var[var.key].ey.push_back(0.0);
            }

            if (std::isfinite(loo_chi2_ndf)) {
                loo_chi2_by_var[var.key].x.push_back(x);
                loo_chi2_by_var[var.key].y.push_back(loo_chi2_ndf);
                loo_chi2_by_var[var.key].ey.push_back(0.0);
            }

            for (size_t iper = 0; iper < c.inputs.size(); ++iper) {
                const TupleValue& v = values[iper];

                if (!v.ok || v.stat <= 0.0 || !std::isfinite(v.value)) {
                    continue;
                }

                const double ratio = v.value / mean;
                const double ratio_stat = std::abs(v.stat / mean);
                const double pull = (v.value - mean) / v.stat;

                if (std::isfinite(ratio) && std::isfinite(ratio_stat)) {
                    PointPack& pack = ratios_by_var_period[var.key][c.inputs[iper].period];
                    pack.x.push_back(x);
                    pack.y.push_back(ratio);
                    pack.ey.push_back(ratio_stat);
                }

                if (std::isfinite(pull)) {
                    PointPack& pack = pulls_by_var_period[var.key][c.inputs[iper].period];
                    pack.x.push_back(x);
                    pack.y.push_back(pull);
                    pack.ey.push_back(0.0);
                }

                double loo_mean = 0.0;
                double loo_mean_stat = 0.0;

                if (!compute_leave_one_out_mean(values, iper, loo_mean, loo_mean_stat)) {
                    continue;
                }

                if (!std::isfinite(loo_mean) || std::abs(loo_mean) <= 0.0) {
                    continue;
                }

                const double loo_ratio = v.value / loo_mean;
                const double loo_ratio_stat = std::abs(loo_ratio) * std::sqrt(
                    (v.stat / v.value) * (v.stat / v.value) +
                    (loo_mean_stat / loo_mean) * (loo_mean_stat / loo_mean)
                );

                const double loo_var = v.stat * v.stat + loo_mean_stat * loo_mean_stat;
                const double loo_pull =
                    (loo_var > 0.0 && std::isfinite(loo_var))
                    ? (v.value - loo_mean) / std::sqrt(loo_var)
                    : std::numeric_limits<double>::quiet_NaN();

                if (std::isfinite(loo_ratio) && std::isfinite(loo_ratio_stat)) {
                    PointPack& pack = loo_ratios_by_var_period[var.key][c.inputs[iper].period];
                    pack.x.push_back(x);
                    pack.y.push_back(loo_ratio);
                    pack.ey.push_back(loo_ratio_stat);
                }

                if (std::isfinite(loo_pull)) {
                    PointPack& pack = loo_pulls_by_var_period[var.key][c.inputs[iper].period];
                    pack.x.push_back(x);
                    pack.y.push_back(loo_pull);
                    pack.ey.push_back(0.0);
                }
            }
        }
    }
}

static void make_plots_for_case(const fs::path& root_out_dir,
                                const CsvTable& table,
                                const ConsistencyCase& c,
                                const std::map<std::string, PolynomialScale>& scale_by_period,
                                bool use_scaling) {
    const fs::path out_dir = root_out_dir / c.file_tag;
    fs::create_directories(out_dir);

    std::map<std::string, PointPack> chi2_by_var;
    std::map<std::string, PointPack> loo_chi2_by_var;

    std::map<std::string, std::map<std::string, PointPack> > ratios_by_var_period;
    std::map<std::string, std::map<std::string, PointPack> > pulls_by_var_period;

    std::map<std::string, std::map<std::string, PointPack> > loo_ratios_by_var_period;
    std::map<std::string, std::map<std::string, PointPack> > loo_pulls_by_var_period;

    fill_case_outputs(table,
                      c,
                      scale_by_period,
                      use_scaling,
                      chi2_by_var,
                      loo_chi2_by_var,
                      ratios_by_var_period,
                      pulls_by_var_period,
                      loo_ratios_by_var_period,
                      loo_pulls_by_var_period);

    const std::vector<VariableConfig> physics_vars = physics_variable_configs();
    const std::vector<VariableConfig> angle_vars = angle_variable_configs();

    draw_chi2_canvas(out_dir,
                     c,
                     chi2_by_var,
                     physics_vars,
                     "physics",
                     use_scaling,
                     "all_mean",
                     "all-mean #chi^{2}/ndf");

    draw_chi2_canvas(out_dir,
                     c,
                     chi2_by_var,
                     angle_vars,
                     "angles",
                     use_scaling,
                     "all_mean",
                     "all-mean #chi^{2}/ndf");

    draw_chi2_canvas(out_dir,
                     c,
                     loo_chi2_by_var,
                     physics_vars,
                     "physics",
                     use_scaling,
                     "leave_one_out",
                     "leave-one-out #chi^{2}/ndf");

    draw_chi2_canvas(out_dir,
                     c,
                     loo_chi2_by_var,
                     angle_vars,
                     "angles",
                     use_scaling,
                     "leave_one_out",
                     "leave-one-out #chi^{2}/ndf");

    draw_multi_period_canvas(out_dir,
                             c,
                             ratios_by_var_period,
                             physics_vars,
                             "physics",
                             use_scaling,
                             "all_mean_period_ratios",
                             "#sigma_{i}/#bar{#sigma}_{all}",
                             0.0,
                             3.0,
                             true,
                             "all-mean period ratios");

    draw_multi_period_canvas(out_dir,
                             c,
                             ratios_by_var_period,
                             angle_vars,
                             "angles",
                             use_scaling,
                             "all_mean_period_ratios",
                             "#sigma_{i}/#bar{#sigma}_{all}",
                             0.0,
                             3.0,
                             true,
                             "all-mean period ratios");

    draw_multi_period_canvas(out_dir,
                             c,
                             loo_ratios_by_var_period,
                             physics_vars,
                             "physics",
                             use_scaling,
                             "leave_one_out_period_ratios",
                             "#sigma_{i}/#bar{#sigma}_{-i}",
                             0.0,
                             3.0,
                             true,
                             "leave-one-out period ratios");

    draw_multi_period_canvas(out_dir,
                             c,
                             loo_ratios_by_var_period,
                             angle_vars,
                             "angles",
                             use_scaling,
                             "leave_one_out_period_ratios",
                             "#sigma_{i}/#bar{#sigma}_{-i}",
                             0.0,
                             3.0,
                             true,
                             "leave-one-out period ratios");

    draw_multi_period_canvas(out_dir,
                             c,
                             pulls_by_var_period,
                             physics_vars,
                             "physics",
                             use_scaling,
                             "all_mean_pulls",
                             "(#sigma_{i}-#bar{#sigma}_{all})/#delta#sigma_{i}",
                             -5.0,
                             5.0,
                             false,
                             "all-mean pulls");

    draw_multi_period_canvas(out_dir,
                             c,
                             pulls_by_var_period,
                             angle_vars,
                             "angles",
                             use_scaling,
                             "all_mean_pulls",
                             "(#sigma_{i}-#bar{#sigma}_{all})/#delta#sigma_{i}",
                             -5.0,
                             5.0,
                             false,
                             "all-mean pulls");

    draw_multi_period_canvas(out_dir,
                             c,
                             loo_pulls_by_var_period,
                             physics_vars,
                             "physics",
                             use_scaling,
                             "leave_one_out_pulls",
                             "(#sigma_{i}-#bar{#sigma}_{-i})/#sqrt{#delta#sigma_{i}^{2}+#delta#bar{#sigma}_{-i}^{2}}",
                             -5.0,
                             5.0,
                             false,
                             "leave-one-out pulls");

    draw_multi_period_canvas(out_dir,
                             c,
                             loo_pulls_by_var_period,
                             angle_vars,
                             "angles",
                             use_scaling,
                             "leave_one_out_pulls",
                             "(#sigma_{i}-#bar{#sigma}_{-i})/#sqrt{#delta#sigma_{i}^{2}+#delta#bar{#sigma}_{-i}^{2}}",
                             -5.0,
                             5.0,
                             false,
                             "leave-one-out pulls");

    print_summary_block(
        "[run-period-consistency] All-mean summary for " +
        std::string(use_scaling ? "scaled e_theta-polynomial " : "unscaled ") + c.label,
        chi2_by_var,
        pulls_by_var_period
    );

    print_summary_block(
        "[run-period-consistency] Leave-one-out summary for " +
        std::string(use_scaling ? "scaled e_theta-polynomial " : "unscaled ") + c.label,
        loo_chi2_by_var,
        loo_pulls_by_var_period
    );

    size_t npoints = 0;
    const auto it = chi2_by_var.find("phi");

    if (it != chi2_by_var.end()) {
        npoints = it->second.x.size();
    }

    size_t loo_npoints = 0;
    const auto it_loo = loo_chi2_by_var.find("phi");

    if (it_loo != loo_chi2_by_var.end()) {
        loo_npoints = it_loo->second.x.size();
    }

    std::cout << "[run-period-consistency] Completed "
              << (use_scaling ? "scaled e_theta-polynomial " : "unscaled ")
              << c.label
              << " with " << npoints
              << " all-mean valid bins and "
              << loo_npoints
              << " leave-one-out valid bins.\n";
}

} // namespace

bool run_period_consistency_systematics(const std::string& csv_path,
                                        const std::string& output_root_dir,
                                        bool make_all_cases) {
    try {
        const fs::path out_dir = fs::path(output_root_dir) / "run_period_consistency";
        fs::create_directories(out_dir);

        gROOT->SetBatch(kTRUE);
        gStyle->SetOptStat(0);
        gStyle->SetTitleFont(42, "XYZ");
        gStyle->SetLabelFont(42, "XYZ");
        gStyle->SetTitleFont(42, "");
        gStyle->SetTextFont(42);
        gStyle->SetEndErrorSize(0);
        gStyle->SetErrorX(0.0);
        gStyle->SetPadTickX(1);
        gStyle->SetPadTickY(1);

        const CsvTable table = read_csv_or_throw(csv_path);
        const std::vector<ConsistencyCase> all_cases = consistency_cases();
        const std::vector<VariableConfig> vars = variable_configs();

        std::vector<ConsistencyCase> cases_to_run;

        for (const auto& c : all_cases) {
            if (make_all_cases || c.file_tag == "10p6_GeV_unpol") {
                cases_to_run.push_back(c);
            }
        }

        validate_schema(table, cases_to_run, vars);

        const fs::path fit_summary_path =
            fs::path(output_root_dir) /
            "combination_systematics" /
            "kinematic_dependence_fits" /
            "kinematic_dependence_fit_summary.csv";

        const std::map<std::string, PolynomialScale> scale_by_period =
            load_e_theta_scale_polynomials(fit_summary_path);

        std::cout << "[run-period-consistency] CSV rows loaded: "
                  << table.rows.size() << "\n";
        std::cout << "[run-period-consistency] Output directory: "
                  << out_dir.string() << "\n";
        std::cout << "[run-period-consistency] make_all_cases = "
                  << (make_all_cases ? "true" : "false") << "\n";
        std::cout << "[run-period-consistency] Scale source: "
                  << fit_summary_path.string() << "\n";
        std::cout << "[run-period-consistency] Scaling is applied only for "
                  << kScaleThetaMinDeg << " <= e_theta <= "
                  << kScaleThetaMaxDeg << " degrees.\n";

        for (const auto& c : cases_to_run) {
            make_plots_for_case(out_dir,
                                table,
                                c,
                                scale_by_period,
                                false);

            make_plots_for_case(out_dir,
                                table,
                                c,
                                scale_by_period,
                                true);
        }

        return true;
    } catch (const std::exception& e) {
        std::cerr << "[run-period-consistency] FATAL: "
                  << e.what() << "\n";
        return false;
    }
}