// bsa.cpp
// -----------------------------------------------------------------------------
// Pi0-subtracted, direct count-based beam-spin asymmetry stage for the DVCS
// pass-2 workflow.
//
// This stage deliberately stays at the measured-count level. It does not use
// acceptance unfolding, bin migration unfolding, radiative corrections, or
// model bin-centering factors. It does apply:
//   * the process-wide global cuts from global_cuts.cpp,
//   * the Python-optimized exclusivity windows in output/jsons/combined_cuts.json,
//   * helicity-separated measured ep->eppi0 subtraction using the existing
//     bin-by-bin contamination ratio and normalized-yield CSV columns.
//
// Per period and CSV row:
//   G+/- = measured ep->epgamma counts after cuts
//   P+/- = measured ep->eppi0 counts after cuts
//   fpi0 = contamination_ratio * Y_norm(epgamma) / Y_norm(eppi0)
//   S+/- = G+/- - fpi0 * P+/-
//   A_LU = (S+ - S-) / [Pbeam * (S+ + S-)]
//
// For combined groups with multiple beam polarizations:
//   A_LU = sum_i(S_i+ - S_i-) / sum_i[P_i * (S_i+ + S_i-)]
//
// Plots are compact xB-slice canvases. Each populated pad is one (Q2, |t|) bin
// and shows A_LU(phi) with statistical error bars only. No theory curve or
// functional fit is drawn in this stage.
// ROOT tree loops are parallelized across independent trees; ROOT plotting remains serial.
// -----------------------------------------------------------------------------

#include "bsa.h"
#include "global_cuts.h"
#include "cross_sections.h"

// ROOT
#include <TAxis.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TH1F.h>
#include <TLatex.h>
#include <TLine.h>
#include <TPad.h>
#include <TROOT.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TTree.h>
#include <TVirtualPad.h>

// JSON
#include <nlohmann/json.hpp>
#include <omp.h>

// C++ stdlib
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

static constexpr double PI = 3.14159265358979323846;
static constexpr double RAD2DEG = 180.0 / PI;

struct StyleInit {
    StyleInit() {
        gStyle->SetOptTitle(0);
        gStyle->SetOptStat(0);
        gStyle->SetPadTickX(1);
        gStyle->SetPadTickY(1);
        gStyle->SetTitleFont(42, "XYZ");
        gStyle->SetLabelFont(42, "XYZ");
        gStyle->SetTextFont(42);
        gStyle->SetFrameLineWidth(2);
    }
} g_style_init;

static std::mutex g_root_bind_mutex;

static inline void fatal(const std::string& msg) {
    throw std::runtime_error(msg);
}

static inline std::string to_lower_ascii(std::string s) {
    for (char& c : s) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    } //endfor
    return s;
}

static inline std::string sanitize_token(std::string s) {
    for (char& c : s) {
        if (!std::isalnum(static_cast<unsigned char>(c))) {
            c = '_';
        } //endif
    } //endfor
    return s;
}

static inline double wrap_phi_deg(double phi_deg) {
    double p = std::fmod(phi_deg, 360.0);
    if (p < 0.0) {
        p += 360.0;
    } //endif
    if (p >= 360.0) {
        p = std::nextafter(360.0, 0.0);
    } //endif
    return p;
}

static inline double delta_phi_rad_from_two_phi(double phi_a, double phi_b) {
    double d = std::fmod(phi_a - phi_b, 2.0 * PI);
    if (d <= -PI) {
        d += 2.0 * PI;
    } //endif
    if (d > PI) {
        d -= 2.0 * PI;
    } //endif
    return std::fabs(d);
}

static inline bool in_range(double v, double a, double b) {
    return (v >= a) && (v < b);
}

static inline bool row_accepts_phi(double phi_deg, double pmin_deg, double pmax_deg) {
    if (pmax_deg > pmin_deg) {
        return in_range(phi_deg, pmin_deg, pmax_deg);
    } //endif
    return (phi_deg >= pmin_deg) || (phi_deg < pmax_deg);
}

static inline double phi_center_deg(double pmin_deg, double pmax_deg) {
    double lo = wrap_phi_deg(pmin_deg);
    double hi = wrap_phi_deg(pmax_deg);
    if (hi <= lo) {
        hi += 360.0;
    } //endif
    return wrap_phi_deg(0.5 * (lo + hi));
}

static inline double phi_half_width_deg(double pmin_deg, double pmax_deg) {
    double lo = wrap_phi_deg(pmin_deg);
    double hi = wrap_phi_deg(pmax_deg);
    if (hi <= lo) {
        hi += 360.0;
    } //endif
    return 0.5 * (hi - lo);
}

enum class TopologyIndex : int { FD_FD = 0, CD_FD = 1, CD_FT = 2, INVALID = -1 };

static inline TopologyIndex topology_index(int det1, int det2) {
    if (det1 == 1 && det2 == 1) return TopologyIndex::FD_FD;
    if (det1 == 2 && det2 == 1) return TopologyIndex::CD_FD;
    if (det1 == 2 && det2 == 0) return TopologyIndex::CD_FT;
    return TopologyIndex::INVALID;
}

static inline const char* topology_name(TopologyIndex topo) {
    switch (topo) {
        case TopologyIndex::FD_FD: return "FD_FD";
        case TopologyIndex::CD_FD: return "CD_FD";
        case TopologyIndex::CD_FT: return "CD_FT";
        default: return "";
    }
}

enum class PhotonTopologyFilter { All, FDPhoton, FTPhoton };

static inline bool topology_passes_filter(TopologyIndex topo, PhotonTopologyFilter filter) {
    if (filter == PhotonTopologyFilter::All) return true;
    if (filter == PhotonTopologyFilter::FDPhoton) {
        return topo == TopologyIndex::FD_FD || topo == TopologyIndex::CD_FD;
    } //endif
    return topo == TopologyIndex::CD_FT;
}

static inline std::string period_display_from_tree_key(const std::string& tree_key) {
    const std::string s = to_lower_ascii(tree_key);
    const auto has = [&](const char* sub) { return s.find(sub) != std::string::npos; };

    if (has("fa18") && has("inb") && !has("supp")) return "Fa18 Inb";
    if (has("fa18") && has("out")) return "Fa18 Out";
    if (has("sp19") && has("inb")) return "Sp19 Inb";
    if (has("sp18") && has("inb")) return "Sp18 Inb";
    if (has("sp18") && has("out")) return "Sp18 Out";

    return "";
}

static inline std::string period_code_from_display(const std::string& period) {
    if (period == "Fa18 Inb") return "Fa18_Inb";
    if (period == "Fa18 Out") return "Fa18_Out";
    if (period == "Sp19 Inb") return "Sp19_Inb";
    if (period == "Sp18 Inb") return "Sp18_Inb";
    if (period == "Sp18 Out") return "Sp18_Out";
    fatal("[bsa] unknown period label: " + period);
    return "";
}

static inline std::string period_global_cuts_label_from_display(const std::string& period) {
    if (period == "Fa18 Inb") return "fa18_inb";
    if (period == "Fa18 Out") return "fa18_out";
    if (period == "Sp19 Inb") return "sp19_inb";
    if (period == "Sp18 Inb") return "sp18_inb";
    if (period == "Sp18 Out") return "sp18_out";
    fatal("[bsa] unknown period label for global cuts: " + period);
    return "";
}

static inline double beam_pol_for_period(const std::string& period, const BSAOptions& opt) {
    if (period == "Sp18 Inb") return opt.beam_pol_sp18_inb;
    if (period == "Sp18 Out") return opt.beam_pol_sp18_out;
    if (period == "Fa18 Inb") return opt.beam_pol_fa18_inb;
    if (period == "Fa18 Out") return opt.beam_pol_fa18_out;
    if (period == "Sp19 Inb") return opt.beam_pol_sp19_inb;
    fatal("[bsa] no beam polarization configured for period: " + period);
    return std::numeric_limits<double>::quiet_NaN();
}

static const std::vector<std::string>& base_period_order() {
    static const std::vector<std::string> v = {
        "Fa18 Inb", "Fa18 Out", "Sp19 Inb", "Sp18 Inb", "Sp18 Out"
    };
    return v;
}

static const std::vector<std::string>& output_group_order() {
    static const std::vector<std::string> v = {
        "Fa18 Inb", "Fa18 Out", "Sp19 Inb", "Sp18 Inb", "Sp18 Out",
        "Fa18", "Sp18", "10.6 GeV"
    };
    return v;
}

static std::vector<std::string> component_periods_for_group(const std::string& group) {
    if (group == "Fa18 Inb") return {"Fa18 Inb"};
    if (group == "Fa18 Out") return {"Fa18 Out"};
    if (group == "Sp19 Inb") return {"Sp19 Inb"};
    if (group == "Sp18 Inb") return {"Sp18 Inb"};
    if (group == "Sp18 Out") return {"Sp18 Out"};
    if (group == "Fa18") return {"Fa18 Inb", "Fa18 Out"};
    if (group == "Sp18") return {"Sp18 Inb", "Sp18 Out"};
    if (group == "10.6 GeV") return {"Fa18 Inb", "Fa18 Out", "Sp18 Inb", "Sp18 Out"};
    fatal("[bsa] unknown BSA output group: " + group);
    return {};
}

static const std::vector<std::string>& csv_topology_labels() {
    static const std::vector<std::string> v = {"(FD, FD)", "(CD, FD)", "(CD, FT)"};
    return v;
}

// -----------------------------------------------------------------------------
// CSV helpers
// -----------------------------------------------------------------------------

struct CSV {
    std::vector<std::string> header;
    std::unordered_map<std::string, int> index;
    std::vector<std::vector<std::string>> rows;
};

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    bool inq = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (c == '"') {
            if (inq && i + 1 < line.size() && line[i + 1] == '"') {
                cur.push_back('"');
                ++i;
            } else {
                inq = !inq;
            } //endif
        } else if (c == ',' && !inq) {
            out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        } //endif
    } //endfor

    out.push_back(cur);
    return out;
}

static bool load_csv(const std::string& path, CSV& csv) {
    std::ifstream fin(path);
    if (!fin.is_open()) fatal("[bsa] cannot open CSV: " + path);

    std::string line;
    if (!std::getline(fin, line)) fatal("[bsa] empty CSV: " + path);

    csv.header = split_csv_line(line);
    csv.index.clear();
    for (int i = 0; i < static_cast<int>(csv.header.size()); ++i) {
        if (csv.index.count(csv.header[i])) fatal("[bsa] duplicate CSV column: " + csv.header[i]);
        csv.index[csv.header[i]] = i;
    } //endfor

    csv.rows.clear();
    while (std::getline(fin, line)) {
        if (line.empty()) continue;
        std::vector<std::string> row = split_csv_line(line);
        if (row.size() < csv.header.size()) row.resize(csv.header.size(), "");
        if (row.size() != csv.header.size()) fatal("[bsa] CSV row width mismatch in " + path);
        csv.rows.push_back(std::move(row));
    } //endwhile

    return true;
}

static void write_csv_atomic(const std::string& path, const CSV& csv) {
    const std::string tmp = path + ".tmp";
    std::ofstream fout(tmp);
    if (!fout.is_open()) fatal("[bsa] cannot write temporary CSV: " + tmp);

    auto write_cell = [&](const std::string& s) {
        const bool quote =
            s.find(',') != std::string::npos ||
            s.find('"') != std::string::npos ||
            s.find('\n') != std::string::npos ||
            s.find('\r') != std::string::npos;

        if (!quote) {
            fout << s;
            return;
        } //endif

        fout << '"';
        for (char c : s) {
            if (c == '"') fout << "\"\"";
            else fout << c;
        } //endfor
        fout << '"';
    };

    for (size_t i = 0; i < csv.header.size(); ++i) {
        write_cell(csv.header[i]);
        if (i + 1 < csv.header.size()) fout << ',';
    } //endfor
    fout << '\n';

    for (const auto& row : csv.rows) {
        if (row.size() != csv.header.size()) fatal("[bsa] CSV row width mismatch while writing");
        for (size_t i = 0; i < row.size(); ++i) {
            write_cell(row[i]);
            if (i + 1 < row.size()) fout << ',';
        } //endfor
        fout << '\n';
    } //endfor

    fout.close();
    if (!fout) fatal("[bsa] failed while writing temporary CSV: " + tmp);

    (void)std::remove(path.c_str());
    if (std::rename(tmp.c_str(), path.c_str()) != 0) {
        fatal("[bsa] failed to rename " + tmp + " to " + path);
    } //endif
}

static int col_strict(const CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);
    if (it == csv.index.end()) fatal("[bsa] missing required CSV column: " + name);
    return it->second;
}

static int col_optional(const CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);
    if (it == csv.index.end()) return -1;
    return it->second;
}

static int ensure_col(CSV& csv, const std::string& name) {
    auto it = csv.index.find(name);
    if (it != csv.index.end()) return it->second;
    const int idx = static_cast<int>(csv.header.size());
    csv.header.push_back(name);
    csv.index[name] = idx;
    for (auto& row : csv.rows) row.push_back("");
    return idx;
}

static inline double to_double_strict(const std::string& s, const std::string& what) {
    if (s.empty()) fatal("[bsa] empty numeric cell for " + what);
    char* end = nullptr;
    const double v = std::strtod(s.c_str(), &end);
    if (end == s.c_str()) fatal("[bsa] parse failure for " + what + " value '" + s + "'");
    return v;
}

static inline bool parse_double_loose(const std::string& s, double& out) {
    if (s.empty()) return false;
    char* end = nullptr;
    out = std::strtod(s.c_str(), &end);
    return end != s.c_str() && std::isfinite(out);
}

static inline bool to_bool_valid(const std::string& s) {
    return (s == "1" || s == "1.0" || s == "true" || s == "TRUE");
}

static bool parse_tuple_first(const std::string& s, double& value) {
    std::string t = s;
    t.erase(std::remove_if(t.begin(), t.end(), [](unsigned char c) {
        return std::isspace(c);
    }), t.end());

    if (t.empty()) return false;

    if (t.front() == '(') {
        const size_t comma = t.find(',');
        const size_t close = t.find(')');
        if (comma == std::string::npos || close == std::string::npos || comma <= 1) return false;
        return parse_double_loose(t.substr(1, comma - 1), value);
    } //endif

    return parse_double_loose(t, value);
}

// -----------------------------------------------------------------------------
// Row binning
// -----------------------------------------------------------------------------

struct RowBin {
    double xBmin = std::numeric_limits<double>::quiet_NaN();
    double xBmax = std::numeric_limits<double>::quiet_NaN();
    double Q2min = std::numeric_limits<double>::quiet_NaN();
    double Q2max = std::numeric_limits<double>::quiet_NaN();
    double tmin  = std::numeric_limits<double>::quiet_NaN();
    double tmax  = std::numeric_limits<double>::quiet_NaN();
    double pmin  = std::numeric_limits<double>::quiet_NaN();
    double pmax  = std::numeric_limits<double>::quiet_NaN();
    bool valid = false;
};

struct AxisBin {
    double min = 0.0;
    double max = 0.0;
};

struct FastBinning {
    std::vector<AxisBin> xbins;
    std::vector<AxisBin> qbins;
    std::vector<AxisBin> tbins;
    std::vector<std::vector<std::vector<std::vector<int>>>> rows_by_xqt;
};

static std::vector<RowBin> load_row_bins_from_csv(const CSV& csv) {
    const int c_xBmin = col_strict(csv, "xBmin");
    const int c_xBmax = col_strict(csv, "xBmax");
    const int c_Q2min = col_strict(csv, "Q2min");
    const int c_Q2max = col_strict(csv, "Q2max");
    const int c_tmin  = col_strict(csv, "t_abs_min");
    const int c_tmax  = col_strict(csv, "t_abs_max");
    const int c_pmin  = col_strict(csv, "phimin");
    const int c_pmax  = col_strict(csv, "phimax");
    const int c_valid = col_strict(csv, "valid bin");

    std::vector<RowBin> rows;
    rows.reserve(csv.rows.size());

    for (int r = 0; r < static_cast<int>(csv.rows.size()); ++r) {
        const auto& row = csv.rows[r];
        RowBin b;
        b.xBmin = to_double_strict(row[c_xBmin], "xBmin");
        b.xBmax = to_double_strict(row[c_xBmax], "xBmax");
        b.Q2min = to_double_strict(row[c_Q2min], "Q2min");
        b.Q2max = to_double_strict(row[c_Q2max], "Q2max");
        b.tmin  = to_double_strict(row[c_tmin],  "t_abs_min");
        b.tmax  = to_double_strict(row[c_tmax],  "t_abs_max");
        b.pmin  = to_double_strict(row[c_pmin],  "phimin");
        b.pmax  = to_double_strict(row[c_pmax],  "phimax");
        b.valid = to_bool_valid(row[c_valid]);
        rows.push_back(b);
    } //endfor

    return rows;
}

static inline bool axis_bin_equal(const AxisBin& a, const AxisBin& b) {
    return a.min == b.min && a.max == b.max;
}

static void add_unique_axis_bin(std::vector<AxisBin>& bins, double minv, double maxv) {
    AxisBin b{minv, maxv};
    auto it = std::find_if(bins.begin(), bins.end(), [&](const AxisBin& x) {
        return axis_bin_equal(x, b);
    });
    if (it == bins.end()) bins.push_back(b);
}

static void sort_axis_bins(std::vector<AxisBin>& bins) {
    std::sort(bins.begin(), bins.end(), [](const AxisBin& a, const AxisBin& b) {
        if (a.min != b.min) return a.min < b.min;
        return a.max < b.max;
    });
}

static int find_axis_bin_index(const std::vector<AxisBin>& bins, double value) {
    for (int i = 0; i < static_cast<int>(bins.size()); ++i) {
        if (value >= bins[i].min && value < bins[i].max) return i;
    } //endfor
    return -1;
}

static int find_axis_bin_exact(const std::vector<AxisBin>& bins, double minv, double maxv) {
    for (int i = 0; i < static_cast<int>(bins.size()); ++i) {
        if (bins[i].min == minv && bins[i].max == maxv) return i;
    } //endfor
    return -1;
}

static FastBinning build_fast_binning(const std::vector<RowBin>& rows) {
    FastBinning fb;

    for (const RowBin& r : rows) {
        if (!r.valid) continue;
        add_unique_axis_bin(fb.xbins, r.xBmin, r.xBmax);
        add_unique_axis_bin(fb.qbins, r.Q2min, r.Q2max);
        add_unique_axis_bin(fb.tbins, r.tmin, r.tmax);
    } //endfor

    sort_axis_bins(fb.xbins);
    sort_axis_bins(fb.qbins);
    sort_axis_bins(fb.tbins);

    fb.rows_by_xqt.resize(fb.xbins.size());
    for (size_t ix = 0; ix < fb.xbins.size(); ++ix) {
        fb.rows_by_xqt[ix].resize(fb.qbins.size());
        for (size_t iq = 0; iq < fb.qbins.size(); ++iq) {
            fb.rows_by_xqt[ix][iq].resize(fb.tbins.size());
        } //endfor
    } //endfor

    for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
        const RowBin& row = rows[r];
        if (!row.valid) continue;

        const int ix = find_axis_bin_exact(fb.xbins, row.xBmin, row.xBmax);
        const int iq = find_axis_bin_exact(fb.qbins, row.Q2min, row.Q2max);
        const int it = find_axis_bin_exact(fb.tbins, row.tmin, row.tmax);
        if (ix < 0 || iq < 0 || it < 0) fatal("[bsa] failed to build fast row-bin lookup");
        fb.rows_by_xqt[ix][iq][it].push_back(r);
    } //endfor

    std::cout << "[bsa] Fast bin lookup built with "
              << fb.xbins.size() << " xB bins, "
              << fb.qbins.size() << " Q2 bins, "
              << fb.tbins.size() << " |t| bins.\n";

    return fb;
}

// -----------------------------------------------------------------------------
// Combined cuts loader
// -----------------------------------------------------------------------------

struct SigmaStats {
    double mean = std::numeric_limits<double>::quiet_NaN();
    double std  = std::numeric_limits<double>::quiet_NaN();
    double cut_low = std::numeric_limits<double>::quiet_NaN();
    double cut_high = std::numeric_limits<double>::quiet_NaN();
    double quantile = 0.0;
    std::string mode = "symmetric_3sigma";
};

using CutVarMap = std::unordered_map<std::string, SigmaStats>;
using TopoCutMap = std::unordered_map<std::string, CutVarMap>;

static inline bool within_cut_window(double v, const SigmaStats& s) {
    if (!std::isfinite(v)) return false;

    if (s.mode == "upper_quantile") {
        if (!std::isfinite(s.cut_high)) return true;
        return v <= s.cut_high;
    } //endif

    double lo = s.cut_low;
    double hi = s.cut_high;
    if (!(std::isfinite(lo) && std::isfinite(hi)) || hi <= lo) {
        if (!std::isfinite(s.mean) || !std::isfinite(s.std) || s.std <= 0.0) return true;
        lo = s.mean - 3.0 * s.std;
        hi = s.mean + 3.0 * s.std;
    } //endif

    return v >= lo && v <= hi;
}

static TopoCutMap load_combined_cuts(const std::string& combined_cuts_json) {
    std::ifstream fin(combined_cuts_json);
    if (!fin.is_open()) fatal("[bsa] cannot open combined cuts JSON: " + combined_cuts_json);

    nlohmann::json j;
    try {
        fin >> j;
    } catch (const std::exception& e) {
        fatal("[bsa] failed to parse combined cuts JSON " +
              combined_cuts_json + ": " + e.what());
    }
    if (!j.is_object()) {
        fatal("[bsa] combined cuts JSON is not an object: " +
              combined_cuts_json);
    }

    TopoCutMap out;

    for (auto it = j.begin(); it != j.end(); ++it) {
        const std::string key = it.key();
        const auto& block = it.value();
        if (!block.is_object() || !block.contains("data")) continue;

        const auto& data = block["data"];
        if (!data.is_object()) continue;

        CutVarMap vm;
        for (auto vit = data.begin(); vit != data.end(); ++vit) {
            const std::string var = vit.key();
            const auto& stats = vit.value();
            if (!stats.is_object() || !stats.contains("mean") || !stats.contains("std")) continue;

            SigmaStats s;
            try {
                s.mean = stats["mean"].get<double>();
                s.std  = stats["std"].get<double>();
                if (stats.contains("cut_low"))  s.cut_low  = stats["cut_low"].get<double>();
                if (stats.contains("cut_high")) s.cut_high = stats["cut_high"].get<double>();
                if (stats.contains("quantile")) s.quantile = stats["quantile"].get<double>();
                if (stats.contains("mode"))     s.mode     = stats["mode"].get<std::string>();
            } catch (...) {
                continue;
            } //endtry

            if (!std::isfinite(s.cut_low) || !std::isfinite(s.cut_high) || s.cut_high <= s.cut_low) {
                if (std::isfinite(s.mean) && std::isfinite(s.std) && s.std > 0.0) {
                    s.cut_low  = s.mean - 3.0 * s.std;
                    s.cut_high = s.mean + 3.0 * s.std;
                } //endif
            } //endif

            if (std::isfinite(s.cut_high)) vm.emplace(var, s);
        } //endfor

        if (!vm.empty()) {
            static const std::set<std::string> supported = {
                "Delta_phi",
                "theta",
                "theta_gamma_gamma",
                "theta_pi0_pi0",
                "pTmiss",
                "Emiss2",
                "Mx2",
                "Mx2_2"
            };

            for (const auto& kv : vm) {
                if (supported.find(kv.first) == supported.end()) {
                    fatal("[bsa] unsupported production exclusivity variable '" +
                          kv.first + "' in JSON block " + key);
                }
            }

            if (vm.find("Mx2") == vm.end()) {
                fatal("[bsa] JSON block " + key +
                      " does not contain the required forced-first Mx2 cut");
            }

            out.emplace(key, std::move(vm));
        }
    } //endfor

    std::cout << "[bsa] Loaded " << out.size()
              << " data topology/period cut blocks from "
              << combined_cuts_json << "\n";

    return out;
}

// -----------------------------------------------------------------------------
// Branch binding and event selection
// -----------------------------------------------------------------------------

struct BranchBinder {
    int runnum = 0; bool has_runnum = false;
    int detector1 = 0; bool has_detector1 = false;
    int detector2 = 0; bool has_detector2 = false;
    int helicity = 0; bool has_helicity = false;

    double x = 0.0; bool has_x = false;
    double Q2 = 0.0; bool has_Q2 = false;
    double t1 = 0.0; bool has_t1 = false;
    double phi2 = 0.0; bool has_phi2 = false;
    double Delta_phi = 0.0; bool has_Delta_phi = false;

    double open_angle_ep2 = 0.0; bool has_open_angle = false;
    double pTmiss = 0.0; bool has_pTmiss = false;
    double theta = 0.0; bool has_theta = false;
    double theta_gamma_gamma = 0.0; bool has_theta_gamma_gamma = false;
    double theta_pi0_pi0 = 0.0; bool has_theta_pi0_pi0 = false;
    double Emiss2 = 0.0; bool has_Emiss2 = false;
    double Mx2 = 0.0; bool has_Mx2 = false;
    double Mx2_2 = 0.0; bool has_Mx2_2 = false;

    double e_p = 0.0; bool has_e_p = false;
    double e_theta = 0.0; bool has_e_theta = false;
    double e_phi = 0.0; bool has_e_phi = false;
    double p1_theta = 0.0; bool has_p1_theta = false;
    double p1_phi = 0.0; bool has_p1_phi = false;
    double p2_p = 0.0; bool has_p2_p = false;
    double p2_theta = 0.0; bool has_p2_theta = false;
    double p2_phi = 0.0; bool has_p2_phi = false;

    void bind(TTree* t) {
        if (!t) return;

        std::lock_guard<std::mutex> lock(g_root_bind_mutex);
        t->SetBranchStatus("*", 0);

        auto enable = [&](const char* name) {
            if (t->GetBranch(name)) t->SetBranchStatus(name, 1);
        };

        const char* names[] = {
            "runnum", "detector1", "detector2", "helicity",
            "x", "Q2", "t1", "phi2", "Delta_phi",
            "open_angle_ep2", "pTmiss",
            "theta", "theta_gamma_gamma", "theta_pi0_pi0",
            "Emiss2", "Mx2", "Mx2_2",
            "e_p", "e_theta", "e_phi", "p1_theta", "p1_phi",
            "p2_p", "p2_theta", "p2_phi"
        };
        for (const char* name : names) enable(name);

        t->SetCacheSize(16LL * 1024LL * 1024LL);
        t->AddBranchToCache("*", true);

        auto bind_int = [&](const char* name, int* ptr, bool& has) {
            if (t->GetBranch(name)) { t->SetBranchAddress(name, ptr); has = true; }
        };
        auto bind_double = [&](const char* name, double* ptr, bool& has) {
            if (t->GetBranch(name)) { t->SetBranchAddress(name, ptr); has = true; }
        };

        bind_int("runnum", &runnum, has_runnum);
        bind_int("detector1", &detector1, has_detector1);
        bind_int("detector2", &detector2, has_detector2);
        bind_int("helicity", &helicity, has_helicity);

        bind_double("x", &x, has_x);
        bind_double("Q2", &Q2, has_Q2);
        bind_double("t1", &t1, has_t1);
        bind_double("phi2", &phi2, has_phi2);
        bind_double("Delta_phi", &Delta_phi, has_Delta_phi);
        bind_double("open_angle_ep2", &open_angle_ep2, has_open_angle);
        bind_double("pTmiss", &pTmiss, has_pTmiss);
        bind_double("theta", &theta, has_theta);
        bind_double("theta_gamma_gamma", &theta_gamma_gamma, has_theta_gamma_gamma);
        bind_double("theta_pi0_pi0", &theta_pi0_pi0, has_theta_pi0_pi0);
        bind_double("Emiss2", &Emiss2, has_Emiss2);
        bind_double("Mx2", &Mx2, has_Mx2);
        bind_double("Mx2_2", &Mx2_2, has_Mx2_2);
        bind_double("e_p", &e_p, has_e_p);
        bind_double("e_theta", &e_theta, has_e_theta);
        bind_double("e_phi", &e_phi, has_e_phi);
        bind_double("p1_theta", &p1_theta, has_p1_theta);
        bind_double("p1_phi", &p1_phi, has_p1_phi);
        bind_double("p2_p", &p2_p, has_p2_p);
        bind_double("p2_theta", &p2_theta, has_p2_theta);
        bind_double("p2_phi", &p2_phi, has_p2_phi);
    }

    double phi_deg() const { return wrap_phi_deg(phi2 * RAD2DEG); }
    double t_abs() const { return std::fabs(t1); }

    double delta_phi_value(bool& has_val) const {
        if (has_Delta_phi) { has_val = true; return Delta_phi; }
        if (has_p1_phi && has_p2_phi) {
            has_val = true;
            return delta_phi_rad_from_two_phi(p1_phi, p2_phi);
        } //endif
        has_val = false;
        return 0.0;
    }
};

static inline double branch_value_for_sigma_var(const BranchBinder& b,
                                                const std::string& var,
                                                bool& has_val) {
    has_val = true;
    if (var == "Delta_phi") { return b.delta_phi_value(has_val); }
    if (var == "theta") { has_val = b.has_theta; return b.theta; }
    if (var == "theta_gamma_gamma") {
        has_val = b.has_theta_gamma_gamma;
        return b.theta_gamma_gamma;
    }
    if (var == "theta_pi0_pi0") {
        has_val = b.has_theta_pi0_pi0;
        return b.theta_pi0_pi0;
    }
    if (var == "pTmiss") { has_val = b.has_pTmiss; return b.pTmiss; }
    if (var == "Emiss2") { has_val = b.has_Emiss2; return b.Emiss2; }
    if (var == "Mx2") { has_val = b.has_Mx2; return b.Mx2; }
    if (var == "Mx2_2") { has_val = b.has_Mx2_2; return b.Mx2_2; }
    has_val = false;
    return 0.0;
}

static bool passes_sigma_cuts(const TopoCutMap& cuts,
                              const std::string& key,
                              const BranchBinder& b) {
    auto it = cuts.find(key);
    if (it == cuts.end()) fatal("[bsa] missing data cut key in combined_cuts.json: " + key);

    for (const auto& var_pair : it->second) {
        bool has_val = false;
        const double val = branch_value_for_sigma_var(b, var_pair.first, has_val);
        if (!has_val) {
            fatal("[bsa] cut key " + key + " requires missing branch: " + var_pair.first);
        } //endif
        if (!within_cut_window(val, var_pair.second)) return false;
    } //endfor

    return true;
}

static bool passes_global_cuts_dispatch(const BranchBinder& b,
                                        const std::string& period_display_label) {
    const GlobalCutConfig& cfg = default_global_cuts();
    const std::string period_label = period_global_cuts_label_from_display(period_display_label);

    if (!(b.has_t1 && b.has_open_angle)) return false;
    if (cfg.enable_pTmiss_cut && !b.has_pTmiss) return false;
    if (b.has_runnum && is_excluded_run(b.runnum)) return false;

    if (cfg.enable_topology_filter || global_cuts_require_sector_phi(cfg) || cfg.enable_dvcsgen_ycol_cut ||
        global_cuts_require_auxiliary_kinematics(cfg)) {
        if (!(b.has_detector1 && b.has_detector2)) {
            fatal("[bsa] topology/sector/ycol/aux selection requires detector1 and detector2 branches");
        } //endif
    } //endif

    if (global_cuts_require_sector_phi(cfg)) {
        if (!(b.has_e_phi && b.has_p1_phi && b.has_p2_phi)) {
            fatal("[bsa] sector selection requires e_phi, p1_phi and p2_phi branches");
        } //endif
    } //endif

    if (global_cuts_require_auxiliary_kinematics(cfg)) {
        if (!(b.has_e_theta && b.has_e_phi && b.has_p1_theta && b.has_p1_phi &&
              b.has_p2_p && b.has_p2_theta && b.has_p2_phi)) {
            fatal("[bsa] auxiliary fiducial cuts require e_theta, e_phi, p1_theta, p1_phi, p2_p, p2_theta and p2_phi branches");
        } //endif
        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  period_label,
                                  b.e_p, b.e_theta, b.e_phi,
                                  b.p1_theta, b.p1_phi,
                                  b.p2_p, b.p2_theta, b.p2_phi,
                                  cfg);
    } //endif

    if (cfg.enable_dvcsgen_ycol_cut) {
        if (!(b.has_e_p && b.has_e_theta && b.has_e_phi && b.has_p2_p && b.has_p2_theta && b.has_p2_phi)) {
            fatal("[bsa] dvcsgen ycol cut requires e_p, e_theta, e_phi, p2_p, p2_theta and p2_phi branches");
        } //endif
        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  period_label,
                                  b.e_p, b.e_theta, b.e_phi,
                                  b.p2_p, b.p2_theta, b.p2_phi,
                                  cfg);
    } //endif

    if (global_cuts_require_sector_phi(cfg)) {
        return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                                  b.detector1, b.detector2,
                                  period_label,
                                  b.e_phi, b.p1_phi, b.p2_phi,
                                  cfg);
    } //endif

    return passes_global_cuts(b.t1, b.open_angle_ep2, b.pTmiss,
                              b.detector1, b.detector2,
                              cfg);
}

// -----------------------------------------------------------------------------
// Counts
// -----------------------------------------------------------------------------

struct HelCounts {
    double plus = 0.0;
    double minus = 0.0;
};

using RowCounts = std::unordered_map<int, HelCounts>;
using PeriodCounts = std::unordered_map<std::string, RowCounts>;
using DenseCounts = std::vector<HelCounts>;

static inline void add_event(HelCounts& h, int helicity) {
    if (helicity > 0) h.plus += 1.0;
    else if (helicity < 0) h.minus += 1.0;
}

struct CompiledSigmaCut {
    enum class Variable : int {
        DeltaPhi,
        Theta,
        ThetaGammaGamma,
        ThetaPi0Pi0,
        PTmiss,
        Emiss2,
        Mx2,
        Mx2_2
    };
    Variable variable;
    const SigmaStats* stats = nullptr;
};

using CompiledSigmaCuts = std::vector<CompiledSigmaCut>;

static CompiledSigmaCut::Variable sigma_variable_id(const std::string& var) {
    if (var == "Delta_phi") return CompiledSigmaCut::Variable::DeltaPhi;
    if (var == "theta") return CompiledSigmaCut::Variable::Theta;
    if (var == "theta_gamma_gamma") {
        return CompiledSigmaCut::Variable::ThetaGammaGamma;
    }
    if (var == "theta_pi0_pi0") {
        return CompiledSigmaCut::Variable::ThetaPi0Pi0;
    }
    if (var == "pTmiss") return CompiledSigmaCut::Variable::PTmiss;
    if (var == "Emiss2") return CompiledSigmaCut::Variable::Emiss2;
    if (var == "Mx2") return CompiledSigmaCut::Variable::Mx2;
    if (var == "Mx2_2") return CompiledSigmaCut::Variable::Mx2_2;

    fatal("[bsa] unsupported production exclusivity variable in combined cuts JSON: " + var);
    return CompiledSigmaCut::Variable::DeltaPhi;
}

static CompiledSigmaCuts compile_sigma_cuts(const TopoCutMap& cuts,
                                             const std::string& key) {
    auto it = cuts.find(key);
    if (it == cuts.end()) fatal("[bsa] missing data cut key in combined_cuts.json: " + key);
    CompiledSigmaCuts out;
    out.reserve(it->second.size());
    for (const auto& kv : it->second) {
        out.push_back({sigma_variable_id(kv.first), &kv.second});
    }
    return out;
}

static inline bool passes_compiled_sigma_cuts(const CompiledSigmaCuts& cuts,
                                               const BranchBinder& b) {
    for (const CompiledSigmaCut& cut : cuts) {
        bool has = true;
        double value = 0.0;
        switch (cut.variable) {
            case CompiledSigmaCut::Variable::DeltaPhi:
                value = b.delta_phi_value(has);
                break;
            case CompiledSigmaCut::Variable::Theta:
                has = b.has_theta;
                value = b.theta;
                break;
            case CompiledSigmaCut::Variable::ThetaGammaGamma:
                has = b.has_theta_gamma_gamma;
                value = b.theta_gamma_gamma;
                break;
            case CompiledSigmaCut::Variable::ThetaPi0Pi0:
                has = b.has_theta_pi0_pi0;
                value = b.theta_pi0_pi0;
                break;
            case CompiledSigmaCut::Variable::PTmiss:
                has = b.has_pTmiss;
                value = b.pTmiss;
                break;
            case CompiledSigmaCut::Variable::Emiss2:
                has = b.has_Emiss2;
                value = b.Emiss2;
                break;
            case CompiledSigmaCut::Variable::Mx2:
                has = b.has_Mx2;
                value = b.Mx2;
                break;
            case CompiledSigmaCut::Variable::Mx2_2:
                has = b.has_Mx2_2;
                value = b.Mx2_2;
                break;
        }
        if (!has) fatal("[bsa] compiled sigma cut requires a missing branch");
        if (!within_cut_window(value, *cut.stats)) return false;
    }
    return true;
}

static inline unsigned long long splitmix64(unsigned long long x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static inline int scrambled_helicity(int original_helicity, int runnum, Long64_t entry,
                                     int replica, unsigned long long seed,
                                     unsigned long long channel_salt) {
    if (original_helicity == 0) return 0;
    unsigned long long key = seed ^ channel_salt;
    key ^= static_cast<unsigned long long>(static_cast<unsigned int>(runnum)) * 0x9e3779b97f4a7c15ULL;
    key ^= static_cast<unsigned long long>(entry) * 0xbf58476d1ce4e5b9ULL;
    key ^= static_cast<unsigned long long>(replica + 1) * 0x94d049bb133111ebULL;
    return (splitmix64(key) & 1ULL) ? 1 : -1;
}

struct CountTask {
    std::string tree_key;
    std::string period;
    std::string period_code;
    TTree* tree = nullptr;
    std::array<CompiledSigmaCuts, 3> compiled_cuts;
};

struct CountTaskResult {
    DenseCounts counts;
    std::vector<DenseCounts> scramble_counts;
    long long entries = 0;
    long long topology = 0;
    long long global = 0;
    long long sigma = 0;
    long long matched = 0;
};

static PeriodCounts accumulate_counts(const std::map<std::string, TTree*>& trees,
                                      const std::string& channel_name,
                                      const std::string& cut_prefix,
                                      const std::vector<RowBin>& rows,
                                      const FastBinning& fast_bins,
                                      const TopoCutMap& sigma_cuts,
                                      int max_workers,
                                      PhotonTopologyFilter topology_filter = PhotonTopologyFilter::All,
                                      std::vector<PeriodCounts>* scramble_outputs = nullptr,
                                      int scramble_replicas = 0,
                                      unsigned long long scramble_seed = 0ULL) {
    PeriodCounts out;
    for (const std::string& period : base_period_order()) out[period] = RowCounts();
    if (scramble_outputs) {
        scramble_outputs->assign(std::max(0, scramble_replicas), PeriodCounts());
        for (PeriodCounts& pc : *scramble_outputs) {
            for (const std::string& period : base_period_order()) pc[period] = RowCounts();
        } //endfor
    } //endif

    std::vector<CountTask> tasks;
    tasks.reserve(trees.size());
    for (const auto& kv : trees) {
        if (!kv.second) continue;
        const std::string period = period_display_from_tree_key(kv.first);
        if (period.empty()) {
            std::cout << "[bsa] Skipping non-canonical or supplemental "
                      << channel_name << " data tree key: " << kv.first << "\n";
            continue;
        }
        const std::string period_code = period_code_from_display(period);
        auto compile_for_channel = [&](const std::string& key) {
            CompiledSigmaCuts compiled = compile_sigma_cuts(sigma_cuts, key);

            // The direct-pi0 JSON uses the logical theta_gamma_gamma name,
            // while the corresponding ROOT branch is theta_pi0_pi0.
            if (cut_prefix == "eppi0") {
                for (CompiledSigmaCut& cut : compiled) {
                    if (cut.variable ==
                        CompiledSigmaCut::Variable::ThetaGammaGamma) {
                        cut.variable =
                            CompiledSigmaCut::Variable::ThetaPi0Pi0;
                    }
                }
            }

            return compiled;
        };

        tasks.push_back({
            kv.first,
            period,
            period_code,
            kv.second,
            {
                compile_for_channel(cut_prefix + "_" + period_code + "_FD_FD"),
                compile_for_channel(cut_prefix + "_" + period_code + "_CD_FD"),
                compile_for_channel(cut_prefix + "_" + period_code + "_CD_FT")
            }
        });
    }

    std::vector<CountTaskResult> results(tasks.size());
    std::vector<std::exception_ptr> errors(tasks.size());
    const int nthreads = std::max(1, std::min({7, max_workers, static_cast<int>(tasks.size())}));

    #pragma omp parallel for schedule(dynamic, 1) num_threads(nthreads)
    for (int task_index = 0; task_index < static_cast<int>(tasks.size()); ++task_index) {
        try {
            const CountTask& task = tasks[task_index];
            CountTaskResult local;
            local.counts.resize(rows.size());
            if (scramble_outputs && scramble_replicas > 0) {
                local.scramble_counts.resize(scramble_replicas);
                for (DenseCounts& dc : local.scramble_counts) dc.resize(rows.size());
            } //endif

            BranchBinder b;
            b.bind(task.tree);
        if (!(b.has_detector1 && b.has_detector2 && b.has_helicity && b.has_x &&
              b.has_Q2 && b.has_t1 && b.has_phi2) ||
            (scramble_outputs && scramble_replicas > 0 && !b.has_runnum)) {
            fatal("[bsa] " + channel_name + " tree " + task.tree_key +
                  " is missing one or more required branches: detector1, detector2, helicity, x, Q2, t1, phi2");
        }

        local.entries = static_cast<long long>(task.tree->GetEntries());
        for (Long64_t i = 0; i < static_cast<Long64_t>(local.entries); ++i) {
            task.tree->GetEntry(i);

            const TopologyIndex topo = topology_index(b.detector1, b.detector2);
            if (topo == TopologyIndex::INVALID) continue;
            if (!topology_passes_filter(topo, topology_filter)) continue;
            ++local.topology;

            if (!passes_global_cuts_dispatch(b, task.period)) continue;
            ++local.global;

            const int topo_i = static_cast<int>(topo);
            if (!passes_compiled_sigma_cuts(task.compiled_cuts[topo_i], b)) continue;
            ++local.sigma;

            const int ix = find_axis_bin_index(fast_bins.xbins, b.x);
            if (ix < 0) continue;
            const int iq = find_axis_bin_index(fast_bins.qbins, b.Q2);
            if (iq < 0) continue;
            const int it = find_axis_bin_index(fast_bins.tbins, b.t_abs());
            if (it < 0) continue;

            const double phi_deg = b.phi_deg();
            const std::vector<int>& candidate_rows = fast_bins.rows_by_xqt[ix][iq][it];
            bool matched = false;
            for (int row_index : candidate_rows) {
                const RowBin& rb = rows[row_index];
                if (!row_accepts_phi(phi_deg, rb.pmin, rb.pmax)) continue;
                add_event(local.counts[row_index], b.helicity);
                if (scramble_outputs && scramble_replicas > 0) {
                    const unsigned long long salt =
                        (cut_prefix == "DVCS") ? 0x44564353ULL : 0x504930ULL;
                    for (int rep = 0; rep < scramble_replicas; ++rep) {
                        const int h_scr = scrambled_helicity(
                            b.helicity, b.runnum, i, rep, scramble_seed, salt);
                        add_event(local.scramble_counts[rep][row_index], h_scr);
                    } //endfor
                } //endif
                matched = true;
            }
            if (matched) ++local.matched;
        }
            results[task_index] = std::move(local);
        } catch (...) {
            errors[task_index] = std::current_exception();
        }
    }

    for (const std::exception_ptr& error : errors) {
        if (error) std::rethrow_exception(error);
    }

    for (int task_index = 0; task_index < static_cast<int>(tasks.size()); ++task_index) {
        const CountTask& task = tasks[task_index];
        const CountTaskResult& local = results[task_index];
        RowCounts& period_counts = out[task.period];
        for (int r = 0; r < static_cast<int>(local.counts.size()); ++r) {
            const HelCounts& h = local.counts[r];
            if (h.plus == 0.0 && h.minus == 0.0) continue;
            HelCounts& dst = period_counts[r];
            dst.plus += h.plus;
            dst.minus += h.minus;
        }
        if (scramble_outputs && scramble_replicas > 0) {
            for (int rep = 0; rep < scramble_replicas; ++rep) {
                RowCounts& rep_period = (*scramble_outputs)[rep][task.period];
                for (int r = 0; r < static_cast<int>(local.scramble_counts[rep].size()); ++r) {
                    const HelCounts& h = local.scramble_counts[rep][r];
                    if (h.plus == 0.0 && h.minus == 0.0) continue;
                    HelCounts& dst = rep_period[r];
                    dst.plus += h.plus;
                    dst.minus += h.minus;
                } //endfor
            } //endfor
        } //endif

        std::cout << "[bsa] channel=" << channel_name
                  << " tree=" << task.tree_key
                  << " period=" << task.period
                  << " entries=" << local.entries
                  << " topology=" << local.topology
                  << " global=" << local.global
                  << " sigma=" << local.sigma
                  << " matched=" << local.matched
                  << "\n";
    }

    return out;
}

// -----------------------------------------------------------------------------
// Pi0 leakage factors
// -----------------------------------------------------------------------------

struct PeriodLeakRows {
    std::unordered_map<std::string, std::vector<double>> f_pi0;
    std::unordered_map<std::string, std::vector<double>> contamination;
};

static std::string first_existing_col(const CSV& csv, const std::vector<std::string>& names) {
    for (const std::string& n : names) {
        if (csv.index.count(n)) return n;
    } //endfor
    return "";
}

static bool sum_topology_columns_for_period_channel_unpol_preferred(const CSV& csv,
                                                                    int row_index,
                                                                    const std::string& channel,
                                                                    const std::string& period,
                                                                    double& sum_value) {
    sum_value = 0.0;
    bool found_any = false;

    auto try_helicity_set = [&](const std::vector<std::string>& helicities) {
        double local_sum = 0.0;
        bool local_found = false;

        for (const std::string& topo : csv_topology_labels()) {
            for (const std::string& hel : helicities) {
                const std::vector<std::string> candidates = {
                    "normalized raw yield, " + channel + ", " + topo + ", exp, " + period + ", " + hel,
                    "raw yield, " + channel + ", " + topo + ", exp, " + period + ", " + hel
                };

                for (const std::string& cname : candidates) {
                    const int c = col_optional(csv, cname);
                    if (c < 0) continue;

                    double v = 0.0;
                    if (parse_tuple_first(csv.rows[row_index][c], v)) {
                        local_sum += v;
                        local_found = true;
                        break;
                    } //endif
                } //endfor
            } //endfor
        } //endfor

        if (local_found) {
            sum_value = local_sum;
            found_any = true;
        } //endif
    };

    try_helicity_set({"unpol"});
    if (!found_any) try_helicity_set({"pos", "neg"});

    return found_any;
}

static bool period_has_any_channel_yield_columns(const CSV& csv,
                                                 const std::string& channel,
                                                 const std::string& period) {
    for (const std::string& topo : csv_topology_labels()) {
        for (const std::string& hel : {std::string("unpol"), std::string("pos"), std::string("neg")}) {
            const std::vector<std::string> candidates = {
                "normalized raw yield, " + channel + ", " + topo + ", exp, " + period + ", " + hel,
                "raw yield, " + channel + ", " + topo + ", exp, " + period + ", " + hel
            };
            for (const std::string& cname : candidates) {
                if (col_optional(csv, cname) >= 0) return true;
            } //endfor
        } //endfor
    } //endfor
    return false;
}

static PeriodLeakRows build_pi0_leakage(const CSV& csv, const BSAOptions& opt,
                                        PhotonTopologyFilter topology_filter = PhotonTopologyFilter::All) {
    PeriodLeakRows out;

    for (const std::string& period : base_period_order()) {
        const std::string c_contam_name = first_existing_col(csv, {
            "contamination ratio, " + period,
            "pi0 contamination ratio, " + period,
            "pi0 contamination, " + period
        });

        if (c_contam_name.empty()) {
            fatal("[bsa] could not find contamination-ratio CSV column for period " + period);
        } //endif
        if (!period_has_any_channel_yield_columns(csv, "ep->epg", period)) {
            fatal("[bsa] could not find any epgamma normalized/raw yield CSV columns for period " + period +
                  ". Expected columns like 'normalized raw yield, ep->epg, (FD, FD), exp, " + period + ", unpol'.");
        } //endif
        if (!period_has_any_channel_yield_columns(csv, "ep->eppi0", period)) {
            fatal("[bsa] could not find any eppi0 normalized/raw yield CSV columns for period " + period +
                  ". Expected columns like 'normalized raw yield, ep->eppi0, (FD, FD), exp, " + period + ", unpol'.");
        } //endif

        const int c_contam = col_strict(csv, c_contam_name);

        std::vector<double> f(csv.rows.size(), 0.0);
        std::vector<double> c(csv.rows.size(), 0.0);

        int n_valid = 0;
        for (int r = 0; r < static_cast<int>(csv.rows.size()); ++r) {
            double contam = 0.0;
            double epg_yield = 0.0;
            double pi0_yield = 0.0;

            bool ok_c = parse_tuple_first(csv.rows[r][c_contam], contam);
            bool ok_g = sum_topology_columns_for_period_channel_unpol_preferred(csv, r, "ep->epg", period, epg_yield);
            bool ok_p = sum_topology_columns_for_period_channel_unpol_preferred(csv, r, "ep->eppi0", period, pi0_yield);

            if (topology_filter == PhotonTopologyFilter::All) {
                if (ok_c && ok_g && ok_p && contam >= 0.0 && epg_yield > 0.0 && pi0_yield > 0.0) {
                    c[r] = contam;
                    f[r] = contam * epg_yield / pi0_yield;
                    ++n_valid;
                } //endif
            } else {
                // For a topology-separated BSA, use the topology-matched MC
                // leakage conversion f_pi0 = N_rec(eppi0->epg) / N_rec(eppi0).
                // This avoids applying the topology-summed contamination factor
                // to FD and FT samples, whose photon efficiencies differ.
                double mis = 0.0, rec = 0.0, data_g = 0.0, data_p = 0.0;
                bool have_mis = false, have_rec = false, have_g = false, have_p = false;
                for (const std::string& topo : csv_topology_labels()) {
                    const bool is_ft = (topo == "(CD, FT)");
                    if (topology_filter == PhotonTopologyFilter::FDPhoton && is_ft) continue;
                    if (topology_filter == PhotonTopologyFilter::FTPhoton && !is_ft) continue;
                    auto add_tuple = [&](const std::string& name, double& sum, bool& have) {
                        const int ci = col_optional(csv, name);
                        double v = 0.0;
                        if (ci >= 0 && parse_tuple_first(csv.rows[r][ci], v) && v >= 0.0) {
                            sum += v; have = true;
                        } //endif
                    };
                    add_tuple("reconstructed current corrected yield, ep->eppi0->epg, " + topo + ", mc, " + period, mis, have_mis);
                    add_tuple("reconstructed current corrected yield, ep->eppi0, " + topo + ", mc, " + period, rec, have_rec);
                    add_tuple("normalized raw yield, ep->epg, " + topo + ", exp, " + period + ", unpol", data_g, have_g);
                    add_tuple("normalized raw yield, ep->eppi0, " + topo + ", exp, " + period + ", unpol", data_p, have_p);
                } //endfor
                if (have_mis && have_rec && rec > 0.0) {
                    f[r] = mis / rec;
                    if (have_g && have_p && data_g > 0.0) c[r] = f[r] * data_p / data_g;
                    ++n_valid;
                } //endif
            } //endif

            if (!opt.enable_pi0_subtraction) {
                c[r] = 0.0;
                f[r] = 0.0;
            } //endif
        } //endfor

        out.f_pi0[period] = std::move(f);
        out.contamination[period] = std::move(c);

        std::cout << "[bsa] pi0 leakage scale factors for " << period
                  << ": valid rows=" << n_valid << "/" << csv.rows.size()
                  << " using contamination column '" << c_contam_name
                  << "' and "
                  << (topology_filter == PhotonTopologyFilter::All
                      ? "summed-topology data yields"
                      : "topology-matched eppi0 MC leakage yields")
                  << ".\n";
    } //endfor

    return out;
}

// -----------------------------------------------------------------------------
// BSA math
// -----------------------------------------------------------------------------

struct AsymResult {
    bool valid = false;
    double value = 0.0;
    double stat = 0.0;

    bool raw_valid = false;
    double raw_value = 0.0;
    double raw_stat = 0.0;

    bool pi0_valid = false;
    double pi0_value = 0.0;
    double pi0_stat = 0.0;

    double g_plus = 0.0;
    double g_minus = 0.0;
    double p_plus = 0.0;
    double p_minus = 0.0;
    double s_plus = 0.0;
    double s_minus = 0.0;

    double f_pi0_effective = 0.0;
    double contamination_ratio_effective = 0.0;
    double polarized_denominator = 0.0;

    // Absolute point-to-point uncertainty from the established relative
    // uncertainty on the pi0 leakage scale factor.
    double pi0_subtraction_sys = 0.0;
};

struct ComponentForVariance {
    double pol = 0.0;
    double s_plus = 0.0;
    double s_minus = 0.0;
    double var_s_plus = 0.0;
    double var_s_minus = 0.0;
};

static HelCounts get_counts_for_row(const PeriodCounts& counts,
                                    const std::string& period,
                                    int row_index) {
    auto ip = counts.find(period);
    if (ip == counts.end()) return {};
    auto ir = ip->second.find(row_index);
    if (ir == ip->second.end()) return {};
    return ir->second;
}

static double get_vector_value(const std::unordered_map<std::string, std::vector<double>>& m,
                               const std::string& period,
                               int row_index) {
    auto ip = m.find(period);
    if (ip == m.end()) return 0.0;
    if (row_index < 0 || row_index >= static_cast<int>(ip->second.size())) return 0.0;
    const double v = ip->second[row_index];
    if (!std::isfinite(v) || v < 0.0) return 0.0;
    return v;
}

static AsymResult compute_group_bsa(const PeriodCounts& gamma_counts,
                                    const PeriodCounts& pi0_counts,
                                    const PeriodLeakRows& leaks,
                                    const std::vector<std::string>& component_periods,
                                    int row_index,
                                    const BSAOptions& opt,
                                    double pi0_leakage_scale = 1.0) {
    AsymResult r;

    double numerator = 0.0;
    double denominator = 0.0;
    double variance = 0.0;

    double raw_num = 0.0;
    double raw_den = 0.0;
    double raw_var_num = 0.0;

    double pi0_num = 0.0;
    double pi0_den = 0.0;
    double pi0_var_num = 0.0;

    double weighted_f_num = 0.0;
    double weighted_c_num = 0.0;
    double weight_sum = 0.0;

    std::vector<ComponentForVariance> comps;

    for (const std::string& period : component_periods) {
        const HelCounts g = get_counts_for_row(gamma_counts, period, row_index);
        const HelCounts p = get_counts_for_row(pi0_counts, period, row_index);
        const double pol = beam_pol_for_period(period, opt);
        const double f = opt.enable_pi0_subtraction
            ? pi0_leakage_scale * get_vector_value(leaks.f_pi0, period, row_index)
            : 0.0;
        const double c = opt.enable_pi0_subtraction ? get_vector_value(leaks.contamination, period, row_index) : 0.0;

        const double gp = g.plus;
        const double gm = g.minus;
        const double pp = p.plus;
        const double pm = p.minus;
        const double sp = gp - f * pp;
        const double sm = gm - f * pm;

        r.g_plus += gp;
        r.g_minus += gm;
        r.p_plus += pp;
        r.p_minus += pm;
        r.s_plus += sp;
        r.s_minus += sm;

        const double raw_s = gp + gm;
        const double raw_d = gp - gm;
        if (raw_s > 0.0) {
            raw_num += raw_d;
            raw_den += pol * raw_s;
            raw_var_num += std::max(0.0, raw_s - raw_d * raw_d / raw_s);
        } //endif

        const double pi0_s = pp + pm;
        const double pi0_d = pp - pm;
        if (pi0_s > 0.0) {
            pi0_num += pi0_d;
            pi0_den += pol * pi0_s;
            pi0_var_num += std::max(0.0, pi0_s - pi0_d * pi0_d / pi0_s);
        } //endif

        const double sig_s = sp + sm;
        const double sig_d = sp - sm;
        if (sig_s > 0.0) {
            numerator += sig_d;
            denominator += pol * sig_s;
            comps.push_back(ComponentForVariance{pol, sp, sm, gp + f * f * pp, gm + f * f * pm});
            weighted_f_num += f * sig_s;
            weighted_c_num += c * sig_s;
            weight_sum += sig_s;
        } //endif
    } //endfor

    if (raw_den > 0.0) {
        r.raw_value = raw_num / raw_den;
        r.raw_stat = std::sqrt(std::max(0.0, raw_var_num)) / raw_den;
        r.raw_valid = std::isfinite(r.raw_value) && std::isfinite(r.raw_stat);
    } //endif

    if (pi0_den > 0.0) {
        r.pi0_value = pi0_num / pi0_den;
        r.pi0_stat = std::sqrt(std::max(0.0, pi0_var_num)) / pi0_den;
        r.pi0_valid = std::isfinite(r.pi0_value) && std::isfinite(r.pi0_stat);
    } //endif

    r.polarized_denominator = denominator;
    if (weight_sum > 0.0) {
        r.f_pi0_effective = weighted_f_num / weight_sum;
        r.contamination_ratio_effective = weighted_c_num / weight_sum;
    } //endif

    if (!(denominator > 0.0)) return r;

    r.value = numerator / denominator;
    for (const ComponentForVariance& comp : comps) {
        const double dA_dSp = (denominator - numerator * comp.pol) / (denominator * denominator);
        const double dA_dSm = (-denominator - numerator * comp.pol) / (denominator * denominator);
        variance += dA_dSp * dA_dSp * comp.var_s_plus;
        variance += dA_dSm * dA_dSm * comp.var_s_minus;
    } //endfor

    r.stat = std::sqrt(std::max(0.0, variance));
    r.valid = std::isfinite(r.value) && std::isfinite(r.stat);
    return r;
}

static std::string fmt_tuple(double value, double stat) {
    if (!(std::isfinite(value) && std::isfinite(stat))) return "";
    std::ostringstream ss;
    ss << std::setprecision(12) << "(" << value << "," << stat << ",0)";
    return ss.str();
}

static bool topology_result_is_usable(const AsymResult& a,
                                      double min_corrected_events) {
    const double corrected = a.s_plus + a.s_minus;
    return a.valid && std::isfinite(a.value) && std::isfinite(a.stat) &&
           a.stat > 0.0 && a.s_plus > 0.0 && a.s_minus > 0.0 &&
           corrected >= min_corrected_events;
}

struct PullAccumulator {
    int n = 0;
    int n_abs_gt2 = 0;
    double sum = 0.0;
    double sum2 = 0.0;
    void add(double x) {
        if (!std::isfinite(x)) return;
        ++n; sum += x; sum2 += x*x;
        if (std::abs(x) > 2.0) ++n_abs_gt2;
    }
};

static void write_topology_summary_csv(
    const std::string& path,
    const std::vector<RowBin>& rows,
    const std::map<std::string, std::vector<AsymResult>>& fd_results,
    const std::map<std::string, std::vector<AsymResult>>& ft_results,
    double min_corrected_events) {
    const std::filesystem::path p(path);
    std::filesystem::create_directories(p.parent_path());
    std::ofstream out(path);
    if (!out.is_open()) fatal("[bsa] cannot write topology summary CSV: " + path);
    out << "group,row,xBmin,xBmax,Q2min,Q2max,tmin,tmax,phimin,phimax,"
           "A_FD,stat_FD,Ncorr_FD,A_FT,stat_FT,Ncorr_FT,"
           "valid_comparison,delta_FD_minus_FT,pull_FD_minus_FT\n";

    // Keep every row in the diagnostic CSV, but only form a pull when both
    // topology measurements satisfy the explicit statistics/positivity test.
    for (const std::string& group : output_group_order()) {
        const auto& fd = fd_results.at(group);
        const auto& ft = ft_results.at(group);
        for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
            if (!rows[r].valid) continue;
            const bool fd_ok = topology_result_is_usable(fd[r], min_corrected_events);
            const bool ft_ok = topology_result_is_usable(ft[r], min_corrected_events);
            const bool usable = fd_ok && ft_ok;
            const double delta = usable ? fd[r].value - ft[r].value
                                        : std::numeric_limits<double>::quiet_NaN();
            const double den = usable ? std::hypot(fd[r].stat, ft[r].stat) : 0.0;
            const double pull = (usable && den > 0.0) ? delta / den
                                                      : std::numeric_limits<double>::quiet_NaN();
            const RowBin& b = rows[r];
            out << group << ',' << r << ',' << b.xBmin << ',' << b.xBmax << ','
                << b.Q2min << ',' << b.Q2max << ',' << b.tmin << ',' << b.tmax << ','
                << b.pmin << ',' << b.pmax << ',';
            if (fd[r].valid) out << fd[r].value << ',' << fd[r].stat << ','
                                 << (fd[r].s_plus + fd[r].s_minus);
            out << ',';
            if (ft[r].valid) out << ft[r].value << ',' << ft[r].stat << ','
                                 << (ft[r].s_plus + ft[r].s_minus);
            out << ',' << (usable ? 1 : 0) << ',';
            if (usable) out << delta << ',' << pull;
            out << '\n';
        } //endfor
    } //endfor

    // Differential pull summary.  This is deliberately a diagnostic rather
    // than a new systematic: it exposes any FD/FT dependence versus each of
    // the four analysis coordinates.
    const std::filesystem::path summary_path = p.parent_path() / "bsa_fd_vs_ft_differential_summary.csv";
    std::ofstream sum(summary_path);
    if (!sum.is_open()) fatal("[bsa] cannot write topology differential summary CSV");
    sum << "group,axis,bin_min,bin_max,n,mean_pull,rms_pull,fraction_abs_pull_gt2\n";
    for (const std::string& group : output_group_order()) {
        const auto& fd = fd_results.at(group);
        const auto& ft = ft_results.at(group);
        for (int axis = 0; axis < 4; ++axis) {
            std::map<std::pair<double,double>, PullAccumulator> acc;
            for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
                if (!rows[r].valid ||
                    !topology_result_is_usable(fd[r], min_corrected_events) ||
                    !topology_result_is_usable(ft[r], min_corrected_events)) continue;
                const double den = std::hypot(fd[r].stat, ft[r].stat);
                if (!(den > 0.0)) continue;
                const double pull = (fd[r].value - ft[r].value) / den;
                std::pair<double,double> key;
                if (axis == 0) key = {rows[r].xBmin, rows[r].xBmax};
                else if (axis == 1) key = {rows[r].Q2min, rows[r].Q2max};
                else if (axis == 2) key = {rows[r].tmin, rows[r].tmax};
                else key = {rows[r].pmin, rows[r].pmax};
                acc[key].add(pull);
            } //endfor
            const char* axis_name = axis == 0 ? "xB" : axis == 1 ? "Q2" : axis == 2 ? "t_abs" : "phi";
            for (const auto& kv : acc) {
                const PullAccumulator& a = kv.second;
                if (a.n == 0) continue;
                const double mean = a.sum / a.n;
                const double rms = std::sqrt(std::max(0.0, a.sum2 / a.n - mean*mean));
                sum << group << ',' << axis_name << ',' << kv.first.first << ',' << kv.first.second << ','
                    << a.n << ',' << mean << ',' << rms << ','
                    << static_cast<double>(a.n_abs_gt2) / a.n << '\n';
            } //endfor
        } //endfor
    } //endfor
}

static void write_scramble_summary_csv(
    const std::string& path,
    const std::vector<RowBin>& rows,
    const std::map<std::string, std::vector<AsymResult>>& nominal,
    const std::vector<std::map<std::string, std::vector<AsymResult>>>& replicas) {
    const std::filesystem::path p(path);
    std::filesystem::create_directories(p.parent_path());
    std::ofstream out(path);
    if (!out.is_open()) fatal("[bsa] cannot write helicity-scramble summary CSV: " + path);
    out << "group,row,xBmin,xBmax,Q2min,Q2max,tmin,tmax,phimin,phimax,"
           "A_nominal,stat_nominal,scramble_mean,scramble_rms,mean_over_stat,rms_over_stat,n_valid\n";
    for (const std::string& group : output_group_order()) {
        for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
            if (!rows[r].valid || !nominal.at(group)[r].valid) continue;
            std::vector<double> vals;
            for (const auto& rep : replicas) {
                const AsymResult& a = rep.at(group)[r];
                if (a.valid) vals.push_back(a.value);
            } //endfor
            if (vals.size() < 2) continue;
            double mean = 0.0;
            for (double v : vals) mean += v;
            mean /= static_cast<double>(vals.size());
            double var = 0.0;
            for (double v : vals) var += (v - mean) * (v - mean);
            var /= static_cast<double>(vals.size() - 1);
            const double rms = std::sqrt(std::max(0.0, var));
            const double stat = nominal.at(group)[r].stat;
            const RowBin& b = rows[r];
            out << group << ',' << r << ',' << b.xBmin << ',' << b.xBmax << ','
                << b.Q2min << ',' << b.Q2max << ',' << b.tmin << ',' << b.tmax << ','
                << b.pmin << ',' << b.pmax << ',' << nominal.at(group)[r].value << ',' << stat << ','
                << mean << ',' << rms << ','
                << (stat > 0.0 ? mean / stat : 0.0) << ','
                << (stat > 0.0 ? rms / stat : 0.0) << ',' << vals.size() << '\n';
        } //endfor
    } //endfor
}

// -----------------------------------------------------------------------------
// JSON and plotting
// -----------------------------------------------------------------------------

static void write_json_summary(const std::string& path,
                               const std::vector<RowBin>& rows,
                               const std::map<std::string, std::vector<AsymResult>>& results) {
    nlohmann::json j;
    j["description"] = "Pi0-subtracted direct-count DVCS beam-spin asymmetries after global cuts and data exclusivity cuts.";
    j["estimator"] = "A_LU = sum_i(Splus_i - Sminus_i) / sum_i[Pbeam_i*(Splus_i + Sminus_i)], S± = G± - f_pi0*P±";

    for (const auto& group_pair : results) {
        const std::string& group = group_pair.first;
        const auto& vec = group_pair.second;
        nlohmann::json rows_json = nlohmann::json::array();

        for (int r = 0; r < static_cast<int>(vec.size()); ++r) {
            const AsymResult& a = vec[r];
            const RowBin& rb = rows[r];

            nlohmann::json row;
            row["row"] = r;
            row["xBmin"] = rb.xBmin;
            row["xBmax"] = rb.xBmax;
            row["Q2min"] = rb.Q2min;
            row["Q2max"] = rb.Q2max;
            row["t_abs_min"] = rb.tmin;
            row["t_abs_max"] = rb.tmax;
            row["phimin"] = rb.pmin;
            row["phimax"] = rb.pmax;
            row["valid"] = a.valid;
            row["Gplus"] = a.g_plus;
            row["Gminus"] = a.g_minus;
            row["Pplus"] = a.p_plus;
            row["Pminus"] = a.p_minus;
            row["Splus"] = a.s_plus;
            row["Sminus"] = a.s_minus;
            row["f_pi0_effective"] = a.f_pi0_effective;
            row["contamination_ratio_effective"] = a.contamination_ratio_effective;
            row["polarized_denominator"] = a.polarized_denominator;
            row["raw_epg_valid"] = a.raw_valid;
            row["pi0_valid"] = a.pi0_valid;

            if (a.valid) {
                row["BSA_pi0_subtracted"] = a.value;
                row["BSA_pi0_subtracted_stat"] = a.stat;
                row["BSA_pi0_subtraction_sys"] = a.pi0_subtraction_sys;
            } //endif
            if (a.raw_valid) {
                row["BSA_raw_epg"] = a.raw_value;
                row["BSA_raw_epg_stat"] = a.raw_stat;
            } //endif
            if (a.pi0_valid) {
                row["BSA_measured_eppi0"] = a.pi0_value;
                row["BSA_measured_eppi0_stat"] = a.pi0_stat;
            } //endif

            rows_json.push_back(row);
        } //endfor

        j["groups"][group] = rows_json;
    } //endfor

    const std::filesystem::path p(path);
    std::filesystem::create_directories(p.parent_path());

    std::ofstream fout(path);
    if (!fout.is_open()) fatal("[bsa] cannot write JSON summary: " + path);
    fout << std::setw(2) << j << "\n";
}

struct BinRange {
    double lo = 0.0;
    double hi = 0.0;

    bool operator<(const BinRange& o) const {
        if (lo != o.lo) return lo < o.lo;
        return hi < o.hi;
    }
};

static std::string range_token(const char* prefix, const BinRange& r) {
    return Form("%s_%g_%g", prefix, r.lo, r.hi);
}

static bool same_range(double lo1, double hi1, const BinRange& r) {
    return lo1 == r.lo && hi1 == r.hi;
}

static inline double range_center(const BinRange& r) {
    return 0.5 * (r.lo + r.hi);
}


struct BSAPanel {
    BinRange q2;
    BinRange tabs;
    std::vector<double> x;
    std::vector<double> y;
    std::vector<double> ex;
    std::vector<double> ey;
};

static void draw_bsa_frame(bool left_col, bool bottom_row) {
    TH1F* frame = static_cast<TH1F*>(gPad->DrawFrame(0.0, -1.0, 360.0, 1.0, ""));
    frame->GetXaxis()->SetTitle(bottom_row ? "#phi (deg)" : "");
    frame->GetYaxis()->SetTitle(left_col ? "A_{LU}" : "");
    frame->GetXaxis()->CenterTitle();
    frame->GetYaxis()->CenterTitle();
    frame->GetXaxis()->SetNdivisions(505);
    frame->GetYaxis()->SetNdivisions(505);
    frame->GetXaxis()->SetTitleSize(bottom_row ? 0.060 : 0.0);
    frame->GetYaxis()->SetTitleSize(left_col ? 0.065 : 0.0);
    frame->GetXaxis()->SetLabelSize(bottom_row ? 0.050 : 0.0);
    frame->GetYaxis()->SetLabelSize(left_col ? 0.050 : 0.0);
    frame->GetXaxis()->SetTitleOffset(1.10);
    frame->GetYaxis()->SetTitleOffset(1.25);
}

static int choose_bsa_ncols(int n_pads) {
    if (n_pads <= 0) return 1;
    if (n_pads <= 3) return n_pads;
    if (n_pads <= 6) return 3;
    if (n_pads <= 12) return 4;
    if (n_pads <= 20) return 5;
    return 6;
}

static void make_bsa_plots(const std::string& output_root,
                           const std::vector<RowBin>& rows,
                           const std::map<std::string, std::vector<AsymResult>>& results) {
    const std::filesystem::path base = std::filesystem::path(output_root) / "bsa_plots";
    std::filesystem::create_directories(base);

    std::set<BinRange> xB_set;
    for (const RowBin& rb : rows) {
        if (!rb.valid) continue;
        xB_set.insert(BinRange{rb.xBmin, rb.xBmax});
    } //endfor

    std::vector<BinRange> xB_bins(xB_set.begin(), xB_set.end());
    if (xB_bins.empty()) {
        std::cerr << "[bsa] WARNING: no valid xB bin ranges found; skipping BSA plots.\n";
        return;
    } //endif

    gROOT->SetBatch(true);
    gStyle->SetOptStat(0);
    gStyle->SetOptTitle(0);
    gStyle->SetTitleFont(42, "XYZ");
    gStyle->SetLabelFont(42, "XYZ");
    gStyle->SetTextFont(42);
    gStyle->SetLineWidth(2);
    gStyle->SetFrameLineWidth(2);
    gStyle->SetPadTickX(1);
    gStyle->SetPadTickY(1);

    for (const auto& group_pair : results) {
        const std::string& group = group_pair.first;
        const std::vector<AsymResult>& vec = group_pair.second;
        const std::filesystem::path out_dir = base / sanitize_token(group);
        std::filesystem::create_directories(out_dir);

        int canvas_count = 0;
        for (const BinRange& xbr : xB_bins) {
            std::map<std::pair<BinRange, BinRange>, BSAPanel> panel_map;

            for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
                if (!rows[r].valid || r >= static_cast<int>(vec.size())) continue;
                if (!vec[r].valid) continue;
                if (!same_range(rows[r].xBmin, rows[r].xBmax, xbr)) continue;

                const BinRange q2{rows[r].Q2min, rows[r].Q2max};
                const BinRange tt{rows[r].tmin, rows[r].tmax};
                auto key = std::make_pair(q2, tt);

                BSAPanel& panel = panel_map[key];
                panel.q2 = q2;
                panel.tabs = tt;
                panel.x.push_back(phi_center_deg(rows[r].pmin, rows[r].pmax));
                panel.y.push_back(vec[r].value);
                panel.ex.push_back(phi_half_width_deg(rows[r].pmin, rows[r].pmax));
                panel.ey.push_back(vec[r].stat);
            } //endfor

            std::vector<BSAPanel> panels;
            panels.reserve(panel_map.size());
            for (auto& kv : panel_map) {
                if (kv.second.x.empty()) continue;

                std::vector<size_t> order(kv.second.x.size());
                for (size_t i = 0; i < order.size(); ++i) order[i] = i;
                std::sort(order.begin(), order.end(), [&](size_t a, size_t b) {
                    return kv.second.x[a] < kv.second.x[b];
                });

                BSAPanel sorted;
                sorted.q2 = kv.second.q2;
                sorted.tabs = kv.second.tabs;
                for (size_t idx : order) {
                    sorted.x.push_back(kv.second.x[idx]);
                    sorted.y.push_back(kv.second.y[idx]);
                    sorted.ex.push_back(kv.second.ex[idx]);
                    sorted.ey.push_back(kv.second.ey[idx]);
                } //endfor
                panels.push_back(std::move(sorted));
            } //endfor

            if (panels.empty()) continue;

            // Sort panels in the same visual order as the cross-section canvases:
            // increasing |t| row by row, with increasing Q2 across each row.
            std::sort(panels.begin(), panels.end(), [](const BSAPanel& a, const BSAPanel& b) {
                if (std::abs(a.tabs.lo - b.tabs.lo) > 1e-9) return a.tabs.lo < b.tabs.lo;
                if (std::abs(a.tabs.hi - b.tabs.hi) > 1e-9) return a.tabs.hi < b.tabs.hi;
                if (std::abs(a.q2.lo - b.q2.lo) > 1e-9) return a.q2.lo < b.q2.lo;
                return a.q2.hi < b.q2.hi;
            });

            const int n_pads = static_cast<int>(panels.size());
            const int n_cols = choose_bsa_ncols(n_pads);
            const int n_rows = (n_pads + n_cols - 1) / n_cols;

            int canvas_w = 280 * n_cols + 160;
            int canvas_h = 260 * n_rows + 150;
            if (canvas_w < 900) canvas_w = 900;
            if (canvas_h < 650) canvas_h = 650;

            // This title is drawn inside the top header pad. TLatex text size is
            // relative to the current pad, not the full canvas, so the title
            // size must be much larger than the per-panel label sizes.
            double title_size = 0.285;
            double panel_label_size = 0.060;
            if (n_pads <= 4) {
                title_size = 0.260;
                panel_label_size = 0.055;
            }
            if (n_pads == 1) {
                title_size = 0.240;
                panel_label_size = 0.050;
            }

            TCanvas c("c_bsa_compact", "", canvas_w, canvas_h);

            TPad* pTop = new TPad("pTop", "pTop", 0.0, 0.88, 1.0, 1.0);
            pTop->SetFillStyle(0);
            pTop->SetBorderSize(0);
            pTop->Draw();

            TPad* pGrid = new TPad("pGrid", "pGrid", 0.0, 0.0, 1.0, 0.88);
            pGrid->SetFillStyle(0);
            pGrid->SetBorderSize(0);
            pGrid->Draw();
            pGrid->cd();
            pGrid->Divide(n_cols, n_rows, 0.0001, 0.0001);

            pTop->cd();
            TLatex head;
            head.SetNDC();
            head.SetTextAlign(22);
            head.SetTextFont(42);
            head.SetTextSize(title_size);
            head.DrawLatex(
                0.5, 0.52,
                Form("#pi^{0}-subtracted ep#gamma BSA   %s   x_{B} in (%.3f, %.3f)",
                     group.c_str(), xbr.lo, xbr.hi)
            );

            std::vector<std::unique_ptr<TGraphErrors>> owned_graphs;
            std::vector<std::unique_ptr<TLine>> owned_lines;

            for (int ip = 0; ip < n_pads; ++ip) {
                const int row = ip / n_cols;
                const int col = ip % n_cols;
                const bool left_col = (col == 0);
                const bool bottom_row = (row == n_rows - 1);

                pGrid->cd(ip + 1);
                gPad->SetGrid(1, 1);
                gPad->SetTickx(1);
                gPad->SetTicky(1);
                gPad->SetTopMargin(0.12);
                gPad->SetBottomMargin(bottom_row ? 0.18 : 0.10);
                gPad->SetLeftMargin(left_col ? 0.16 : 0.09);
                gPad->SetRightMargin(0.06);

                draw_bsa_frame(left_col, bottom_row);

                auto zero = std::make_unique<TLine>(0.0, 0.0, 360.0, 0.0);
                zero->SetLineStyle(2);
                zero->SetLineWidth(1);
                zero->SetLineColor(kGray + 2);
                zero->Draw("SAME");

                const BSAPanel& panel = panels[ip];
                auto gr = std::make_unique<TGraphErrors>(
                    static_cast<int>(panel.x.size()),
                    panel.x.data(), panel.y.data(), panel.ex.data(), panel.ey.data());
                gr->SetName(Form("gr_bsa_%d", ip));
                gr->SetMarkerStyle(20);
                gr->SetMarkerSize(0.75);
                gr->SetMarkerColor(kBlack);
                gr->SetLineColor(kBlack);
                gr->SetLineWidth(1);
                gr->Draw("P SAME");

                TLatex lab;
                lab.SetNDC();
                lab.SetTextFont(42);
                lab.SetTextAlign(11);
                lab.SetTextSize(panel_label_size);
                lab.DrawLatex(
                    0.14, 0.93,
                    Form("Q^{2} in (%.2f, %.2f), |t| in (%.2f, %.2f)",
                         panel.q2.lo, panel.q2.hi, panel.tabs.lo, panel.tabs.hi)
                );

                owned_lines.push_back(std::move(zero));
                owned_graphs.push_back(std::move(gr));
            } //endfor

            const std::string name =
                (out_dir / Form("bsa_%s_%s.png",
                                sanitize_token(group).c_str(),
                                range_token("xB", xbr).c_str())).string();
            c.SaveAs(name.c_str());
            ++canvas_count;
        } //endfor

        std::cout << "[bsa] Wrote " << canvas_count
                  << " compact BSA canvases for group " << group
                  << " to " << out_dir.string() << "\n";
    } //endfor
}

} // namespace

bool update_bsa_counts_csv(const std::map<std::string, TTree*>& dvcsDataTrees,
                           const std::map<std::string, TTree*>& eppi0DataTrees,
                           const BSAOptions& options) {
    try {
        CSV csv;
        load_csv(options.csv_path, csv);

        const std::vector<RowBin> rows = load_row_bins_from_csv(csv);
        const FastBinning fast_bins = build_fast_binning(rows);
        const TopoCutMap sigma_cuts = load_combined_cuts(options.combined_cuts_json);
        const PeriodLeakRows leaks = build_pi0_leakage(csv, options);
        PeriodLeakRows leaks_fd, leaks_ft;
        if (options.make_photon_topology_study) {
            leaks_fd = build_pi0_leakage(csv, options, PhotonTopologyFilter::FDPhoton);
            leaks_ft = build_pi0_leakage(csv, options, PhotonTopologyFilter::FTPhoton);
        } //endif

        std::vector<PeriodCounts> gamma_scrambles;
        std::vector<PeriodCounts> pi0_scrambles;
        const int n_scrambles = options.make_helicity_scrambling_study
            ? std::max(0, options.helicity_scramble_replicas) : 0;
        const PeriodCounts gamma_counts =
            accumulate_counts(dvcsDataTrees, "DVCS", "DVCS", rows, fast_bins, sigma_cuts,
                              options.max_workers, PhotonTopologyFilter::All,
                              n_scrambles > 0 ? &gamma_scrambles : nullptr, n_scrambles,
                              options.helicity_scramble_seed);
        const PeriodCounts pi0_counts =
            accumulate_counts(eppi0DataTrees, "eppi0", "eppi0", rows, fast_bins, sigma_cuts,
                              options.max_workers, PhotonTopologyFilter::All,
                              n_scrambles > 0 ? &pi0_scrambles : nullptr, n_scrambles,
                              options.helicity_scramble_seed);

        PeriodCounts gamma_fd_counts, gamma_ft_counts, pi0_fd_counts, pi0_ft_counts;
        if (options.make_photon_topology_study) {
            std::cout << "[bsa] Building independent FD-photon and FT-photon BSA samples.\n";
            gamma_fd_counts = accumulate_counts(
                dvcsDataTrees, "DVCS FD-photon", "DVCS", rows, fast_bins, sigma_cuts,
                options.max_workers, PhotonTopologyFilter::FDPhoton);
            gamma_ft_counts = accumulate_counts(
                dvcsDataTrees, "DVCS FT-photon", "DVCS", rows, fast_bins, sigma_cuts,
                options.max_workers, PhotonTopologyFilter::FTPhoton);
            pi0_fd_counts = accumulate_counts(
                eppi0DataTrees, "eppi0 FD-photon", "eppi0", rows, fast_bins, sigma_cuts,
                options.max_workers, PhotonTopologyFilter::FDPhoton);
            pi0_ft_counts = accumulate_counts(
                eppi0DataTrees, "eppi0 FT-photon", "eppi0", rows, fast_bins, sigma_cuts,
                options.max_workers, PhotonTopologyFilter::FTPhoton);
        } //endif

        std::map<std::string, std::vector<AsymResult>> results;
        for (const std::string& group : output_group_order()) {
            const std::vector<std::string> components = component_periods_for_group(group);
            std::vector<AsymResult> group_results(rows.size());

            for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
                if (!rows[r].valid) continue;
                group_results[r] =
                    compute_group_bsa(gamma_counts, pi0_counts, leaks, components, r, options);

                if (group_results[r].valid && options.enable_pi0_subtraction &&
                    options.pi0_leakage_relative_uncertainty > 0.0) {
                    const double rel = options.pi0_leakage_relative_uncertainty;
                    const AsymResult lo = compute_group_bsa(
                        gamma_counts, pi0_counts, leaks, components, r, options, 1.0 - rel);
                    const AsymResult hi = compute_group_bsa(
                        gamma_counts, pi0_counts, leaks, components, r, options, 1.0 + rel);
                    if (lo.valid && hi.valid) {
                        group_results[r].pi0_subtraction_sys =
                            0.5 * std::abs(hi.value - lo.value);
                    } //endif
                } //endif
            } //endfor

            results[group] = std::move(group_results);
        } //endfor

        if (n_scrambles > 0) {
            std::vector<std::map<std::string, std::vector<AsymResult>>> scramble_results;
            scramble_results.resize(n_scrambles);
            for (int rep = 0; rep < n_scrambles; ++rep) {
                for (const std::string& group : output_group_order()) {
                    const auto components = component_periods_for_group(group);
                    auto& vec = scramble_results[rep][group];
                    vec.resize(rows.size());
                    for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
                        if (!rows[r].valid) continue;
                        vec[r] = compute_group_bsa(
                            gamma_scrambles[rep], pi0_scrambles[rep], leaks, components, r, options);
                    } //endfor
                } //endfor
            } //endfor
            const std::filesystem::path scramble_csv =
                std::filesystem::path(options.output_root) / "bsa_studies" / "helicity_scrambling_summary.csv";
            write_scramble_summary_csv(scramble_csv.string(), rows, results, scramble_results);
            std::cout << "[bsa] Wrote " << n_scrambles
                      << "-replica helicity-scrambling null study to "
                      << scramble_csv.string() << "\n";
        } //endif

        if (options.make_photon_topology_study) {
            std::map<std::string, std::vector<AsymResult>> fd_results;
            std::map<std::string, std::vector<AsymResult>> ft_results;
            for (const std::string& group : output_group_order()) {
                const auto components = component_periods_for_group(group);
                fd_results[group].resize(rows.size());
                ft_results[group].resize(rows.size());
                for (int r = 0; r < static_cast<int>(rows.size()); ++r) {
                    if (!rows[r].valid) continue;
                    fd_results[group][r] = compute_group_bsa(
                        gamma_fd_counts, pi0_fd_counts, leaks_fd, components, r, options);
                    ft_results[group][r] = compute_group_bsa(
                        gamma_ft_counts, pi0_ft_counts, leaks_ft, components, r, options);
                } //endfor
            } //endfor
            const std::filesystem::path topo_csv =
                std::filesystem::path(options.output_root) / "bsa_studies" / "bsa_fd_vs_ft.csv";
            write_topology_summary_csv(topo_csv.string(), rows, fd_results, ft_results,
                                       options.topology_study_min_corrected_events);
            std::cout << "[bsa] Wrote FD-vs-FT photon topology study to "
                      << topo_csv.string() << "\n";
            if (options.make_plots) {
                make_bsa_plots((std::filesystem::path(options.output_root) / "bsa_studies/FD_photon").string(), rows, fd_results);
                make_bsa_plots((std::filesystem::path(options.output_root) / "bsa_studies/FT_photon").string(), rows, ft_results);
            } //endif
        } //endif

        for (const std::string& group : output_group_order()) {
            const std::string col_name = "BSA, counts, " + group;
            const int c = col_strict(csv, col_name);
            const int c_pi0_sys = ensure_col(csv, col_name + ", pi0 subtraction sys");
            const auto& vec = results.at(group);

            for (int r = 0; r < static_cast<int>(csv.rows.size()); ++r) {
                if (r >= static_cast<int>(vec.size()) || !vec[r].valid) {
                    csv.rows[r][c].clear();
                    csv.rows[r][c_pi0_sys].clear();
                    continue;
                } //endif
                csv.rows[r][c] = fmt_tuple(vec[r].value, vec[r].stat);
                csv.rows[r][c_pi0_sys] = std::to_string(vec[r].pi0_subtraction_sys);
            } //endfor
        } //endfor

        write_csv_atomic(options.csv_path, csv);
        std::cout << "[bsa] Updated BSA count columns in " << options.csv_path << "\n";

        const std::filesystem::path json_path =
            std::filesystem::path(options.output_root) / "jsons" / "BSA_counts" / "bsa_counts_summary.json";
        write_json_summary(json_path.string(), rows, results);
        std::cout << "[bsa] Wrote JSON summary to " << json_path.string() << "\n";

        if (options.make_plots) {
            make_bsa_plots(options.output_root, rows, results);
        } //endif

        return true;
    } catch (const std::exception& e) {
        std::cerr << "[bsa] ERROR: " << e.what() << "\n";
        return false;
    } //endtry
}

bool write_bsa_helicity_charge_balance(const std::string& output_csv,
                                       const std::string& charge_csv) {
    try {
        LumiBuildOptions opts;
        opts.charge_csv_path = charge_csv;
        const LumiMap lumi = build_lumi_map(opts);
        const std::filesystem::path p(output_csv);
        std::filesystem::create_directories(p.parent_path());
        std::ofstream out(output_csv);
        if (!out.is_open()) throw std::runtime_error("cannot write " + output_csv);
        out << "period,Qplus_nC,Qminus_nC,Qplus_over_Qminus,charge_asymmetry\n";
        for (const std::string& period : base_period_order()) {
            // RGA Sp18 has no reliable helicity-resolved Faraday-cup charge.
            // Do not let a malformed/non-helicity quantity pass the generic
            // positive-number validity test (Sp18 Inb previously produced an
            // unphysical Q+/Q- ~ 230 diagnostic).
            if (period == "Sp18 Inb" || period == "Sp18 Out") {
                out << period << ",,,,\n";
                std::cout << "[bsa] helicity-charge balance " << period
                          << ": unavailable (no usable helicity-resolved FC charge).\n";
                continue;
            } //endif
            auto it = lumi.find(period);
            if (it == lumi.end() || !(it->second.stat > 0.0) || !(it->second.sys > 0.0)) {
                out << period << ",,,,\n";
                std::cout << "[bsa] helicity-charge balance " << period
                          << ": unavailable (expected for Sp18).\n";
                continue;
            } //endif
            const double qp = it->second.stat;
            const double qm = it->second.sys;
            const double ratio = qp / qm;
            const double asym = (qp - qm) / (qp + qm);
            out << period << ',' << qp << ',' << qm << ',' << ratio << ',' << asym << '\n';
            std::cout << "[bsa] helicity-charge balance " << period
                      << ": Q+/Q-=" << ratio
                      << ", (Q+-Q-)/(Q++Q-)=" << asym << "\n";
        } //endfor
        return true;
    } catch (const std::exception& e) {
        std::cerr << "[bsa] WARNING: helicity-charge balance check failed: " << e.what() << "\n";
        return false;
    } //endtry
}
